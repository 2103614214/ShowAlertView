//
//  deleteHintView.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/30.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "deleteHintView.h"

@implementation deleteHintView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //初始化控件
        UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:@"删除后，将清空该聊天的消息记录"];
        remarkLabel.backgroundColor = [UIColor whiteColor];
        remarkLabel.textAlignment = NSTextAlignmentCenter;
        remarkLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, kHeight(59));
        [self addSubview:remarkLabel];
        
        __weak typeof (self)weakSelf = self;
        float y = remarkLabel.height+1;
        UILabel *delLabel = [Utils labelTextColor:[UIColor redColor] fontSize:15 numberOfLines:1 text:@"删除"];
        delLabel.backgroundColor = [UIColor whiteColor];
        delLabel.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            weakSelf.delClick();
        }];
        [delLabel addGestureRecognizer:tap];
        delLabel.textAlignment = NSTextAlignmentCenter;
        delLabel.frame = CGRectMake(0, y, SCREEN_WIDTH, kHeight(45));
        [self addSubview:delLabel];
        
        y += (delLabel.height+(kHeight(5)));
        UILabel *closeLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"取消"];
        closeLabel.backgroundColor = [UIColor whiteColor];
        closeLabel.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
        [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
            weakSelf.closeView();
        }];
        [closeLabel addGestureRecognizer:tap1];
        closeLabel.textAlignment = NSTextAlignmentCenter;
        closeLabel.frame = CGRectMake(0, y, SCREEN_WIDTH, kHeight(45));
        [self addSubview:closeLabel];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
