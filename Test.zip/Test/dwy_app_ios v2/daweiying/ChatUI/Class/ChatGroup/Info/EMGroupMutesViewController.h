//
//  EMGroupMutesViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 06/01/2017.
//  Copyright © 2017 XieYajie. All rights reserved.
//

#import "EaseRefreshTableViewController.h"

@interface EMGroupMutesViewController : EaseRefreshTableViewController

- (instancetype)initWithGroup:(EMGroup *)aGroup;

@end
