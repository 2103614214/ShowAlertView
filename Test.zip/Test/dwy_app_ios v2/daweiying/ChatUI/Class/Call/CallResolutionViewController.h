//
//  CallResolutionViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 9/19/16.
//  Copyright © 2016 XieYajie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CallResolutionViewController : UITableViewController

@end
