//
//  EMCallOptions+NSCoding.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 15/10/2016.
//  Copyright © 2016 XieYajie. All rights reserved.
//

#import <Hyphenate/EMCallOptions.h>

@interface EMCallOptions (NSCoding)<NSCoding>

@end
