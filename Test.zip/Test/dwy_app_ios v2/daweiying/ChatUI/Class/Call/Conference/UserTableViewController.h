//
//  UserTableViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 8/31/16.
//  Copyright © 2016 XieYajie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserTableViewController : UITableViewController

- (instancetype)initWithDataSource:(NSArray *)aDataSource;

@end
