//
//  EMChatroomMutesViewController.h
//  ChatDemo-UI3.0
//
//  Created by XieYajie on 06/01/2017.
//  Copyright © 2017 XieYajie. All rights reserved.
//

#import "EaseRefreshTableViewController.h"

@interface EMChatroomMutesViewController : EaseRefreshTableViewController

- (instancetype)initWithChatroom:(EMChatroom *)aChatroom;

@end
