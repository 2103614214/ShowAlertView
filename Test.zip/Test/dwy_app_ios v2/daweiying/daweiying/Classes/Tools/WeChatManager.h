//
//  WeChatManager.h
//  daweiying
//
//  Created by 汪亮 on 2017/11/23.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeChatManager : NSObject

+(instancetype)sharedManager;
//微信登录发起授权
+(void)sendAuthrequest;

//微信支付发起支付
+(void)WXPayWithSing:(id)dataObject;

//请求本地服务器，二次签名发起微信支付
+(void)sendWechatPay:(NSString *)money WithOrderNum:(NSString *)orderNum;

//保存用户登录信息   1为手机号  2为微信登录
+(void)saveLoginInfo:(id)dataObject WithPassword:(id)password WithLoginType:(int)type;

//退出
+(void)logout;

//分享
+(void)shareBtnClick:(CGRect)rect WithDict:(NSDictionary *)dict;

//发团成功后分享
+(void)shareGroupSendClick:(CGRect)rect WithDict:(NSDictionary *)dict;
//支付成功后分享
+(void)sharePaySuccessClick:(CGRect)rect WithDict:(NSDictionary *)dict;

+(void)shareWXMessage:(int)type WithDict:(NSDictionary *)dict;
@end
