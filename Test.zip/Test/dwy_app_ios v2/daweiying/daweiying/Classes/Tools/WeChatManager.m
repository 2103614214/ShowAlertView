//
//  WeChatManager.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/23.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "WeChatManager.h"
#import <WXApi.h>
#import "ShowAnimationView.h"

@implementation WeChatManager

+(instancetype)sharedManager{
    static WeChatManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[WeChatManager alloc] init];
    });
    return instance;
}



//enum  WXErrCode {
//    WXSuccess           = 0,    //** < 成功    */
//    WXErrCodeCommon     = -1,   /**< 普通错误类型    */
//    WXErrCodeUserCancel = -2,   /**< 用户点击取消并返回    */
//    WXErrCodeSentFail   = -3,   /**< 发送失败    */
//    WXErrCodeAuthDeny   = -4,   /**< 授权失败    */
//    WXErrCodeUnsupport  = -5,   /**< 微信不支持    */
//};

-(void)onResp:(BaseResp *)resp{
    /* 微信登录的回调 */
    if ([resp isKindOfClass:[SendAuthResp class]]) {
        //拿到微信返回的code
        SendAuthResp *res = (SendAuthResp *)resp;
        //返回服务器
        [self loginSuccessByCode:res.code];
    }
    
    if([resp isKindOfClass:[PayResp class]]){
        
        //支付返回结果，实际支付结果需要去微信服务器端查询
        NSString *strMsg;
        NSString *Str = [appDelegate.appDefault objectForKey:@"pathwayType"];
        NSString *o_number = [appDelegate.appDefault objectForKey:@"o_number"];
        switch (resp.errCode) {
            case WXSuccess:
                strMsg = @"支付结果：成功！";
                //[MBManager showSuccess:strMsg];
                //KPostNotification(@"payWXSuccess", nil); //发送通知 //isQuick
                if ([Str isEqualToString:@"isQuick"]) {
                  //KPostNotification(@"sendWXSuccessOrder", o_number);
                    NSString *m_id = [appDelegate.appDefault objectForKey:@"m_uid"];
                    
                    NSString *order = [NSString stringWithFormat:@"buy=%@",o_number];
                    NSDictionary *dict = @{@"order":@(true)};
                    [EaseSDKHelper sendTextMessage:order withExt:dict WithUid:m_id];
                    
                  KPostNotification(@"payWXSuccess", nil);
                  //KPostNotification(@"fujiaPaySuccess", nil);
                  KPostNotification(@"updataLogo", nil);
                }else if ([Str isEqualToString:@"isOrder"]){
                    KPostNotification(@"BuyerOrderPaySuccess", nil);
                    KPostNotification(@"updataLogo", nil);
                    KPostNotification(@"RefreshOrder", nil);
                }
                else{
                    KPostNotification(@"payWXSuccess", nil);
                    //KPostNotification(@"fujiaPaySuccess", nil);
                    KPostNotification(@"updataLogo", nil);
                    //KPostNotification(@"BuyerOrderPaySuccess", nil);
                }
             
               NSLog(@"支付成功－PaySuccess，retcode = %d", resp.errCode);
                break;
                
            default:
                strMsg = [NSString stringWithFormat:@"支付结果：失败！retcode = %d, retstr = %@", resp.errCode,resp.errStr];
                //[MBManager showError:strMsg];
                 KPostNotification(@"fujiaPayFail", nil);
                NSLog(@"错误，retcode = %d, retstr = %@", resp.errCode,resp.errStr);
                break;
        }
    }
}

/*微信登录调起事件*/
+(void)sendAuthrequest{
    //构造SendAuthReq结构体
    SendAuthReq *req = [[SendAuthReq alloc] init];
    req.scope = @"snsapi_userinfo";
    req.openID = WXAPPID;
    //第三方向微信终端发送一个SendAuthReq消息结构
    [WXApi sendReq:req];
}

/*微信支付调起事件*/
+(void)WXPayWithSing:(id)dataObject{
    
    id payObject = [dataObject objectForKey:@"result"];
    NSDate *senddate = [NSDate date];
    NSString *date2 = [NSString stringWithFormat:@"%ld", (long)[senddate timeIntervalSince1970]];
    NSNumber *num = [NSNumber numberWithString:date2];
    //使用服务器返回的二次交易签名数据发起交易
    PayReq* req             = [[PayReq alloc] init];
    req.openID              = payObject[@"appid"];
    req.partnerId           = payObject[@"partnerid"];
    req.prepayId            = payObject[@"prepayid"];
    req.nonceStr            = payObject[@"noncestr"];
    req.timeStamp           = (UInt32)num.longValue;  //(UInt32)[payObject[@"timestamp"] integerValue];
    req.package             = payObject[@"package"];
    //req.sign                = payObject[@"sign"];
    
    //本地签名
    req.sign = [self createMD5SingForPayWithAppID:req.openID partnerid:req.partnerId prepayid:req.prepayId package:req.package noncestr:req.nonceStr timestamp:req.timeStamp];
    DLog(@"-----%@",req.sign);
    //发起微信支付
    [WXApi sendReq:req];
}

#pragma mark -  微信支付本地签名
//创建发起支付时的sign签名
+(NSString *)createMD5SingForPayWithAppID:(NSString *)appid_key partnerid:(NSString *)partnerid_key prepayid:(NSString *)prepayid_key package:(NSString *)package_key noncestr:(NSString *)noncestr_key timestamp:(UInt32)timestamp_key{
    NSMutableDictionary *signParams = [NSMutableDictionary dictionary];
    [signParams setObject:appid_key forKey:@"appid"];//微信appid 例如wxfb132134e5342
    [signParams setObject:noncestr_key forKey:@"noncestr"];//随机字符串
    [signParams setObject:package_key forKey:@"package"];//扩展字段  参数为 Sign=WXPay
    [signParams setObject:partnerid_key forKey:@"partnerid"];//商户账号
    [signParams setObject:prepayid_key forKey:@"prepayid"];//此处为统一下单接口返回的预支付订单号
    [signParams setObject:[NSString stringWithFormat:@"%u",timestamp_key] forKey:@"timestamp"];//时间戳
    
    NSMutableString *contentString  =[NSMutableString string];
    NSArray *keys = [signParams allKeys];
    //按字母顺序排序
    NSArray *sortedArray = [keys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    //拼接字符串
    for (NSString *categoryId in sortedArray) {
        if (   ![[signParams objectForKey:categoryId] isEqualToString:@""]
            && ![[signParams objectForKey:categoryId] isEqualToString:@"sign"]
            && ![[signParams objectForKey:categoryId] isEqualToString:@"key"]
            )
        {
            [contentString appendFormat:@"%@=%@&", categoryId, [signParams objectForKey:categoryId]];
        }
    }
    //添加商户密钥key字段  API 密钥
    [contentString appendFormat:@"key=%@", WX_APP_SECRET];
    NSString *result = [contentString md5String];//md5加密
    NSString *upper = [result uppercaseString];  //转大写
    return upper;
}


#pragma mark - 微信登录回调
//根据code获取access_token openid
-(void)loginSuccessByCode:(NSString *)code{
    __weak typeof (*&self)weakSelf = self;
    NSString *url = [NSString stringWithFormat:@"https://api.weixin.qq.com/sns/oauth2/access_token?appid=%@&secret=%@&code=%@&grant_type=authorization_code",WXAPPID,WX_APP_Login_SECRET,code];
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [[WLNetworking sharedWLNetworking] POST:url parameters:dict success:^(id  _Nonnull responseObject) {
        /*
            access_token  接口调用凭证
            expires_in access_token接口调用凭证超时时间,单位(秒)
            refresh_token 用户刷新access_token
            openid  授权用户户一标识
         
         */
        //NSLog(@"----------%@",responseObject);
        NSString *accessToken = [responseObject valueForKey:@"access_token"];
        NSString *openID = [responseObject valueForKey:@"openid"];
        [weakSelf requestUserInfoByToken:accessToken andOpenid:openID];
    } failure:^(NSError * _Nonnull error) {
        
        [MBManager showError:@"获取授权失败"];
    }];
}

//获取微信的用户信息
-(void)requestUserInfoByToken:(NSString *)token andOpenid:(NSString *)openID{
    NSString *url = [NSString stringWithFormat:@"https://api.weixin.qq.com/sns/userinfo?access_token=%@&openid=%@",token,openID];
    DLog(@"接口中的数据是:%@",url);
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [[WLNetworking sharedWLNetworking] POST:url parameters:dict success:^(id  _Nonnull responseObject) {
        
        //NSLog(@"---------------%@",responseObject);
        //获取到用户信息，发送通知操作
        KPostNotification(@"wxLogin", responseObject);
    } failure:^(NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
}


+(void)sendWechatPay:(NSString *)money WithOrderNum:(NSString *)orderNum{
    
    NSDictionary *params = [[NSDictionary alloc] initWithObjectsAndKeys:
                            money, @"money",
                            orderNum,@"o_number",
                            nil];
    NSString *urlStr = [Utils getMemberServiceUri:@"prepayment"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        NSLog(@"%@",[Utils transformUnicode:responseObject]);
        [MBManager hideAlert];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        id dataObject = [responseObject objectForKey:@"data"];
        if ([status isEqualToString:@"200"]) {
            
            NSString *codeStr = [[dataObject objectForKey:@"result"] objectForKey:@"return_code"];
            if ([codeStr isEqualToString:@"FAIL"]) {
                [MBManager showError:@"商户订单号重复"];
            }else{
                [self WXPayWithSing:dataObject]; //发起微信支付
            }
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        
    }];
}

//保存用户登录信息 
+(void)saveLoginInfo:(id)dataObject WithPassword:(id)password WithLoginType:(int)type{
    
    //1为手机号登录   2为微信登录  3自动登录
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    if (type == 1) { //手机号登录
        [ud setObject:password forKey:@"password"];
        [ud setObject:@(type) forKey:@"loginType"]; //登录方式
    }else if (type == 2){ //微信登录
        [ud setObject:[password objectForKey:@"openid"] forKey:@"openid"];
        [ud setObject:[password objectForKey:@"nickname"] forKey:@"nickname"];
        [ud setObject:[password objectForKey:@"headimgurl"] forKey:@"headimgurl"];
        [ud setObject:@(type) forKey:@"loginType"]; //登录方式
    }
    
    [ud setObject:[dataObject objectForKey:@"user_id"] forKey:kUser_id];
    [ud setObject:[dataObject objectForKey:@"username"] forKey:kUser_name];
    [ud setObject:[dataObject objectForKey:@"phone"] forKey:kPhone];
    [ud setObject:[dataObject objectForKey:@"token"] forKey:kToken];
    [ud setObject:[dataObject objectForKey:@"rank"] forKey:kRank];
    [ud setObject:[dataObject objectForKey:@"dwy_id"] forKey:@"dwy_id"];
    [ud setObject:[dataObject objectForKey:@"bound_phone"] forKey:@"bound_phone"];
    [ud setObject:[dataObject objectForKey:@"version"] forKey:@"version"];
    [ud setObject:[dataObject objectForKey:@"user_logo"] forKey:@"user_logo"];
    NSString *codeStr = [dataObject objectForKey:@"code_img"];
    if ([Utils isBlankString:codeStr]) {
        [ud setObject:@"" forKey:@"code_img"];
    }else{
        [ud setObject:[dataObject objectForKey:@"code_img"] forKey:@"code_img"];
    }

    [ud setObject:[dataObject objectForKey:@"pay_password"] forKey:@"pay_password"];
    [ud setObject:[dataObject objectForKey:@"fjyf_status"] forKey:@"fjyf_status"];
    [ud setObject:[dataObject objectForKey:@"store_id"] forKey:@"store_id"];
    [ud setObject:[dataObject objectForKey:@"store_type"] forKey:@"store_type"];  //店铺类型
    //地址
    NSString *phoneStr = [[dataObject objectForKey:@"address"] objectForKey:@"phone"];
    NSString *nameStr = [[dataObject objectForKey:@"address"] objectForKey:@"name"];
    NSString *provinceStr = [[dataObject objectForKey:@"address"] objectForKey:@"province"];
    NSString *cityStr = [[dataObject objectForKey:@"address"] objectForKey:@"city"];
    NSString *areaStr = [[dataObject objectForKey:@"address"] objectForKey:@"area"];
    NSString *address_nameStr = [[dataObject objectForKey:@"address"] objectForKey:@"address_name"];
    NSString *address_id = [[dataObject objectForKey:@"address"] objectForKey:@"id"];
    
    [ud setObject:phoneStr forKey:@"add_Phone"];
    [ud setObject:nameStr forKey:@"add_Name"];
    [ud setObject:provinceStr forKey:@"province"];
    [ud setObject:cityStr forKey:@"city"];
    [ud setObject:areaStr forKey:@"area"];
    [ud setObject:address_nameStr forKey:@"address_name"];
    [ud setObject:address_id forKey:@"address_id"];
    [ud synchronize];


}

+(void)logout{
    
     NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:@"" forKey:kUser_id];
    [ud setObject:@"" forKey:kUser_name];
    [ud setObject:@"" forKey:kPhone];
    [ud setObject:@"" forKey:kToken];
    [ud setObject:@"" forKey:kRank];
    [ud setObject:@"" forKey:@"dwy_id"];
    [ud setObject:@"" forKey:@"bound_phone"];
    [ud setObject:@"" forKey:@"code_img"];
    [ud setObject:@"" forKey:@"version"];
    [ud setObject:@"" forKey:@"user_logo"];
    [ud setObject:@"" forKey:@"phone"];
    [ud setObject:@"" forKey:@"city"];
    [ud setObject:@"" forKey:@"area"];
    [ud setObject:@"" forKey:@"address_name"];
    [ud setObject:@"" forKey:@"name"];
    [ud setObject:@"" forKey:@"province"];
    [ud setObject:@"" forKey:@"pay_password"];
    [ud setObject:@"" forKey:@"fjyf_status"];
    [ud setObject:@"" forKey:@"store_id"];
    [ud setObject:@"" forKey:@"store_type"];
    
    [ud setObject:@"" forKey:@"password"];
    [ud setObject:@"" forKey:@"loginType"]; //登录方式
    [ud setObject:@"" forKey:@"openid"];
    [ud setObject:@"" forKey:@"nickname"];
    [ud setObject:@"" forKey:@"headimgurl"];
    [ud setObject:@"" forKey:@"loginType"]; //登录方式
    [ud synchronize];
    
    EMError *error = [[EMClient sharedClient] logout:YES];
    if (!error) {
        //NSLog(@"退出成功");
    }//13392445601
}



//分享
+(void)shareBtnClick:(CGRect)rect WithDict:(NSDictionary *)dict{
    
    //__weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:rect];
    //装载商品信息的视图
    float height = kHeight(150);
    UIView *whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    
    
    //分享微信好友
    float viewW = SCREEN_WIDTH/2;
    UIView *friend = [[UIView alloc] init];
    friend.frame = CGRectMake(0, 0, viewW, height);
    friend.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        //[weakSelf shareWXMessage:1];
         [self shareWXMessage:1 WithDict:dict];
    }];
    [friend addGestureRecognizer:tap];
    [whiteView addSubview:friend];
    
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"friend"]];
    imageV.frame = CGRectMake((viewW-(kWidth(40)))/2, kHeight(40), kWidth(40), kHeight(40));
    [friend addSubview:imageV];
    
    UILabel *friendLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"微信好友"];
    friendLabel.textAlignment = NSTextAlignmentCenter;
    [friend addSubview:friendLabel];
    friendLabel.sd_layout
    .topSpaceToView(imageV, 5)
    .xIs(0)
    .widthIs(friend.width)
    .heightIs(kHeight(25));
    
    //分享朋友圈
    UIView *friendCircle = [[UIView alloc] init];
    friendCircle.frame = CGRectMake(viewW, 0, viewW, height);
    friendCircle.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        //[weakSelf shareWXMessage:2];
        [self shareWXMessage:2 WithDict:dict];
    }];
    [friendCircle addGestureRecognizer:tap1];
    [whiteView addSubview:friendCircle];
    
    UIImageView *imageV1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"friendC"]];
    imageV1.frame = CGRectMake((viewW-(kWidth(40)))/2, kHeight(40), kWidth(40), kHeight(40));
    [friendCircle addSubview:imageV1];
    
    UILabel *friendCircleLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"朋友圈"];
    friendCircleLabel.textAlignment = NSTextAlignmentCenter;
    [friendCircle addSubview:friendCircleLabel];
    friendCircleLabel.sd_layout
    .topSpaceToView(imageV1, 5)
    .xIs(0)
    .widthIs(friend.width)
    .heightIs(kHeight(25));
    
    [coverV addSubview:whiteView];
    [coverV showView];
    
}


//分享 ----  支付成功
+(void)sharePaySuccessClick:(CGRect)rect WithDict:(NSDictionary *)dict{
    
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:rect];
    //装载商品信息的视图
    float height = kHeight(390);
    UIView *whiteView = [[UIView alloc] initWithFrame:CGRectMake(kWidth(20), (SCREEN_HEIGHT-height)/2, SCREEN_WIDTH-(kWidth(40)), height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    whiteView.layer.cornerRadius = 10;
    whiteView.layer.masksToBounds = YES;
    
    //store_img
    UIImageView *bgImageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"store_img"]];
    bgImageV.frame = CGRectMake(0, kHeight(30), whiteView.width, kHeight(80));
    [whiteView addSubview:bgImageV];
    
    UILabel *payLabel = [Utils labelTextColor:[UIColor orangeColor] fontSize:25 numberOfLines:1 text:@"支付成功"];
    payLabel.frame = CGRectMake(0, kHeight(80), whiteView.width, kHeight(30));
    payLabel.textAlignment = NSTextAlignmentCenter;
    [whiteView addSubview:payLabel];
    
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(kWidth(20), kHeight(120), whiteView.width-(kWidth(40)), 1)];
    [whiteView addSubview:line];
    
    UILabel *title = [Utils labelTextColor:[UIColor blackColor] fontSize:20 numberOfLines:1 text:@"分享邀请好友拼团"];
    title.frame = CGRectMake(0, kHeight(140), whiteView.width, kHeight(30));
    title.textAlignment = NSTextAlignmentCenter;
    [whiteView addSubview:title];
    
    
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"省成本，就用大维营商城"];
    remarkLabel.frame = CGRectMake(0, kHeight(170), whiteView.width, kHeight(30));
    remarkLabel.textAlignment = NSTextAlignmentCenter;
    [whiteView addSubview:remarkLabel];
    
    
    
    //分享微信好友
    float viewW = whiteView.width/2;
    float viewH = kHeight(110);
    UIView *friend = [[UIView alloc] init];
    friend.frame = CGRectMake(0, kHeight(200), viewW, viewH);
    friend.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        // [weakSelf shareWXMessage:1];
        [self shareWXMessage:1 WithDict:dict];
    }];
    [friend addGestureRecognizer:tap];
    [whiteView addSubview:friend];
    
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"friend"]];
    imageV.frame = CGRectMake((viewW-(kWidth(40)))/2, kHeight(40), kWidth(40), kHeight(40));
    [friend addSubview:imageV];
    
    UILabel *friendLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"微信好友"];
    friendLabel.textAlignment = NSTextAlignmentCenter;
    [friend addSubview:friendLabel];
    friendLabel.sd_layout
    .topSpaceToView(imageV, 5)
    .xIs(0)
    .widthIs(friend.width)
    .heightIs(kHeight(25));
    
    //分享朋友圈
    UIView *friendCircle = [[UIView alloc] init];
    friendCircle.frame = CGRectMake(viewW, kHeight(200), viewW, viewH);
    friendCircle.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        // [weakSelf shareWXMessage:2];
        [self shareWXMessage:2 WithDict:dict];
    }];
    [friendCircle addGestureRecognizer:tap1];
    [whiteView addSubview:friendCircle];
    
    UIImageView *imageV1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"friendC"]];
    imageV1.frame = CGRectMake((viewW-(kWidth(40)))/2, kHeight(40), kWidth(40), kHeight(40));
    [friendCircle addSubview:imageV1];
    
    UILabel *friendCircleLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"朋友圈"];
    friendCircleLabel.textAlignment = NSTextAlignmentCenter;
    [friendCircle addSubview:friendCircleLabel];
    friendCircleLabel.sd_layout
    .topSpaceToView(imageV1, 5)
    .xIs(0)
    .widthIs(friend.width)
    .heightIs(kHeight(25));
    
    
    [coverV addSubview:whiteView];
    [coverV showView];
    
}

//分享 ----   发团成功后
+(void)shareGroupSendClick:(CGRect)rect WithDict:(NSDictionary *)dict{
    
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:rect];
    //装载商品信息的视图
    float height = kHeight(250);
    UIView *whiteView = [[UIView alloc] initWithFrame:CGRectMake(kWidth(20), (SCREEN_HEIGHT-height)/2, SCREEN_WIDTH-(kWidth(40)), height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    whiteView.layer.cornerRadius = 10;
    whiteView.layer.masksToBounds = YES;
    
    
    UILabel *title = [Utils labelTextColor:[UIColor blackColor] fontSize:20 numberOfLines:1 text:@"立即分享，跟好友一起拼团"];
    title.frame = CGRectMake(0, kHeight(30), whiteView.width, kHeight(30));
    title.textAlignment = NSTextAlignmentCenter;
    [whiteView addSubview:title];
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"省成本，提销量，就用大维营商城"];
    remarkLabel.frame = CGRectMake(0, kHeight(60), whiteView.width, kHeight(30));
    remarkLabel.textAlignment = NSTextAlignmentCenter;
    [whiteView addSubview:remarkLabel];
    
    
    
    //分享微信好友
    float viewW = whiteView.width/2;
    float viewH = kHeight(110);
    UIView *friend = [[UIView alloc] init];
    friend.frame = CGRectMake(0, kHeight(90), viewW, viewH);
    friend.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        //[weakSelf shareWXMessage:1];
        [self shareWXMessage:1 WithDict:dict];
    }];
    [friend addGestureRecognizer:tap];
    [whiteView addSubview:friend];
    
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"friend"]];
    imageV.frame = CGRectMake((viewW-(kWidth(40)))/2, kHeight(40), kWidth(40), kHeight(40));
    [friend addSubview:imageV];
    
    UILabel *friendLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"微信好友"];
    friendLabel.textAlignment = NSTextAlignmentCenter;
    [friend addSubview:friendLabel];
    friendLabel.sd_layout
    .topSpaceToView(imageV, 5)
    .xIs(0)
    .widthIs(friend.width)
    .heightIs(kHeight(25));
    
    //分享朋友圈
    UIView *friendCircle = [[UIView alloc] init];
    friendCircle.frame = CGRectMake(viewW, kHeight(90), viewW, viewH);
    friendCircle.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
//        [weakSelf shareWXMessage:2];
        [self shareWXMessage:2 WithDict:dict];
    }];
    [friendCircle addGestureRecognizer:tap1];
    [whiteView addSubview:friendCircle];
    
    UIImageView *imageV1 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"friendC"]];
    imageV1.frame = CGRectMake((viewW-(kWidth(40)))/2, kHeight(40), kWidth(40), kHeight(40));
    [friendCircle addSubview:imageV1];
    
    UILabel *friendCircleLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"朋友圈"];
    friendCircleLabel.textAlignment = NSTextAlignmentCenter;
    [friendCircle addSubview:friendCircleLabel];
    friendCircleLabel.sd_layout
    .topSpaceToView(imageV1, 5)
    .xIs(0)
    .widthIs(friend.width)
    .heightIs(kHeight(25));
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(kWidth(20), kHeight(110), whiteView.width-(kWidth(40)), 1)];
    [whiteView addSubview:line];
    
    [coverV addSubview:whiteView];
    [coverV showView];
    
}


+(void)shareWXMessage:(int)type WithDict:(NSDictionary *)dict{
    
    if ([WXApi isWXAppInstalled] && [WXApi isWXAppSupportApi]) {
        //message是多媒体分享(链接/网页/图片/音乐各种)
        //text是分享文本,两者只能选其一
        
        SendMessageToWXReq * req = [[SendMessageToWXReq alloc] init];
        req.bText = NO;
        WXMediaMessage * message = [WXMediaMessage message];
        message.title = dict[@"share_title"];
        //        [message setThumbImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:self.shareDict[@"share_img"]]]]];
        [message setThumbImage:[UIImage imageNamed:@"daweiying"]];
        message.description = dict[@"share_content"];
        
        WXWebpageObject * webObject = [WXWebpageObject object];
        webObject.webpageUrl = dict[@"share_url"];
        message.mediaObject = webObject;
        req.message = message;
        if (type == 1) {
            req.scene = WXSceneSession;
        }else if (type == 2){
            req.scene = WXSceneTimeline;
        }
        [WXApi sendReq:req];
    }
    
}





@end
