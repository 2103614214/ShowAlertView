//
//  OrderManager.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/7.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderManager : NSObject 

+(instancetype)sharedManager;

//查看物流
+(void)checkExpress:(NSString *)expressNum WithControl:(UIViewController *)VC;

//删除订单
+(void)delOrder:(NSString *)orderID WithControl:(UIViewController *)VC;

//提醒发货
+(void)RemindSend:(NSString *)OrderID;

//确认收货
+(void)ConfirmReceipt:(NSString *)OrderID Wintcontrol:(UIViewController *)VC;

//延长收货
+(void)delayGetGoods:(NSString *)days WithOrder:(NSString *)orderNum;

//付甲一方，钱包余额支付
+(void)WalletAndFujiaPay:(NSString *)money WithSign:(NSString *)sign WithOrderNum:(NSString *)OrderNum WithPayType:(NSString *)type WithController:(UIViewController *)VC;


//钱包余额支付
+(void)Wallet:(NSString *)money WithSign:(NSString *)sign WithOrderNum:(NSString *)OrderNum WithController:(UIViewController *)VC;

+(void)confirmPayType:(UIViewController *)vc WithMoney:(NSString *)money WithOrder:(NSString *)order;
+(void)PayType:(NSString *)orderNum WithController:(UIViewController *)vc WithMoney:(NSString *)money WithType:(NSString *)type;

+(void)showAlertView:(NSString *)str WithDict:(NSDictionary *)dict WithController:(UIViewController *)VC;

//确认收货输入密码验证
+(void)PayType:(NSString *)OrderID WintController:(UIViewController *)VC;



//新手引导页
+(void)chooseStoreType:(NSString *)imageName WithType:(int)type WithController:(UIViewController *)VC;

@end
