//
//  WLPasswordView.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "WLPasswordView.h"

#define kDotSize CGSizeMake (10, 10) //密码点的大小
#define kDotCount 6  //密码个数
#define K_Field_Height self.frame.size.height  //每一个输入框的高度等于当前view的高度

@implementation ForbidCopy

/**
 禁止粘贴，选中，全选功能
 */
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(paste:)) {//禁止粘贴
        return NO;
    }
    if (action == @selector(select:)) {//禁止选中
        return NO;
    }
    if (action == @selector(selectAll:)) {//禁止全选
        return NO;
    }
    return [super canPerformAction:action withSender:sender];
}


@end



@interface WLPasswordView ()


@property (nonatomic, strong) NSMutableArray *dotArray; //用于存放黑色的点点

@property (nonatomic, strong) WLKeyboardView *keyboard;

@property (nonatomic, strong) NSMutableString *passWord;

@end

@implementation WLPasswordView

- (NSMutableString *)passWord {
    if (!_passWord) {
        _passWord = [NSMutableString stringWithCapacity:6];
    }
    return _passWord;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
    
        [self initPwdTextField];
    }
    return self;
}

- (void)initPwdTextField
{
    //每个密码输入框的宽度
    CGFloat width = self.frame.size.width / kDotCount;
    
    //生成分割线
    for (int i = 0; i < kDotCount - 1; i++) {
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.textField.frame) + (i + 1) * width, 0, 0.5, K_Field_Height)];
        lineView.backgroundColor = [UIColor grayColor];
        [self addSubview:lineView];
    }
    
    self.dotArray = [[NSMutableArray alloc] init];
    //生成中间的点
    for (int i = 0; i < kDotCount; i++) {
        UIView *dotView = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.textField.frame) + (width - kDotCount) / 2 + i * width, CGRectGetMinY(self.textField.frame) + (K_Field_Height - kDotSize.height) / 2, kDotSize.width, kDotSize.height)];
        dotView.backgroundColor = [UIColor blackColor];
        dotView.layer.cornerRadius = kDotSize.width / 2.0f;
        dotView.clipsToBounds = YES;
        dotView.hidden = YES; //先隐藏
        [self addSubview:dotView];
        //把创建的黑色点加入到数组中
        [self.dotArray addObject:dotView];
    }
}

/**
 *  清除密码
 */
- (void)clearUpPassword
{
    self.textField.text = @"";
    self.passWord = nil;
    [self changeValue];
    
}


#pragma mark - init

- (UITextField *)textField
{
    if (!_textField) {
        _textField = [[ForbidCopy alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, K_Field_Height)];
        _textField.backgroundColor = [UIColor whiteColor];
        //输入的文字颜色为白色
        _textField.textColor = [UIColor whiteColor];
        //输入框光标的颜色为白色
        _textField.tintColor = [UIColor whiteColor];
        _textField.delegate = self;
        _textField.inputView = self.keyboard;
        _textField.layer.borderColor = [[UIColor grayColor] CGColor];
        _textField.layer.borderWidth = 1;
        [self addSubview:_textField];
    }
    return _textField;
}

/***************需要*************/
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    self.textField.text = nil;
    self.passWord = nil;
    
    CGFloat x = 0;
    CGFloat y = self.height - 216;
    CGFloat w = self.width;
    CGFloat h = 216;
    self.keyboard = [[WLKeyboardView alloc] initWithFrame:CGRectMake(x, y, w, h)];
    self.keyboard.backgroundColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR];
    self.keyboard.delegate = self;
    
    self.textField.inputView = _keyboard;
    
    return YES;
}

#pragma mark - WLKeyboardDelegate
- (void)keyboard:(WLKeyboardView *)keyboard didClickButton:(UIButton *)button {
    
    if (self.passWord.length > 5) return;
    [self.passWord appendString:button.currentTitle];
    self.textField.text = self.passWord;

    [self changeValue];  //黑点点改变个数
}

-(void)changeValue{
    for (UIView *dotView in self.dotArray) {
        dotView.hidden = YES;
    }
    for (int i = 0; i < self.textField.text.length; i++) {
        ((UIView *)[self.dotArray objectAtIndex:i]).hidden = NO;
    }
    if (self.textField.text.length == kDotCount) { //输入完毕，最好在此验证密码是否错误
//        if (self.inputFinish) {
//            self.inputFinish(self.passWord);
//        }
        [self getPaySign:self.passWord];
        
    }
}

- (void)keyboard:(WLKeyboardView *)keyboard didClickDeleteBtn:(UIButton *)deleteBtn {

    NSUInteger loc = self.passWord.length;
    if (loc == 0)   return;
    NSRange range = NSMakeRange(loc - 1, 1);
    [self.passWord deleteCharactersInRange:range];
    self.textField.text = self.passWord;
   
     [self changeValue];  //黑点点改变个数
}

//隐藏键盘
-(void)keyboard:(WLKeyboardView *)keyboard didClickhiddenBtn:(UIButton *)hiddenBtn{
    
    [self.textField resignFirstResponder];
}

//获取钱包支付,付甲一方支付的支付签名
-(void)getPaySign:(NSString *)pwd{
    
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"pay_pwd"] = [Utils md5:pwd];
    
    NSString *urlStr = [Utils getMemberServiceUri:@"PayPwdVerify"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
       // DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
       
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSString *sign = dataObject[@"sign"];
            
            //获得支付签名，发起支付
            if (self.inputFinish) {
                self.inputFinish(sign);
            }
            
        }else if ([status isEqualToString:@"402"]){
            [MBManager showError:@"您今天已输错3次密码,请明天再试"];
        }else if ([status isEqualToString:@"404"]){
            [MBManager showError:@"您未设置支付密码"];
            if (self.forgetBtnBlock) {
                self.forgetBtnBlock();
            }
        }
        else{

            NSString *messageString = @"支付密码不正确，请重新输入！";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:messageString delegate:self cancelButtonTitle:@"重新输入" otherButtonTitles:@"忘记密码", nil];
            
            [alert show];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {  //重新输入
        [self clearUpPassword];
    }else{ //忘记密码
        if (self.forgetBtnBlock) {
            self.forgetBtnBlock();
        }
    }
}


@end
