//
//  WLPasswordView.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WLKeyboardView.h"

@interface ForbidCopy : UITextField

@end

@interface WLPasswordView : UIView<UITextFieldDelegate,WLKeyboardDelegate,UIAlertViewDelegate>



@property (nonatomic, strong) ForbidCopy *textField;
/**
 *  清除密码
 */
- (void)clearUpPassword;

/** 输入入完毕 */
@property(nonatomic,copy) void (^inputFinish)(NSString *pwd);
/** 忘记密码 */
@property(nonatomic,copy) void (^forgetBtnBlock)();


@end
