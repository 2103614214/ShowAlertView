//
//  WLKeyboardView.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIView+Extension.h"

@class WLKeyboardView;
@protocol WLKeyboardDelegate <NSObject>

@optional
/** 点击了数字按钮 */
- (void)keyboard:(WLKeyboardView *)keyboard didClickButton:(UIButton *)button;
/** 点击删除按钮 */
- (void)keyboard:(WLKeyboardView *)keyboard didClickDeleteBtn:(UIButton *)deleteBtn;
/** 点击隐藏按钮 */
- (void)keyboard:(WLKeyboardView *)keyboard didClickhiddenBtn:(UIButton *)hiddenBtn;

@end

@interface WLKeyboardView : UIView

@property (nonatomic, assign) id<WLKeyboardDelegate> delegate;

@end
