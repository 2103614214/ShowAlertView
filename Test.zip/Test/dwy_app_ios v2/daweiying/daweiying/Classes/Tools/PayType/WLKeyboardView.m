//
//  WLKeyboardView.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "WLKeyboardView.h"

#define KeyboardCols 3
#define KeyboardTextFont 20

@interface WLKeyboardView ()

/** 删除按钮 */
@property (nonatomic, weak) UIButton *deleteBtn;

/** 隐藏键盘按钮 */
@property (nonatomic, weak) UIButton *hiddenBtn;


@end


@implementation WLKeyboardView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // 普通图片
        UIImage *image = [UIImage imageNamed:@"c_chaKeyboardButton"];
        image = [image stretchableImageWithLeftCapWidth:image.size.width * 0.5 topCapHeight:image.size.height * 0.5];
        // 高亮图片
        UIImage *highImage = [UIImage imageNamed:@"c_chaKeyboardButtonSel"];
        highImage = [highImage stretchableImageWithLeftCapWidth:highImage.size.width * 0.5 topCapHeight:highImage.size.height * 0.5];
        
        [self setupTopButtonsWithImage:image highImage:highImage];
        [self setupBottomButtonsWithImage:image highImage:highImage]; //highImage
    }
    return self;
}

#pragma mark - 数字按钮
- (void)setupTopButtonsWithImage:(UIImage *)image highImage:(UIImage *)highImage {
    
    NSMutableArray *arrM = [NSMutableArray array];
    [arrM removeAllObjects];
    for (int i = 0 ; i < 10; i++) {
        int j = arc4random_uniform(10);
        
        NSNumber *number = [[NSNumber alloc] initWithInt:j];
        if ([arrM containsObject:number]) {
            i--;
            continue;
        }
        [arrM addObject:number];
    }
    
    for (int i = 0; i < 10; i++) {
       
        UIButton *numBtn = [[UIButton alloc] init];
        NSNumber *number = arrM[i];
        NSString *title = number.stringValue;
        [numBtn setTitle:title forState:UIControlStateNormal];
        
        [numBtn setBackgroundImage:image forState:UIControlStateNormal];
        [numBtn setBackgroundImage:highImage forState:UIControlStateHighlighted];
        numBtn.titleLabel.font = [UIFont systemFontOfSize:KeyboardTextFont];//[UIFont boldSystemFontOfSize:KeyboardTextFont];
        [numBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [numBtn addTarget:self action:@selector(numBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:numBtn];
    }
}

- (void)numBtnClick:(UIButton *)numBtn {

    if ([self.delegate respondsToSelector:@selector(keyboard:didClickButton:)]) {
        [self.delegate keyboard:self didClickButton:numBtn];
    }
}


#pragma mark - 删除按钮, 隐藏键盘按钮
- (void)setupBottomButtonsWithImage:(UIImage *)image highImage:(UIImage *)highImage {
     //隐藏键盘
//    self.hiddenBtn = [self setupBottomButtonWithTitle:@"收回键盘" image:image];
//    self.hiddenBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
//   
//    [self.hiddenBtn addTarget:self action:@selector(hiddenBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    // 删除按钮
    self.deleteBtn = [self setupBottomButtonWithTitle:nil image:nil];
    [self.deleteBtn setBackgroundImage:[UIImage imageNamed:@"c_number_keyboardDeleteButton"] forState:UIControlStateNormal];
    [self.deleteBtn setBackgroundImage:[UIImage imageNamed:@"c_number_keyboardDeleteButtonSel"] forState:UIControlStateHighlighted];
    self.deleteBtn.contentMode = UIViewContentModeCenter;
    [self.deleteBtn addTarget:self action:@selector(deleteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)hiddenBtnClick:(UIButton *)hiddenBtn{
    if ([self.delegate respondsToSelector:@selector(keyboard:didClickhiddenBtn:)]) {
        [self.delegate keyboard:self didClickhiddenBtn:hiddenBtn];
    }
}
- (void)deleteBtnClick:(UIButton *)deleteBtn {

    if ([self.delegate respondsToSelector:@selector(keyboard:didClickDeleteBtn:)]) {
        [self.delegate keyboard:self didClickDeleteBtn:deleteBtn];
    }
}

- (UIButton *)setupBottomButtonWithTitle:(NSString *)title image:(UIImage *)image {
    
    UIButton *bottomBtn = [[UIButton alloc] init];
    if (title) {
        [bottomBtn setTitle:title forState:UIControlStateNormal];
        bottomBtn.titleLabel.font = [UIFont systemFontOfSize:KeyboardTextFont]; //[UIFont boldSystemFontOfSize:KeyboardTextFont];
        [bottomBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    if (image) {
        [bottomBtn setBackgroundImage:image forState:UIControlStateNormal];
        bottomBtn.userInteractionEnabled = YES;
    }
    [self addSubview:bottomBtn];
    return bottomBtn;
}

- (void)layoutSubviews {

    CGFloat topMargin = 17;
    CGFloat bottomMargin = 3;
    CGFloat leftMargin = 3;
    CGFloat colMargin = 5;
    CGFloat rowMargin = 3;
    
    CGFloat topBtnW = (self.width - 2 * leftMargin - 2 * colMargin) / 3;
    CGFloat topBtnH = (self.height - topMargin - bottomMargin - 3 * rowMargin) / 4;

    NSUInteger count = self.subviews.count;
    
    // 布局数字按钮
    for (NSUInteger i = 0; i < count; i++) {
        if (i == 0 ) { // 0
            UIButton *buttonZero = self.subviews[i];
            buttonZero.height = topBtnH;
            buttonZero.width = topBtnW;
            buttonZero.centerX = self.centerX;
            buttonZero.centerY = self.height - bottomMargin - buttonZero.height * 0.5;
            
            // 隐藏键盘及删除按钮的位置
            self.deleteBtn.x = CGRectGetMaxX(buttonZero.frame) + colMargin;
            self.deleteBtn.y = buttonZero.y;
            self.deleteBtn.width = buttonZero.width;
            self.deleteBtn.height = buttonZero.height;
            
            self.hiddenBtn.x = leftMargin;
            self.hiddenBtn.y = buttonZero.y;
            self.hiddenBtn.width = buttonZero.width;
            self.hiddenBtn.height = buttonZero.height;
            
        }
        if (i > 0 && i < 10) { // 0 ~ 9
            
            UIButton *topButton = self.subviews[i];
            CGFloat row = (i - 1) / 3;
            CGFloat col = (i - 1) % 3;
            
            topButton.x = leftMargin + col * (topBtnW + colMargin);
            topButton.y = topMargin + row * (topBtnH + rowMargin);
            topButton.width = topBtnW;
            topButton.height = topBtnH;
        }
        
    }
    
}

@end
