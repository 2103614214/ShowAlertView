//
//  OrderManager.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/7.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "OrderManager.h"
#import "LogisticModel.h"
#import "ExpressViewCtl.h"

#import "ShowAnimationView.h"
#import "ConfirmPayView.h"
#import "WeChatManager.h"
#import "PayTypeView.h"
#import "PayPasswordViewCtl.h"

#import "EaseSDKHelper.h"
#import "OrderCountCtl.h"
#import "UnionPayViewCtl.h"
#import "guideView.h"
#import "addBoundViewCtl.h"
#import "OrderCountCtl.h"
@implementation OrderManager


+(instancetype)sharedManager{
    static OrderManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[OrderManager alloc] init];
    });
    return instance;
}


//删除订单
+(void)delOrder:(NSString *)orderID WithControl:(UIViewController *)VC{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"o_number"] = orderID;
    NSString *urlStr = [Utils getMemberServiceUri:@"delOrder"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        // DLog(@"%@",responseObject);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            [MBManager showSuccess:@"删除成功"];
             KPostNotification(@"updateAllList", nil); //刷新全部列表
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [VC.navigationController popViewControllerAnimated:YES];
            });
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
}

//查看物流
+(void)checkExpress:(NSString *)expressNum WithControl:(UIViewController *)VC{

    [MBManager showLoading];

    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"express"] = expressNum;//@"886281104010914459";
    NSString *urlStr = [Utils getMemberServiceUri:@"queryByExpress"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSMutableArray *dataArray = [NSMutableArray array];
            NSDictionary *dict = [dataObject objectForKey:@"express_message"];
            dataArray = [LogisticModel mj_objectArrayWithKeyValuesArray:dict];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                ExpressViewCtl *vc = [[ExpressViewCtl alloc] init];
                vc.dataArray = dataArray;
                [VC.navigationController pushViewController:vc animated:YES];
                
            });
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        //NSLog(@"%@",error);
        [MBManager showError];
    }];

}


//提醒发货
+(void)RemindSend:(NSString *)OrderID{
    
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"o_number"] = OrderID;
    NSString *urlStr = [Utils getMemberServiceUri:@"remindSend"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            [MBManager showSuccess:@"提醒成功"];
        }else{
            [MBManager showError:@"提交数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}


//确认收货输入密码
+(void)PayType:(NSString *)OrderID WintController:(UIViewController *)VC{
    
    __weak typeof (VC)weakSelf = VC;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:VC.view.bounds];
    //装载商品信息的视图
    //NSString *payStr = @"付甲一方";
    float height = (kHeight(170))+216;
    PayTypeView *whiteView = [[PayTypeView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    whiteView.closeBtnBlock = ^{
        [coverV dismissContactView];
    };
    //忘记密码
    whiteView.forgetBtnBlock = ^{
        [coverV dismissContactView];
//        addBoundViewCtl *vc = [[addBoundViewCtl alloc] init];
//        vc.isBound = YES;
//        vc.type = isPayPassword;
      PayPasswordViewCtl *vc = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
        
    };
    __weak typeof (self)weakSELF = self;
    whiteView.inputView.inputFinish = ^(NSString *pwd) { //输入正确
        [coverV dismissContactView];
        //weakSelf.signStr = pwd;  // 保存支付签名
        //[weakSelf payBtnClick:pwd];
        [weakSELF ConfirmReceipt:OrderID Wintcontrol:weakSelf];
        
    };
    whiteView.inputView.forgetBtnBlock = ^{
        [coverV dismissContactView];
//        addBoundViewCtl *vc = [[addBoundViewCtl alloc] init];
//        vc.isBound = YES;
//        vc.type = isPayPassword;
        PayPasswordViewCtl *vc = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
    };
    [coverV addSubview:whiteView];
    [coverV showView];
    
}

//确认收货
+(void)ConfirmReceipt:(NSString *)OrderID Wintcontrol:(UIViewController *)VC{
    
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"o_number"] = OrderID;
    NSString *urlStr = [Utils getMemberServiceUri:@"confirmReceipt"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            [MBManager showSuccess:@"收货成功"];
             KPostNotification(@"updateAllList", nil); //刷新全部列表
            [VC.navigationController popViewControllerAnimated:YES];
        }else{
            [MBManager showError:@"提交数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}


//延迟收货
+(void)delayGetGoods:(NSString *)days WithOrder:(NSString *)orderNum{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"o_number"] = orderNum;
    params[@"delay_day"] = days;
    NSString *urlStr = [Utils getMemberServiceUri:@"delayGetGoods"];
    //NSLog(@"%@",params);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"提交成功"];
            
            KPostNotification(@"setupList", nil);  //刷新
            KPostNotification(@"updateAllList", nil); //刷新全部列表
            
        }else if ([status isEqualToString:@"402"]){
            
        }
        else{
            [MBManager showError:@"延长订单失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}


#pragma mark - 钱包余额，付甲一方支付
+(void)WalletAndFujiaPay:(NSString *)money WithSign:(NSString *)sign WithOrderNum:(NSString *)OrderNum WithPayType:(NSString *)type WithController:(UIViewController *)VC{
   // [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sign"] = sign;
    params[@"o_number"] = OrderNum;
    params[@"money"] = money;
    NSString *urlStr;
    if ([type isEqualToString:@"钱包余额"]) {  //钱包
        urlStr =  [Utils getMemberServiceUri:@"walletPayment"];
    }else if ([type isEqualToString:@"付甲一方"]){ //付甲一方
        urlStr = [Utils getMemberServiceUri:@"fujiaPayment"];
    }
    
    //NSLog(@"%@",params);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
       // DLog(@"%@",[Utils transformUnicode:responseObject]);
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"付款成功"];
            NSString *Str = [appDelegate.appDefault objectForKey:@"pathwayType"];
            if ([Str isEqualToString:@"isQuick"]) {
                
                NSString *m_id = [appDelegate.appDefault objectForKey:@"m_uid"];
                
                NSString *order = [NSString stringWithFormat:@"buy=%@",OrderNum];
                NSDictionary *dict = @{@"order":@(true)};
                [EaseSDKHelper sendTextMessage:order withExt:dict WithUid:m_id];
                
                KPostNotification(@"payWXSuccess", nil);
                KPostNotification(@"fujiaPaySuccess", nil);
                KPostNotification(@"updataLogo", nil);
                KPostNotification(@"updateAllList", nil); //刷新全部列表
            }else{
                KPostNotification(@"payWXSuccess", nil);
                KPostNotification(@"fujiaPaySuccess", nil);
                KPostNotification(@"updataLogo", nil);
               
                //BuyerOrderPaySuccess
            }

            
        }else if ([status isEqualToString:@"201"]){ //余额不足
            [MBManager showBriefAlert:hint];
            id fjyf = [appDelegate.appDefault objectForKey:@"fjyf_status"];
            if ([fjyf intValue] == 0) { //未开通
                 KPostNotification(@"fujiaPayFail", nil);
            }else{ //已开通 付甲一方  抱歉，无法完成付款,
                NSString *string = [NSString stringWithFormat:@"%@",hint];
            
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

                    NSDictionary *dict = @{@"sign":sign,@"o_number":OrderNum,@"payType":type,@"money":money};
                    [self showAlertView:string WithDict:dict WithController:VC];
                });
            }
        }else{
            [MBManager showError:hint];
            KPostNotification(@"fujiaPayFail", nil);
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}

#pragma mark - 钱包余额
+(void)Wallet:(NSString *)money WithSign:(NSString *)sign WithOrderNum:(NSString *)OrderNum WithController:(UIViewController *)VC{
    // [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sign"] = sign;
    params[@"o_number"] = OrderNum;
    params[@"money"] = money;
    NSString *urlStr = [Utils getMemberServiceUri:@"walletPayment"];

    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        // DLog(@"%@",[Utils transformUnicode:responseObject]);
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
              [MBManager showSuccess:@"付款成功"];
            NSString *Str = [appDelegate.appDefault objectForKey:@"pathwayType"];
            NSLog(@"%@",Str);
            if ([Str isEqualToString:@"isOrder"]) {
                KPostNotification(@"updataLogo", nil);
                KPostNotification(@"RefreshOrder", nil);
                KPostNotification(@"BuyerOrderPaySuccess", nil);
            }else{
                KPostNotification(@"payWXSuccess", nil);
                //KPostNotification(@"fujiaPaySuccess", nil);
                KPostNotification(@"updataLogo", nil);
                //KPostNotification(@"BuyerOrderPaySuccess", nil);
            }
          
          
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                for (UIViewController *controller in VC.navigationController.viewControllers) {
//                    if ([controller isKindOfClass:[MainTabBarController class]]) {
//                        [VC.navigationController popToViewController:controller animated:YES];
//                    }
//                }
                OrderCountCtl *vc = [[OrderCountCtl alloc] init];
                [VC.navigationController pushViewController:vc animated:YES];
            });
            
        }else{
            [MBManager showError:hint];
            //KPostNotification(@"fujiaPayFail", nil);
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                OrderCountCtl *vc = [[OrderCountCtl alloc] init];
                vc.jumpType = 1;
                [VC.navigationController pushViewController:vc animated:YES];
            });
            
        }
//        else if ([status isEqualToString:@"201"]){ //余额不足
//
//        }
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}

+(void)showAlertView:(NSString *)str WithDict:(NSDictionary *)dict WithController:(UIViewController *)VC{
    
    __weak typeof (VC)weakSelf = VC;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:str preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"组合支付" style:(UIAlertActionStyleDestructive) handler:^(UIAlertAction * _Nonnull action) {
        UnionPayViewCtl *vc= [[UnionPayViewCtl alloc] init];
        vc.dict = dict;
        [weakSelf.navigationController pushViewController:vc animated:YES];
    }];
    [alertA setValue:[UIColor orangeColor] forKey:@"_titleTextColor"];
    
    UIAlertAction *alertB = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {
       
        OrderCountCtl *vc = [[OrderCountCtl alloc] init];
        vc.jumpType = 1;
        [weakSelf.navigationController pushViewController:vc animated:YES];
    }];
    [alertB setValue:[UIColor blackColor] forKey:@"_titleTextColor"];
    [alert addAction:alertA];
    [alert addAction:alertB];


    [VC presentViewController:alert animated:YES completion:nil];
}


+(void)confirmPayType:(UIViewController *)vc WithMoney:(NSString *)money WithOrder:(NSString *)order{ //130 100
   
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:vc.view.bounds];
    //装载商品信息的视图
    int number = 2;
//    id fjStatus = [appDelegate.appDefault objectForKey:@"fjyf_status"];
//    if ([fjStatus intValue] == 1) {
//        number = 3;
//    }else{
//        number = 2;
//    }
    float height = number*(kHeight(50))+(kHeight(230));
    ConfirmPayView *whiteView = [[ConfirmPayView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height) WithStr:@"钱包余额" WithPrice:money];
    whiteView.closeView = ^{
        [coverV dismissContactView];
    };
    //支付
    whiteView.payBlock = ^(NSString *payType) {
        [coverV dismissContactView];
        
        if ([payType isEqualToString:@"微信支付"]) {
            
            [WeChatManager sendWechatPay:money WithOrderNum:order];
        }else{ //钱包，付甲一方
            [OrderManager PayType:order WithController:vc WithMoney:money WithType:payType];
        }
      
    };
    [coverV addSubview:whiteView];
    [coverV showView];
}


//钱包余额，
+(void)PayType:(NSString *)orderNum WithController:(UIViewController *)vc WithMoney:(NSString *)money WithType:(NSString *)type{
    
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:vc.view.bounds];
    //装载商品信息的视图
    //NSString *payStr = @"付甲一方";
    float height = (kHeight(170))+216;
    PayTypeView *whiteView = [[PayTypeView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    whiteView.closeBtnBlock = ^{
        [coverV dismissContactView];
    };
    //忘记密码
    whiteView.forgetBtnBlock = ^{
        [coverV dismissContactView];

      PayPasswordViewCtl *vc1 = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [vc.navigationController pushViewController:vc1 animated:YES];
        });
    
    };
    whiteView.inputView.inputFinish = ^(NSString *pwd) { //输入正确
        [coverV dismissContactView];
        //weakSelf.signStr = pwd;  // 保存支付签名
        
       // [OrderManager WalletAndFujiaPay:money WithSign:pwd WithOrderNum:orderNum WithPayType:type];
        //[OrderManager WalletAndFujiaPay:money WithSign:pwd WithOrderNum:orderNum WithPayType:type WithController:vc];
        [OrderManager Wallet:money WithSign:pwd WithOrderNum:orderNum WithController:vc];
        
    };
    //密码错误，忘记密码
    whiteView.inputView.forgetBtnBlock = ^{
        [coverV dismissContactView];
//        addBoundViewCtl *vc1 = [[addBoundViewCtl alloc] init];
//        vc1.isBound = YES;
//        vc1.type = isPayPassword;
        PayPasswordViewCtl *vc1 = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [vc.navigationController pushViewController:vc1 animated:YES];
        });
    };
    [coverV addSubview:whiteView];
    [coverV showView];
    
}



//新手引导页
//1---我的页面
+(void)chooseStoreType:(NSString *)imageName WithType:(int)type WithController:(UIViewController *)VC{
    // __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:VC.view.bounds];
    guideView *whiteView = [[guideView alloc] initWithFrame:VC.view.bounds WithType:type WithImageName:imageName];
    
    whiteView.imageClickBlock = ^{
        [coverV dismissContactView];
    };
    [coverV addSubview:whiteView];
    [coverV showView];
}

@end
