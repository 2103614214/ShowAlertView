//
//  guideView.m
//  daweiying
//
//  Created by 汪亮 on 2018/1/2.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "guideView.h"

@implementation guideView

-(instancetype)initWithFrame:(CGRect)frame WithType:(int)type WithImageName:(NSString *)imageName{
    if (self = [super initWithFrame:frame]) {
        
        //初始化
        __weak typeof (self)weakSelf = self;
        UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
        imageV.frame = self.bounds;
        imageV.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            //点击消失
            if (weakSelf.imageClickBlock) {
                weakSelf.imageClickBlock();
            }
        }];
        [imageV addGestureRecognizer:tap];
        [self addSubview:imageV];
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
