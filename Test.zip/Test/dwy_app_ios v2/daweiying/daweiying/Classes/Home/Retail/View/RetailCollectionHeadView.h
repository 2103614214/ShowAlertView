//
//  RetailCollectionHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/20.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SDCycleScrollView.h>

@interface RetailCollectionHeadView : UICollectionReusableView

/** 轮播图 */
@property(nonatomic,strong)SDCycleScrollView *cycleScrollView;
/** 分类  */
@property(nonatomic,strong)UIView *categoryView;
/** 数据源 */
@property(nonatomic,strong)NSArray *dataArray;

@end
