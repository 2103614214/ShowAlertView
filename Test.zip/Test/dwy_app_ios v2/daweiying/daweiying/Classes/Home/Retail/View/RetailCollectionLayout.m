//
//  RetailCollectionLayout.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/20.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "RetailCollectionLayout.h"

@implementation RetailCollectionLayout

/// 准备布局
- (void)prepareLayout {
    [super prepareLayout];
    //设置item尺寸
    CGFloat itemW = (self.collectionView.frame.size.width-5)/ 2;
    self.itemSize = CGSizeMake(itemW, SCREEN_HEIGHT*0.3);
    
    //设置最小间距
    self.minimumLineSpacing = 5;
    self.minimumInteritemSpacing = 5;
    self.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.headerReferenceSize=CGSizeMake(SCREEN_WIDTH, (SCREEN_HEIGHT*0.48)+10); //设置collectionView头视图的大
}

@end
