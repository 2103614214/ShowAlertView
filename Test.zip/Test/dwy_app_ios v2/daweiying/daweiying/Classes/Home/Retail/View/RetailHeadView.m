//
//  RetailHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/20.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "RetailHeadView.h"
#import "UISearchBar+SearchBarPlaceholder.h"

@interface RetailHeadView() <UISearchBarDelegate>

@end

@implementation RetailHeadView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];

    UIButton *backBtn = [UIButton new];
    [backBtn setImage:[UIImage imageNamed:@"shop_btn_back_22_22"] forState:0];
    [[backBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        //返回按钮
        self.backBlock();
    }];
    [self addSubview:backBtn];
    backBtn.sd_layout
    .topSpaceToView(self, 5)
    .leftSpaceToView(self, 5)
    .widthIs(30)
    .heightIs(30);
    _backBtn = backBtn;
    
    //搜索
    _searchBar = [[UISearchBar alloc] init];
    _searchBar.keyboardType =UIKeyboardTypeNumbersAndPunctuation;
    [_searchBar changeLeftPlaceholder:@"商品名称"];
    UIImage* searchBarBg = [self GetImageWithColor:[UIColor clearColor] andHeight:32.0f];
    [_searchBar setBackgroundImage:searchBarBg];
    _searchBar.delegate = self;
    [self addSubview:_searchBar];
    _searchBar.sd_layout
    .topEqualToView(backBtn)
    .leftSpaceToView(backBtn, 5)
    .widthIs(self.width-backBtn.width-20)
    .heightIs(30);
    
}


#pragma mark 实现搜索条背景透明化

- (UIImage*) GetImageWithColor:(UIColor *)color andHeight:(CGFloat)height{
    
    CGRect r= CGRectMake(0.0f, 0.0f, 1.0f, height);
    
    UIGraphicsBeginImageContext(r.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    
    CGContextFillRect(context, r);
    
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
    
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
