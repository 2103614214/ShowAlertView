//
//  RetailViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/20.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "RetailViewCtl.h"
#import "RetailCollectionHeadView.h"
#import "publicCollectionViewCell.h"
#import "RetailCollectionLayout.h"
#import "HomeModel.h"
#import "RetailHeadView.h"

@interface RetailViewCtl () <UICollectionViewDelegate, UICollectionViewDataSource>

/** 顶部视图 */
@property (nonatomic,strong) RetailHeadView *headView;
/** collectionView */
@property (nonatomic, strong) UICollectionView *collectionView;
/** 商品数据源 */
@property(nonatomic,strong)NSMutableArray *productMutableArr;

/** 轮播图广告页数据源 */
@property(nonatomic,strong)NSMutableArray *AdvMutableArr;
/** 分类(大类)数据源 */
@property(nonatomic,strong)NSMutableArray *categoryMutableArr;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;


@end

static NSString *collectionID = @"CollectionViewCell";
static NSString *headerViewID = @"hederviewID";

@implementation RetailViewCtl

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:[[RetailCollectionLayout alloc] init]];
        [_collectionView registerClass:[publicCollectionViewCell class] forCellWithReuseIdentifier:collectionID];
        if (@available(iOS 11.0, *)) {
            _collectionView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            _collectionView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, kTabBarHeight, 0);
            _collectionView.scrollIndicatorInsets = _collectionView.contentInset;
        }
        //注册头视图
        [_collectionView registerClass:[RetailCollectionHeadView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                   withReuseIdentifier:headerViewID];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        
    }
    return _collectionView;
}

-(NSMutableArray *)productMutableArr{
    if (!_productMutableArr) {
        _productMutableArr = [NSMutableArray array];
    }
    return _productMutableArr;
}
-(NSMutableArray *)AdvMutableArr{
    if (!_AdvMutableArr) {
        _AdvMutableArr = [NSMutableArray array];
    }
    return _AdvMutableArr;
}

-(NSMutableArray *)categoryMutableArr{
    if (!_categoryMutableArr) {
        _categoryMutableArr = [NSMutableArray array];
    }
    return _categoryMutableArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self viewDidLoad:YES];
    
    //collectionView
    [self.view addSubview:self.collectionView];
    
    __weak typeof(self)weakSelf = self;
    //顶部视图
    self.headView = [[RetailHeadView alloc] initWithFrame:CGRectMake(0, 20, SCREEN_WIDTH, 44)];
    self.headView.backBlock = ^{
        [weakSelf back];
    };
    [self.view addSubview:self.headView];

    
    // 添加刷新控件
    [self setupRefresh];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBar.hidden = YES;
}

-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //搜索键盘消失
    [self.headView.searchBar resignFirstResponder];
    self.headView.searchBar.text = nil;
    
    if ([scrollView isKindOfClass:[UICollectionView class]]) {
        CGFloat contentOffsetY = scrollView.contentOffset.y;
        
        if (contentOffsetY > 64) {
            self.headView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
            [self setStatusBarBackgroundColor:[UIColor colorWithHex:0xedf0f3]];
            
            //设置返回按钮图片颜色
            [self.headView.backBtn setImage:[UIImage imageNamed:@"login_btn_back_22_22"] forState:0];
            
        }else{
            self.headView.backgroundColor = [UIColor clearColor];
            [self setStatusBarBackgroundColor:[UIColor clearColor]];
            //设置返回按钮图片颜色
            [self.headView.backBtn setImage:[UIImage imageNamed:@"shop_btn_back_22_22"] forState:0];
        }
    }
    
}


-(void)setupRefresh{
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.collectionView.mj_header.automaticallyChangeAlpha = YES;
    [self.collectionView.mj_header beginRefreshing];
    
    self.collectionView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
}

-(void)loadData{
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];

    NSString *urlStr = [Utils getMemberLoginUri:@"retail"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
         //DLog(@"%@",responseObject);
    
        [self.collectionView.mj_header endRefreshing];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            //品牌推广数据源
            NSDictionary *hotDict = [dataObject objectForKey:@"products"];
            self.productMutableArr = [HomeModel mj_objectArrayWithKeyValuesArray:hotDict];
            
            //分类数据源
            hotDict = [dataObject objectForKey:@"categorys"];
            self.categoryMutableArr = [catetorysModel mj_objectArrayWithKeyValuesArray:hotDict];
            
            //轮播广告页
            hotDict = [dataObject objectForKey:@"banner"];
            self.AdvMutableArr = [AdvModel mj_objectArrayWithKeyValuesArray:hotDict];
            //不发通知传值过去， 轮播图不自动轮播
            [[NSNotificationCenter defaultCenter] postNotificationName:@"RetailNotification" object:self.AdvMutableArr];
            
            [self.collectionView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_header endRefreshing];
        if (self.params != params) return;
    }];

}

//上拉刷新请求
-(void)loadMoreDatas{
    // 结束下拉
    [self.collectionView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"没有更多数据了"];
        [self.collectionView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"retail"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *hotDict = [dataObject objectForKey:@"products"];
            NSArray *newProducts = [HomeModel mj_objectArrayWithKeyValuesArray:hotDict];
            [self.productMutableArr addObjectsFromArray:newProducts];
            
            [self.collectionView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.collectionView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_footer endRefreshing];
        if (self.params != params) return;
    }];
    
}


#pragma mark UICollectionViewDataSource 数据源方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.productMutableArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    publicCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectionID forIndexPath:indexPath];
    cell.model = self.productMutableArr[indexPath.row];
    return cell;
}

#pragma mark UICollectionView 代理方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    DLog(@"点击了%ld----%ld",indexPath.section,indexPath.row);
}


//  返回头视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    //如果是头视图
    RetailCollectionHeadView *view = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                        withReuseIdentifier:headerViewID
                                                                               forIndexPath:indexPath];
    if ([kind isEqualToString:UICollectionElementKindSectionHeader])
    {
        //刷新头部数据源
        view.dataArray = self.categoryMutableArr;
        
    }
    return view;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
