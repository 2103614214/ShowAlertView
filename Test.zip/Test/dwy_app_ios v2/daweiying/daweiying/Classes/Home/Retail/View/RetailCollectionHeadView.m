//
//  RetailCollectionHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/20.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "RetailCollectionHeadView.h"
#import "HomeModel.h"

#define CURRENT_SIZE(_size) _size / 375.0 * SCREEN_WIDTH

@interface RetailCollectionHeadView()<SDCycleScrollViewDelegate>

@end

@implementation RetailCollectionHeadView
{
    UIImageView *_imageView1;
    UIImageView *_imageView2;
    UIImageView *_imageView3;
    UIImageView *_imageView4;
    UIImageView *_imageView5;
    
    UILabel *_label1;
    UILabel *_label2;
    UILabel *_label3;
    UILabel *_label4;
    UILabel *_label5;

}

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self)
    {
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    //设置轮播图
    self.cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.25) delegate:self placeholderImage:[UIImage imageNamed:@""]];
    
    self.cycleScrollView.autoScrollTimeInterval = 3.0;
    _cycleScrollView.currentPageDotColor = [UIColor whiteColor];
    _cycleScrollView.pageDotColor = [UIColor colorWithHex:0xffffff alpha:0.5];
    _cycleScrollView.pageControlDotSize = CGSizeMake(8, 8);
    // 不设置标题
    self.cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleClassic;
    self.cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    self.cycleScrollView.bannerImageViewContentMode = UIViewContentModeScaleToFill;
    [self addSubview:self.cycleScrollView];
    
    
    //分类
    float interval = 10;
    float y = self.cycleScrollView.height;
    CGRect ret = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_HEIGHT*0.15);
    self.categoryView = [[UIView alloc] initWithFrame:ret];
    self.categoryView.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.categoryView];
    
    for (int i=0; i<5;i++) {
        UIView * vi = [[UIView alloc] initWithFrame:CGRectMake((SCREEN_WIDTH / 5.0 ) * i, 0, SCREEN_WIDTH / 5.0, self.height)];
        vi.userInteractionEnabled = YES;
        vi.tag = 100 + i;
        vi.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
        [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
            
            //self.imageViewBlock(@"selection", 101);
            NSLog(@"%ld",vi.tag);
        }];
        [vi addGestureRecognizer:tap1];
        
        float imageVW = vi.width/1.8;
        UIImageView * imageV = [[UIImageView alloc] initWithFrame:CGRectMake((vi.width-imageVW)/2, CURRENT_SIZE(15), imageVW, vi.width/1.8)];
        [vi addSubview:imageV];
        
        UILabel * label = [[UILabel alloc] init];
        label.font = [UIFont systemFontOfSize:12];
        label.textColor = [UIColor grayColor];
        label.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:label];
        label.sd_layout
        .topSpaceToView(imageV, 10)
        .centerXEqualToView(imageV)
        .widthIs(SCREEN_HEIGHT / 5)
        .heightIs(15);
        
        if (i == 0) {
            _imageView1 = imageV;
            _label1 = label;
        }else if (i == 1){
            _imageView2 = imageV;
            _label2 = label;
        }else if (i == 2){
            _imageView3 = imageV;
            _label3 = label;
        }else if (i == 3){
            _imageView4 = imageV;
            _label4 = label;
        }else if (i == 4){
            _imageView5 = imageV;
            _label5 = label;
        }else{
            return;
        }
        
        [self.categoryView addSubview:vi];
    
        
    }

    y += self.categoryView.height+interval;
    ret = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_HEIGHT*0.07);
    UIView *headTitleview = [[UIView alloc] initWithFrame:ret];
    headTitleview.backgroundColor = [UIColor whiteColor];
    [self addSubview:headTitleview];
    
    
    UILabel *titleLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"推荐商品"];
    titleLabel.frame = CGRectMake(headTitleview.width/2, 0, 90, headTitleview.height);
    [headTitleview addSubview:titleLabel];
    
    UIImage *imageName = [UIImage imageNamed:@"shop_icon_fire_18_18"];
    UIImageView *imageV = [[UIImageView alloc] initWithImage:imageName];
    float imageVW = headTitleview.height/1.5;
    imageV.frame = CGRectMake(headTitleview.width/2-imageVW-10, 5, imageVW, imageVW);
    [headTitleview addSubview:imageV];

    
    y += headTitleview.height;
    ret = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_HEIGHT*0.01);
    UIView *lineView = [[UIView alloc] initWithFrame:ret];
    lineView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    [self addSubview:lineView];
}

-(void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    for (int i =0; i < _dataArray.count; i++) {
        catetorysModel *model = _dataArray[i];
        if (i == 0) {
            [_imageView1 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label1.text = model.cate_name;
        }else if (i == 1){
            [_imageView2 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label2.text = model.cate_name;
        }else if (i == 2){
            [_imageView3 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label3.text = model.cate_name;
        }else if (i == 3){
            [_imageView4 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label4.text = model.cate_name;
        }else if (i == 4){
            [_imageView5 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label5.text = model.cate_name;
        }else{
            
            return;
        }
    }

}
-(void)RetailNotiData:(NSNotification *)noti{
    NSMutableArray *array = [NSMutableArray array];
    NSArray *arr = noti.object;
    for (int i =0; i <arr.count; i++) {
        AdvModel *model = arr[i];
        [array addObject:model.b_logo];
    }
    
    self.cycleScrollView.imageURLStringsGroup = array;
}

//移除通知方法
- (void)willMoveToWindow:(UIWindow *)newWindow {
    if (newWindow == nil) {
        // Will be removed from window, similar to -viewDidUnload.
        // Unsubscribe from any notifications here.
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"RetailNotification" object:nil];
    }
    
}

//添加通知方法
- (void)didMoveToWindow {
    if (self.window) {
        // Added to a window, similar to -viewDidLoad.
        // Subscribe to notifications here.
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(RetailNotiData:) name:@"RetailNotification" object:nil];
    }
    
}


/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    DLog(@"%ld",index);
}


@end
