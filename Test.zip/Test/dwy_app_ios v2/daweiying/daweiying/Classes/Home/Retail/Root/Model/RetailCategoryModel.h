//
//  RetailCategoryModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/12.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface RetailCategoryModel : BaseModel

/** 分类id */
@property(nonatomic,assign)int cate_id;
/** 分类名 */
@property(nonatomic,copy)NSString *cate_name;

@end
