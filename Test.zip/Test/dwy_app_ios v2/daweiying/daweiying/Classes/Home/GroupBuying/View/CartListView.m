//
//  CartListView.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CartListView.h"
#import "CartListViewCell.h"

static NSString * const CartListId = @"CartListId";
@implementation CartListView

-(NSMutableArray *)objects{
    if (!_objects) {
        _objects = [NSMutableArray array];
    }
    return _objects;
}

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSMutableArray *)objects{
    self = [super initWithFrame:frame];
    
    if (self) {
        self.objects = objects;
    
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];
    
    UILabel *totalLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"购物车"];
    totalLabel.backgroundColor = [UIColor colorWithHex:0xf7ca5e];
    totalLabel.textAlignment = NSTextAlignmentCenter;
    totalLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, kHeight(30));
    [self addSubview:totalLabel];
    
    UIView *headV = [[UIView alloc] initWithFrame:CGRectMake(0, kHeight(30), SCREEN_WIDTH, kHeight(50))];
    headV.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:headV];
    
    UILabel *label = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"已选商品"];
    label.frame = CGRectMake(10, 0, 100, headV.height);
    [headV addSubview:label];
    
    UIButton *delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    delBtn.frame = CGRectMake(SCREEN_WIDTH-(kWidth(80)), 0, kWidth(80), headV.height);
    [delBtn setImage:[UIImage imageNamed:@"shopaddress_btn_delet_18_18"] forState:0];
    [delBtn setTitle:@" 清空" forState:0];
    [delBtn addTarget:self action:@selector(clearAllList) forControlEvents:UIControlEventTouchUpInside];
    [delBtn setTitleColor:[UIColor grayColor] forState:0];
    delBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [headV addSubview:delBtn];

    // [self count]; //求和
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeight(80), SCREEN_WIDTH, self.height-(kHeight(80)))];
    self.tableView.bounces = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.rowHeight = kHeight(70);
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[CartListViewCell class] forCellReuseIdentifier:CartListId];
    
}

#pragma mark - TableViewDelegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.objects count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CartListViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CartListId forIndexPath:indexPath];
    if (!cell) {
        cell = [[CartListViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CartListId];
    }
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    cell.selectionStyle = UITableViewCellSelectionStyleNone; //取消点中效果
    cell.model = self.objects[indexPath.row];
    
    return cell;
    
}

//左滑删除
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
    
        [self.objects removeObjectAtIndex:indexPath.row];
     
        if (self.updateCartListBlock) {
            self.updateCartListBlock();
        }
        [self.tableView reloadData];
    }
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

-(void)clearAllList{
    UIAlertView *alertV = [[UIAlertView alloc] initWithTitle:@"" message:@"确定清空购物车?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [alertV show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex == 1) {
    
        [self.objects removeAllObjects];
        
        if (self.updateCartListBlock) {
            self.updateCartListBlock();
        }
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
