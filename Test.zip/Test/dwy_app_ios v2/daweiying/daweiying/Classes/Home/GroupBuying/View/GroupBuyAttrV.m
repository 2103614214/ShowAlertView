//
//  GroupBuyAttrV.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupBuyAttrV.h"
#import "GroupBuyAttrCell.h"
#import "MyStoreModel.h"
#import "GroupBuyAttrModel.h"

static NSString * const GroupAttributeViewSelectedId = @"GroupAttributeViewSelectedId";
@implementation GroupBuyAttrV

-(NSMutableArray *)objects{
    if (!_objects) {
        _objects = [NSMutableArray array];
    }
    return _objects;
}

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSArray *)objects isPayType:(int)isPayType WithDict:(MyStoreModel *)dict{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        //self.objects = objects;
        for (int i = 0; i<objects.count; i++) {
            GroupBuyAttrModel *model = [[GroupBuyAttrModel alloc] init];
            model.pro_attrName = objects[i];
            model.number = 0;
            model.units = dict.units;
            model.pro_name = dict.pro_name;
            if (isPayType == 1) {
                 model.price = dict.price;
            }else if (isPayType == 2){
                 model.price = dict.group_price;
            }
           
            model.pro_id = dict.pro_id;
            [self.objects addObject:model];
        }
        self.dict = dict;
        self.type = isPayType;
        [self initWithSubViews];
    }
    return self;
}
-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];
    
    UIView *headV = [[UIView alloc] initWithFrame:CGRectMake(0, kHeight(30), SCREEN_WIDTH, kHeight(60))];
    headV.backgroundColor = [UIColor whiteColor];
    [self addSubview:headV];
    
    UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(kWidth(15), -(kHeight(30)), kWidth(90), kHeight(80))];
    //[imgV setImage:[UIImage imageNamed:placeImageName]];
    [imgV sd_setImageWithURL:[NSURL URLWithString:self.dict.pro_img] placeholderImage:[UIImage imageNamed:placeImageName]];
    [headV addSubview:imgV];
    
    
    //价格
    NSString *priceStr;
    if (self.type == 1) { //原价
        priceStr = [NSString stringWithFormat:@"¥%@/%@",self.dict.price,self.dict.units];
    }else{ //团购价
        priceStr = [NSString stringWithFormat:@"¥%@/%@",self.dict.group_price,self.dict.units];
    }
    UILabel *priceLabel1 = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:14 numberOfLines:1 text:priceStr];
    priceLabel1.frame = CGRectMake(kWidth(125), 0, kWidth(200), kHeight(30));
    [headV addSubview:priceLabel1];
    
    if (self.type == 1) {
        //最低起批数
        NSString *leastStr = [NSString stringWithFormat:@"最低起批数量: %ld",self.dict.least_number];
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:leastStr];
        nameLabel.frame = CGRectMake(kWidth(125), kHeight(25), kWidth(200), kHeight(30));
        [headV addSubview:nameLabel];
    }
    
    UILabel *line2 = [Utils lineWithFrame:CGRectMake(0, kHeight(89), SCREEN_WIDTH, 1)];
    [self addSubview:line2];
    
    UIButton *closeBtn = [UIButton addBtnImage:@"shopspec_btn_close_30_30" WithTarget:self action:@selector(dismissContactView)];
    closeBtn.frame = CGRectMake(SCREEN_WIDTH-(kWidth(45)), (kHeight(15)), kWidth(30), kHeight(30));
    [self addSubview:closeBtn];
    
    
    //底部  80
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, self.height-(kHeight(80)), SCREEN_WIDTH, 1)];
    [self addSubview:line];
    
    UILabel *priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"  已选 0个  共计 0.00"];
    priceLabel.backgroundColor = [UIColor whiteColor];
    [self addSubview:priceLabel];
    priceLabel.sd_layout
    .topSpaceToView(line, 0)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(35));
    self.priceLabel = priceLabel;
    
    //确定
    float btnH = kHeight(45);
//    if (kTabBarHeight > 49) {
//        btnH = kHeight(65);
//    }
    
     __weak typeof (self)weakSelf = self;
    NSString *btnStr = @"确认已选";
    float BtnX = 0;
    float BtnW = SCREEN_WIDTH;
    if (self.type == 2) { //团购 ,加入购物车
        btnStr = @"购买";
        BtnX = SCREEN_WIDTH/2;
        BtnW = SCREEN_WIDTH/2;
        UIButton *stockBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        stockBtn.frame = CGRectMake(0, self.height-btnH, SCREEN_WIDTH/2, kHeight(45));
        [stockBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xff9602]] forState:UIControlStateNormal];
        [stockBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xa58702]] forState:UIControlStateHighlighted];
        [stockBtn setTitleColor:[UIColor whiteColor] forState:0];
        stockBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [stockBtn setTitle:@"加入购物车" forState:0];
        [self addSubview:stockBtn];
        [[stockBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
            
            NSInteger cout = 0;
            int SelectedCout = 0;
            for (GroupBuyAttrModel *model in weakSelf.objects) {
                cout +=model.number;
                if (model.number > 0) {
                    SelectedCout +=1;
                }
            }
            if (cout > 0) {
                
                if (weakSelf.delegete && [weakSelf.delegete respondsToSelector:@selector(SeletedAttrSucceed:WithStoreModel:WithType:)]) {
                    [weakSelf.delegete SeletedAttrSucceed:weakSelf.objects WithStoreModel:weakSelf.dict WithType:3];
                }
            }else{
                [MBManager showError:@"未选择商品!"];
            }
            
            
        }];

    }
    //普通商品,直接购买
    UIButton *stockBtn = [Utils createMainButtonEnable];
    stockBtn.frame = CGRectMake(BtnX, self.height-btnH, BtnW, kHeight(45));
    //[stockBtn setBackgroundColor:[UIColor colorWithHex:0xff9701]];
    [stockBtn setTitleColor:[UIColor whiteColor] forState:0];
    stockBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [stockBtn setTitle:btnStr forState:0];
    [self addSubview:stockBtn];
    [[stockBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        
        NSInteger cout = 0;
        int SelectedCout = 0;
        for (GroupBuyAttrModel *model in weakSelf.objects) {
            cout +=model.number;
            if (model.number > 0) {
                SelectedCout +=1;
            }
        }
        if (weakSelf.type == 1) {
            if (cout < weakSelf.dict.least_number) {
                [MBManager showError:@"小于最低起批数!"];
                return;
            }
        }
        if (cout > 0) {
         
            if (weakSelf.delegete && [weakSelf.delegete respondsToSelector:@selector(SeletedAttrSucceed:WithStoreModel:WithType:)]) {
                [weakSelf.delegete SeletedAttrSucceed:weakSelf.objects WithStoreModel:weakSelf.dict WithType:weakSelf.type];
            }
        }else{
            [MBManager showError:@"未选择商品!"];
        }
      
        
    }];

    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeight(90), SCREEN_WIDTH, self.height-(kHeight(170)))];
    self.tableView.bounces = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[GroupBuyAttrCell class] forCellReuseIdentifier:GroupAttributeViewSelectedId];
    
}


#pragma mark - TableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.objects count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return kHeight(60);
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    GroupBuyAttrCell *cell = [tableView dequeueReusableCellWithIdentifier:GroupAttributeViewSelectedId forIndexPath:indexPath];
    if (!cell) {
        cell = [[GroupBuyAttrCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:GroupAttributeViewSelectedId];
    }
 
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    cell.selectionStyle = UITableViewCellSelectionStyleNone; //取消点中效果
    cell.model = self.objects[indexPath.row];
    
    __weak typeof (self)weakSelf = self;
    cell.numberClickBlock = ^{
        //[weakSelf count];
        NSInteger cout = 0;
        for (GroupBuyAttrModel *model in weakSelf.objects) {
            cout +=model.number;
        }
        float totalPrice = 0;
        if (weakSelf.type == 1) {
            totalPrice = cout * [weakSelf.dict.price floatValue];
        }else if (weakSelf.type == 2){
            totalPrice = cout * [weakSelf.dict.group_price floatValue];
        }
        
        weakSelf.priceLabel.text = [NSString stringWithFormat:@"  已选 %ld个  共计 ¥%.2f",cout,totalPrice];
    };
    
    return cell;
    
}

-(void)dismissContactView{
    if (self.closeView) {
        self.closeView();
    }
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
