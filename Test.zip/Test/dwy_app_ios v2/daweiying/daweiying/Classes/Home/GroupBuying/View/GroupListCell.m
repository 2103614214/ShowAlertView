//
//  GroupListCell.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/23.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupListCell.h"
#import "GroupListModel.h"
#import "MZTimerLabel.h"

@implementation GroupListCell
{
    UILabel *_storeNameLabel;
    UILabel *_numberLabel;
    UILabel *_remarkLabel;
    UILabel *_oldPrice;
    UILabel *_newPrice;
    UIImageView *_logV;
    MZTimerLabel *_timerLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //初始化cell
        self.contentView.backgroundColor = [UIColor colorWithHex:0xfafafa];
        
        UIView *headV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(45))];
        headV.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:headV];
        
        UIImageView *logV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shopping_icon_tittle_18_18"]];
        logV.frame = CGRectMake(kWidth(10), 12, kWidth(20), 20);
        [headV addSubview:logV];
        
        
        UILabel *storeNameLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
        storeNameLabel.frame = CGRectMake(kWidth(35), 0, kWidth(120), headV.height);
        [headV addSubview:storeNameLabel];
        _storeNameLabel = storeNameLabel;
        
        
        UILabel *numberLabel = [Utils labelTextColor:[UIColor redColor] fontSize:13 numberOfLines:1 text:@""];
        numberLabel.adjustsFontSizeToFitWidth = YES;
        numberLabel.frame = CGRectMake(kWidth(155), 0, SCREEN_WIDTH-(kWidth(165)), headV.height);
        numberLabel.textAlignment = NSTextAlignmentRight;
        [headV addSubview:numberLabel];
        _numberLabel = numberLabel;
     
        float y = 55;
        UIImageView *picV = [[UIImageView alloc] initWithFrame:CGRectMake(kWidth(10), y, kWidth(100), 110)];
        //[picV setImage:[UIImage imageNamed:placeImageName]];
        [self.contentView addSubview:picV];
        _logV = picV;
        
        
        UILabel *remarkLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"5"];
        remarkLabel.frame = CGRectMake(kWidth(120), y, SCREEN_WIDTH-(kWidth(130)), 50);
        remarkLabel.numberOfLines = 0;
        [self.contentView addSubview:remarkLabel];
        _remarkLabel = remarkLabel;
        
        //110+45
        UILabel *oldPrice = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@""];
        oldPrice.frame = CGRectMake(kWidth(120), 125, kWidth(60), 25);
        oldPrice.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:oldPrice];
        _oldPrice = oldPrice;
        
        UILabel *oldLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:11 numberOfLines:1 text:@"原价"];
        oldLabel.frame = CGRectMake(kWidth(120), 150, kWidth(60), 15);
        [self.contentView addSubview:oldLabel];
        
        UILabel *newPrice = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:18 numberOfLines:1 text:@""];
        newPrice.frame = CGRectMake(kWidth(190), 120, kWidth(90), 30);
        [self.contentView addSubview:newPrice];
        _newPrice = newPrice;
        
        UILabel *newLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:11 numberOfLines:1 text:@"团购价"];
        newLabel.frame = CGRectMake(kWidth(190), 150, kWidth(90), 15);
        [self.contentView addSubview:newLabel];
        
       
        
        UIButton *groupBtn = [Utils createMainButtonEnable];
        [groupBtn setTitle:@"去参团" forState:UIControlStateNormal];
        groupBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        groupBtn.layer.cornerRadius = 3;
        groupBtn.layer.masksToBounds = YES;
        [groupBtn addTarget:self action:@selector(groupListClick) forControlEvents:UIControlEventTouchUpInside];
        groupBtn.frame = CGRectMake(SCREEN_WIDTH-(kWidth(100)), 130, kWidth(90), 35);
        [self.contentView addSubview:groupBtn];
        
        UIImageView *timeImageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shopping_btn_time_12_12"]];
        timeImageV.frame = CGRectMake(SCREEN_WIDTH-(kWidth(100)), 110, 15, 15);
        [self.contentView addSubview:timeImageV];
        
        UILabel *timerLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:12 numberOfLines:1 text:@"00:00:00"];
        timerLabel.frame = CGRectMake(SCREEN_WIDTH-(kWidth(80)), 108, groupBtn.width, kHeight(20));
        [self.contentView addSubview:timerLabel];
         _timerLabel = [[MZTimerLabel alloc] initWithLabel:timerLabel andTimerType:MZTimerLabelTypeTimer];
  
        
    }
    
    return self;
}

-(void)groupListClick{
    if (self.delegate && [self.delegate respondsToSelector:@selector(GroupListCellClick:)]) {
        [self.delegate GroupListCellClick:self];
    }
}

-(void)setModel:(GroupListModel *)model{
    _model = model;
    
    _storeNameLabel.text = [NSString stringWithFormat:@"%@ >",model.group_title];
    //5件商品在拼团，6人正在团购
    _numberLabel.text = [NSString stringWithFormat:@"%@件商品在拼团,%@人正在团购",model.group_number,model.user_number];
    [_logV sd_setImageWithURL:[NSURL URLWithString:model.goods.pro_img] placeholderImage:[UIImage imageNamed:placeImageName]];
    _remarkLabel.text = model.goods.pro_name;
    
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"¥%@",model.goods.price]];
    [aString
     addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:10]range:NSMakeRange(0, 1
                                                                                          )];
    NSMutableAttributedString *bString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"¥%@",model.goods.group_price]];
    [bString
     addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12]range:NSMakeRange(0, 1
                                                                                          )];
    
    _oldPrice.attributedText = aString;
    _newPrice.attributedText = bString;
    //30*60
    [_timerLabel setCountDownTime:[Utils Countdown:model.c_time]]; //** Or you can use [timer3 setCountDownToDate:aDate];
    [_timerLabel start];
    
    
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
