//
//  SpecialApplyViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "SpecialApplyViewCtl.h"

@interface SpecialApplyViewCtl ()

@end

@implementation SpecialApplyViewCtl

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"申请专场";
    
    [self initWithSubViews];
}

-(void)initWithSubViews{
    UILabel *storeLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"  店铺信息"];
    storeLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, kHeight(40));
    [self.scrollView addSubview:storeLabel];
    
    UIView *storeV = [[UIView alloc] initWithFrame:CGRectMake(0, storeLabel.height, SCREEN_WIDTH, kHeight(150))];
    storeV.backgroundColor = [UIColor whiteColor];
    [self.scrollView addSubview:storeV];
    

    UILabel *storeNameLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"店铺名"];
    storeNameLabel.frame = CGRectMake(kWidth(10), 0, kWidth(100), kHeight(50));
    [storeV addSubview:storeNameLabel];
    
    UITextField *storeF = [Utils addTextFieldWithFrame:CGRectMake(kWidth(110), 0, SCREEN_WIDTH-(kWidth(120)), storeLabel.height) AndStr:@"请输入您的店铺名" AndFont:14 AndTextColor:[UIColor blackColor]];
    storeF.textAlignment = NSTextAlignmentLeft;
    [storeV addSubview:storeF];

    UILabel *line = [Utils lineWithFrame:CGRectMake(0, kHeight(50), SCREEN_WIDTH, 1)];
    [storeV addSubview:line];
    
    UILabel *typeLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"产品类别"];
    typeLabel.frame = CGRectMake(kWidth(10), kHeight(51), kWidth(100), kHeight(49));
    [storeV addSubview:typeLabel];
    
    UITextField *typeF = [Utils addTextFieldWithFrame:CGRectMake(kWidth(110), kHeight(51), SCREEN_WIDTH-(kWidth(120)), typeLabel.height) AndStr:@"请输入产品类别" AndFont:14 AndTextColor:[UIColor blackColor]];
    typeF.textAlignment = NSTextAlignmentLeft;
    [storeV addSubview:typeF];
    
    UILabel *line1 = [Utils lineWithFrame:CGRectMake(0, kHeight(100), SCREEN_WIDTH, 1)];
    [storeV addSubview:line1];
    

    UILabel *addressLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"店铺地址"];
    addressLabel.frame = CGRectMake(kWidth(10), kHeight(101), kWidth(100), kHeight(49));
    [storeV addSubview:addressLabel];
    
    UITextField *addressF = [Utils addTextFieldWithFrame:CGRectMake(kWidth(110), kHeight(101), SCREEN_WIDTH-(kWidth(120)), addressLabel.height) AndStr:@"请输入详细地址" AndFont:14 AndTextColor:[UIColor blackColor]];
    addressF.textAlignment = NSTextAlignmentLeft;
    [storeV addSubview:addressF];
    
    
    //联系方式
    UILabel *contactLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"  联系方式"];
    contactLabel.frame = CGRectMake(0, kHeight(190), SCREEN_WIDTH, kHeight(40));
    [self.scrollView addSubview:contactLabel];
    
    UIView *contactV = [[UIView alloc] initWithFrame:CGRectMake(0, kHeight(230), SCREEN_WIDTH, kHeight(100))];
    contactV.backgroundColor = [UIColor whiteColor];
    [self.scrollView addSubview:contactV];
    
    
    UILabel *NameLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"联系人"];
    NameLabel.frame = CGRectMake(kWidth(10), 0, kWidth(100), kHeight(50));
    [contactV addSubview:NameLabel];
    
    UITextField *nameF = [Utils addTextFieldWithFrame:CGRectMake(kWidth(110), 0, SCREEN_WIDTH-(kWidth(120)), storeLabel.height) AndStr:@"请输入姓名" AndFont:14 AndTextColor:[UIColor blackColor]];
    nameF.textAlignment = NSTextAlignmentLeft;
    [contactV addSubview:nameF];
    
    UILabel *line3 = [Utils lineWithFrame:CGRectMake(0, kHeight(50), SCREEN_WIDTH, 1)];
    [contactV addSubview:line3];
    
    UILabel *telLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"手机号"];
    telLabel.frame = CGRectMake(kWidth(10), kHeight(51), kWidth(100), kHeight(49));
    [contactV addSubview:telLabel];
    
    UITextField *telF = [Utils addTextFieldWithFrame:CGRectMake(kWidth(110), kHeight(51), SCREEN_WIDTH-(kWidth(120)), typeLabel.height) AndStr:@"请输入手机号码" AndFont:14 AndTextColor:[UIColor blackColor]];
    telF.keyboardType = UIKeyboardTypePhonePad;
    telF.textAlignment = NSTextAlignmentLeft;
    [contactV addSubview:telF];
    
    __weak typeof (self)weakSelf = self;
    UIButton *commitBtn = [Utils createMainButtonEnable];
    [commitBtn setTitle:@"提交" forState:0];
    commitBtn.layer.cornerRadius = 3;
    commitBtn.layer.masksToBounds = YES;
    [self.scrollView addSubview:commitBtn];
    commitBtn.sd_layout
    .topSpaceToView(contactV, kHeight(50)).xIs(kWidth(20)).widthIs(SCREEN_WIDTH-(kWidth(40))).heightIs(kHeight(49));
    [[commitBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        
        NSString *shop_name = storeF.text;
        NSString *pro_cate = typeF.text;
        NSString *address = addressF.text;
        NSString *username = nameF.text;
        NSString *phone = telF.text;
        
        if ([Utils isBlankString:shop_name] ||[Utils isBlankString:pro_cate] || [Utils isBlankString:address] ||[Utils isBlankString:username] || [Utils isBlankString:phone]) {
            [MBManager showError:@"信息未填写完整!"];
            return;
        }else{
            NSDictionary *params = @{@"shop_name": shop_name, @"pro_cate":pro_cate,@"address":address,
                                     @"username": username,@"phone": phone
                                     };
            [weakSelf RequestData:params];
        }

        
    }];
}

//  请求数据
- (void)RequestData:(NSDictionary *)parameters{
    
    
    __weak typeof(self) WeakSelf = self;
    
    //网络请求
    NSString *urlString = [Utils V2GetMemberServiceUrl:@"special_apply"];
    
    [super PostRequsetDataUrlString:urlString Parameters:parameters];
    self.PostSuccess=^(id responseObject){
        //解析
        NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"申请成功"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [WeakSelf.navigationController popToRootViewControllerAnimated:YES];
            });
            
        }else{
            [MBManager showBriefAlert:@"申请失败"];
        }
  
    };
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
