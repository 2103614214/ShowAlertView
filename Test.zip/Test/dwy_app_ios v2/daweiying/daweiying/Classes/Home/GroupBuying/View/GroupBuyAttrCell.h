//
//  GroupBuyAttrCell.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/28.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class GroupBuyAttrModel;

@interface GroupBuyAttrCell : UITableViewCell <UITextFieldDelegate>

@property(nonatomic,strong)UILabel *numberLabel;

@property (nonatomic,assign) NSInteger number;

//属性
@property(nonatomic,assign)UILabel *nameLabel;
/** model */
@property(nonatomic,strong)GroupBuyAttrModel *model;

/** 数量block */
@property(nonatomic,copy) void (^numberClickBlock)();

@end
