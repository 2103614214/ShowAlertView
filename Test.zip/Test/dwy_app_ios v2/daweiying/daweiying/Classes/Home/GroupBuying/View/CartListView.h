//
//  CartListView.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CartListView : UIView <UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>

@property (nonatomic,strong) NSMutableArray *objects;

@property(nonatomic,strong)NSDictionary *dict;

@property (nonatomic,strong) UITableView *tableView;

/** 更新列表 */
@property(nonatomic,copy) void (^updateCartListBlock)();

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSMutableArray *)objects;

@end
