//
//  GroupBuyingFootV.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupBuyingFootV.h"

@implementation GroupBuyingFootV

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        UIView *grayV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH-(kWidth(100)), self.height)];
        grayV.backgroundColor = [UIColor colorWithHex:0x5a5a5a];
        [self addSubview:grayV];
        
        UIImageView *carV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shopping-_btn_shopcart_32_32"]];
        carV.frame = CGRectMake(kWidth(20), 10, 35, 35);
        carV.userInteractionEnabled = YES;
        [grayV addSubview:carV];
        self.carV = carV;
        
        UIImageView *iconV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shopping_icon_15_15"]];
        [grayV addSubview:iconV];
        iconV.hidden = YES;
        iconV.sd_layout
        .leftSpaceToView(carV, -15).yIs(5).widthIs(20).heightIs(20);
        self.iconV = iconV;
 
        
        //shopping_icon_15_15
        UILabel *rangeLabel = [Utils labelTextColor:[UIColor whiteColor] fontSize:10 numberOfLines:1 text:@""];
        rangeLabel.backgroundColor = [UIColor clearColor];
        //rangeLabel.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"shopping_icon_15_15"]];
        rangeLabel.textAlignment = NSTextAlignmentCenter;
//        rangeLabel.layer.cornerRadius = 10;
//        rangeLabel.layer.masksToBounds = YES;
        rangeLabel.hidden = YES;
        [grayV addSubview:rangeLabel];
        rangeLabel.sd_layout
        .leftSpaceToView(carV, -15).yIs(5).widthIs(20).heightIs(20);
        self.rangeLabel = rangeLabel;
        

        
        UILabel *priceLabel = [Utils labelTextColor:[UIColor whiteColor] fontSize:16 numberOfLines:1 text:@"¥0.00"];
        [grayV addSubview:priceLabel];
        priceLabel.sd_layout
        .leftSpaceToView(carV, 10).yIs(20).widthIs(200).heightIs(20);
        self.priceLabel = priceLabel;
//        UILabel *remarkLabel = [Utils labelTextColor:[UIColor whiteColor] fontSize:11 numberOfLines:1 text:@"另外需要快递费 6"];
//        [grayV addSubview:remarkLabel];
//        remarkLabel.sd_layout
//        .leftSpaceToView(carV, 10).topSpaceToView(priceLabel, 0).widthIs(200).heightIs(15);
        
        UIButton *payBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [payBtn setTitle:@"去结算" forState:0];
        payBtn.frame = CGRectMake(grayV.width, 0, kWidth(100), self.height);
        [payBtn setTitleColor:[UIColor whiteColor] forState:0];
        payBtn.backgroundColor = [UIColor redColor];
        [payBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xc52d24]] forState:UIControlStateHighlighted];
//         payBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        payBtn.titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:17];
         [self addSubview:payBtn];
        self.payBtn = payBtn;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
