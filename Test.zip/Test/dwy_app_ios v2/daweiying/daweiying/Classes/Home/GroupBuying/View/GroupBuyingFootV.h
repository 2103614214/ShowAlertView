//
//  GroupBuyingFootV.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupBuyingFootV : UIView

@property(nonatomic,strong)UIImageView *carV;

@property(nonatomic,weak)UIButton *payBtn;
/** 标识 */
@property(nonatomic,weak)UILabel *rangeLabel;
/** 圆圈 */
@property(nonatomic,weak)UIImageView *iconV;
/** 标识 */
@property(nonatomic,weak)UILabel *priceLabel;

@end
