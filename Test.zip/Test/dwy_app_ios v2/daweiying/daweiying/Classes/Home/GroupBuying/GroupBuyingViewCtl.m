//
//  GroupBuyingViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupBuyingViewCtl.h"
#import "MyStoreCell.h"
#import "PriceTypeView.h"
#import "MyStoreHeadV.h"

#import "GroupBuyingFootV.h"
#import "ShowAnimationView.h"
#import "GroupBuyAttrV.h"
#import "CartListView.h"

#import "DWYAffirmViewCtl.h"
#import "MyStoreModel.h"
#import "NSObject+Property.h"
#import "CollectTools.h"
#import "GroupBuyAttrModel.h"
#import "MyStoreModel.h"
#import "GroupOrderSucceedCtl.h"
#import "GroupInfoModel.h"
#import <WXApi.h>
#import "StoreIntroViewCtl.h"
#import "LoginUtils.h"
#import "ChatViewController.h"
#import "XLPhotoBrowser.h"
#import "WeChatManager.h"
@interface GroupBuyingViewCtl () <UITableViewDelegate,UITableViewDataSource,MyStoreCellDelegate,GroupBuyAttrvDelegate>

/** headview */
@property(nonatomic,strong)MyStoreHeadV *headView;

@property(nonatomic,weak)ShowAnimationView *coverV;

@property(nonatomic,weak)GroupBuyAttrV *whiteView;
/** footv */
@property(nonatomic,weak)GroupBuyingFootV *footv;

// 数据源
@property (nonatomic, strong) NSMutableArray *dataArray;
//已拼团数组
@property (nonatomic, strong) NSMutableArray *is_GroupDataArray;
//  上拉、下拉   页码
@property (nonatomic, assign)NSInteger pageIndex;
//总页数
@property (nonatomic, assign)NSInteger total_page;
/** 店铺信息 */
@property(nonatomic,strong)NSDictionary *storeInfoDict;

@property(nonatomic,weak)UIButton *likeBtn;

@property(nonatomic,weak)UILabel *likeLabel;
/** 收藏人数 */
@property(nonatomic,assign)NSInteger collect_number;

/** 购物车数据源 */
@property(nonatomic,strong)NSMutableArray *cartMutArray;
/** 团购id */
@property(nonatomic,copy)NSString *group_id;

@property(nonatomic,strong)NSDictionary *shareDict;

@property(nonatomic,strong)EaseImageView *avatarView;


@end

static NSString * const GroupBuyingId = @"GroupBuyingId";
@implementation GroupBuyingViewCtl

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableArray *)is_GroupDataArray{
    if (!_is_GroupDataArray) {
        _is_GroupDataArray = [NSMutableArray array];
    }
    return _is_GroupDataArray;
}

-(NSMutableArray *)cartMutArray{
    if (!_cartMutArray) {
        _cartMutArray = [NSMutableArray array];
    }
    return _cartMutArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.titleStr;
    
    
    // 初始值  通过修改该数组来增加请求数
    self.pageIndex = 1;
    self.total_page = 1;
    
    //  添加  下拉  上拉
    __weak typeof(self) WeakSelf = self;
    [self createMJRefresh:isAll actionBlock:^{
        [WeakSelf MJRequestData];
    }];
    
    
    //  网络请求
    [self MJRequestData];
    
    //  添加 主tableView
    self.mainTableView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 55-kBottomMargeHeight);
    self.headView = [[MyStoreHeadV alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 190)];
    self.headView.checkBtn.hidden = YES;
   
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        //NSLog(@"tap");
        StoreIntroViewCtl *vc = [StoreIntroViewCtl new];
        vc.store_id = [WeakSelf.storeId intValue];
        [WeakSelf.navigationController pushViewController:vc animated:YES];
        
    }];
    [self.headView.storeInfoV addGestureRecognizer:tap1];
    
    self.mainTableView.tableHeaderView = self.headView;
    self.mainTableView.rowHeight = 160;
    self.mainTableView.delegate = self;
    self.mainTableView.dataSource = self;
    self.mainTableView.separatorStyle =  UITableViewCellSeparatorStyleSingleLine;
    // 注册 重用名
    [self.mainTableView registerClass:[MyStoreCell class] forCellReuseIdentifier:GroupBuyingId];
    [self.view addSubview: self.mainTableView];
    
 
    GroupBuyingFootV *footv = [[GroupBuyingFootV alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-55-kBottomMargeHeight, SCREEN_WIDTH, 55)];
    [footv.payBtn addTarget:self action:@selector(payBtnClick) forControlEvents:UIControlEventTouchUpInside];
    @weakify(self);
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        @strongify(self);
        if (self.coverV.isOpen) {
            
            [self.coverV dismissContactView];
        }else{
            if (self.cartMutArray.count > 0) {
                [self popCarList];
            }
            
        }
        
    }];
    [footv.carV addGestureRecognizer:tap];
    [self.view addSubview:footv];
    self.footv = footv;
    
    [self setupNavItems];// 初始化nav
    
        
        //客服
        self.avatarView = [[EaseImageView alloc] init];
        self.avatarView.image = [UIImage imageNamed:@"shopping_btn_chat_60_60"];
        self.avatarView.backgroundColor = [UIColor clearColor];
        [self.view addSubview:self.avatarView];
        self.avatarView.sd_layout
        .bottomSpaceToView(self.view, kHeight(80))
        .rightSpaceToView(self.view, kWidth(10))
        .widthIs(kWidth(60))
        .heightIs(kWidth(60));
        UITapGestureRecognizer *avatarVtap = [[UITapGestureRecognizer alloc] init];
        __weak typeof(self)weakSelf = self;
        [[avatarVtap rac_gestureSignal] subscribeNext:^(id x) {
            
            int m = [[weakSelf.storeInfoDict objectForKey:@"c_id"] intValue];
            NSString *name = [weakSelf.storeInfoDict objectForKey:@"s_name"];
            NSString *strId = [NSString stringWithFormat:@"%d",m];
            ChatViewController *chatController = [[ChatViewController alloc] initWithConversationChatter:strId conversationType:EMConversationTypeChat];
            chatController.jumpType = 3;
            chatController.titleStr = name;
            chatController.storeId = [weakSelf.storeInfoDict objectForKey:@"s_id"];
            [weakSelf.navigationController pushViewController:chatController animated:YES];
                
        }];
        [self.avatarView addGestureRecognizer:avatarVtap];
        
        UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];
        [self.avatarView addGestureRecognizer:pan];//给图片添加手势
    
    
}

#pragma mark - 手势执行的方法
-(void)handlePan:(UIPanGestureRecognizer *)rec{
    
    self.avatarView.alpha = 1.0;
    CGFloat KWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat KHeight = [UIScreen mainScreen].bounds.size.height;
    
    //返回在横坐标上、纵坐标上拖动了多少像素
    CGPoint point=[rec translationInView:self.view];
    
    CGFloat centerX = rec.view.center.x+point.x;
    CGFloat centerY = rec.view.center.y+point.y;
    
    CGFloat viewHalfH = rec.view.frame.size.height/2;
    CGFloat viewhalfW = rec.view.frame.size.width/2;
    
    //确定特殊的centerY
    if (centerY - viewHalfH < 0 ) {
        centerY = viewHalfH;
    }
    if (centerY + viewHalfH > KHeight ) {
        centerY = KHeight - viewHalfH;
    }
    
    //确定特殊的centerX
    if (centerX - viewhalfW < 0){
        centerX = viewhalfW;
    }
    if (centerX + viewhalfW > KWidth){
        centerX = KWidth - viewhalfW;
    }
    
    rec.view.center=CGPointMake(centerX, centerY);
    
    //拖动完之后，每次都要用setTranslation:方法制0这样才不至于不受控制般滑动出视图
    [rec setTranslation:CGPointMake(0, 0) inView:self.view];
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        _avatarView.alpha = 0.6;
    });
    
    
}



-(void)setupNavItems{
    
    UIView *leftV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kWidth(65), kHeight(44))];
    UIView *rightV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kWidth(70), kHeight(44))];
    
    UIButton *backBtn = [UIButton addBtnImage:@"login_btn_back_22_22" WithTarget:self action:@selector(back)];
    backBtn.frame = CGRectMake(0, 0, kWidth(20), leftV.height);
    [leftV addSubview:backBtn];
    
    UIButton *homeBtn = [UIButton addBtnImage:@"shopping-_btn_homepage_22_22" WithTarget:self action:@selector(homeBtnClick)];
    homeBtn.frame = CGRectMake(kWidth(35), 0, kWidth(30), leftV.height);
    [leftV addSubview:homeBtn];
 
    UIButton *likeBtn = [UIButton addBtnImage:@"shopping-_btn_love_22_22" WithTarget:self action:@selector(likeBtnClick:)];
    likeBtn.frame = CGRectMake(0, 0, kWidth(40), leftV.height);
    [likeBtn setImage:[UIImage imageNamed:@"shopping-_btn_pre_love_22_22"] forState:UIControlStateSelected];
    [rightV addSubview:likeBtn];
    self.likeBtn = likeBtn;
    
    UILabel *likeLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:8 numberOfLines:1 text:@""];
    likeLabel.adjustsFontSizeToFitWidth = YES;
    likeLabel.frame = CGRectMake(kWidth(20), kHeight(20), kWidth(35), kHeight(15));
    [rightV addSubview:likeLabel];
    self.likeLabel = likeLabel;
    
    UIButton *shareBtn = [UIButton addBtnImage:@"shopping-_btn_share_22_22" WithTarget:self action:@selector(shareBtnClick)];
    shareBtn.frame = CGRectMake(kWidth(50), 0, kWidth(30), leftV.height);
    [rightV addSubview:shareBtn];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:leftV];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:rightV];
    
    
}

//收藏
-(void)likeBtnClick:(UIButton *)sender{
    
    if (![LoginUtils isLogin]) { //未登录
        [Utils loginController:self];
    }else{
        sender.selected = !sender.selected;
        if (sender.selected) { //收藏
            self.collect_number +=1;
            [CollectTools collectStoreV2:self.storeId WithType:1];
        }else{ //取消
            self.collect_number -=1;
            [CollectTools collectStoreV2:self.storeId WithType:2];
        }
        self.likeLabel.text = [Utils colloctNumer:self.collect_number];
        //[NSString stringWithFormat:@"+%ld人",self.collect_number];
    }


    
}

-(void)homeBtnClick{
    for (UIViewController *controller in self.navigationController.viewControllers) {
        if ([controller isKindOfClass:[MainTabBarController class]]) {
            [self.navigationController popToViewController:controller animated:YES];
        }
    }
}


//分享
-(void)shareBtnClick{
    [WeChatManager shareBtnClick:self.view.bounds WithDict:self.shareDict];
    
}


-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

// 请求数据
- (void)MJRequestData{
    if (self.judge == 10) {
        // 下拉时 清空数据数组 重新请求添加
        self.pageIndex = 1;
//        [self.dataArray removeAllObjects];
//        [self.is_GroupDataArray removeAllObjects];
     
    } else if (self.judge == 11){
        // 上拉时  数组中添加内容
        self.pageIndex++;
   
    }
    __weak typeof(self) WeakSelf = self;
    
    //转换一下
    NSString *Number = [NSString stringWithFormat:@"%ld",(long)self.pageIndex];
 
    NSDictionary *parameters = @{@"page": Number, @"store_id":self.storeId};
    
    if (self.pageIndex > self.total_page) {
        // 为零时 实现没有更多数据
        [self.mainTableView.mj_footer endRefreshingWithNoMoreData];
        return;
    }
  
    //网络请求
    NSString *urlString = [Utils V2GetMemberServiceUrl:@"group_procurement"];
    
    [super PostRequsetDataUrlString:urlString Parameters:parameters];
    self.PostSuccess=^(id responseObject){
        //解析
        //下拉刷新清空数据
        if (WeakSelf.judge == 10) {
            [WeakSelf.dataArray removeAllObjects];
            [WeakSelf.is_GroupDataArray removeAllObjects];
        }
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        if ([status isEqualToString:@"200"]) {
            
         
            
            id dataObjct = [responseObject objectForKey:@"data"];
            WeakSelf.total_page = [[dataObjct objectForKey:@"total_page"] integerValue];
            if (WeakSelf.total_page == 0) {
                WeakSelf.total_page = 1;
            }
            id is_collect = [dataObjct objectForKey:@"is_collect"];
            id collect_number = [dataObjct objectForKey:@"collect_number"];
            WeakSelf.collect_number = [collect_number integerValue];
            WeakSelf.likeLabel.text = [Utils colloctNumer:WeakSelf.collect_number];
            if ([is_collect intValue] == 0) {
                WeakSelf.likeBtn.selected = NO;
            }else if ([is_collect intValue] == 1){
                WeakSelf.likeBtn.selected = YES;
            }
            
            WeakSelf.storeInfoDict = [dataObjct objectForKey:@"store"];
            WeakSelf.shareDict = [dataObjct objectForKey:@"share"];
            NSDictionary *groupDict = [dataObjct objectForKey:@"group"];
            [WeakSelf setHeadViewState:groupDict];
            
//            NSArray *rootArray = dataObjct[@"group_goods"];
//
//            for (NSDictionary *dic in rootArray) {
//
//                MyStoreModel *model = [MyStoreModel objectWithDictionary:dic];
//                //处理数据，转模型之类的
//                [WeakSelf.dataArray addObject:model];
//
//            }
//            if (rootArray.count == 0) {
//                // 为零时 实现没有更多数据
//                [WeakSelf.mainTableView.mj_footer endRefreshingWithNoMoreData];
//            } else {
//                [WeakSelf.mainTableView.mj_footer endRefreshing];
//            }
//        }else if ([status isEqualToString:@"202"]){
//            [WeakSelf.mainTableView.mj_footer endRefreshingWithNoMoreData];
//        }else if ([status isEqualToString:@"201"]){
//            [MBManager showBriefAlert:@"没有数据"];
//        }
        
        
        
        NSArray *rootArray = dataObjct[@"goods_list"];
        NSArray *group_goodsArray = dataObjct[@"group_goods"];
        for (NSDictionary *dic in rootArray) {

            MyStoreModel *model = [MyStoreModel objectWithDictionary:dic];
            //处理数据，转模型之类的
            [WeakSelf.dataArray addObject:model];
        }
            if (self.judge != 11) {
                for (NSDictionary *dic in group_goodsArray) {
                    
                    MyStoreModel *model = [MyStoreModel objectWithDictionary:dic];
                    //处理数据，转模型之类的
                    [WeakSelf.is_GroupDataArray addObject:model];
                }
            }
   

        if (WeakSelf.is_GroupDataArray.count < 1) {

            [WeakSelf.headView.redV setHeight:0];
            [WeakSelf.headView.whiteCV setHeight:0];
            [WeakSelf.headView setHeight:70];
            [WeakSelf.headView.storeInfoV setMj_y:0];
            WeakSelf.headView.redV.hidden = YES;
            WeakSelf.headView.whiteCV.hidden = YES;


        }
        
        
            if (rootArray.count == 0) {
                // 为零时 实现没有更多数据
                [WeakSelf.mainTableView.mj_footer endRefreshingWithNoMoreData];
            } else {
                [WeakSelf.mainTableView.mj_footer endRefreshing];
            }
        }else if ([status isEqualToString:@"202"]){
            [WeakSelf.mainTableView.mj_footer endRefreshingWithNoMoreData];
        }else if ([status isEqualToString:@"201"]){
            [MBManager showBriefAlert:@"没有数据"];
        }
        
        
        //刷新数据
        [WeakSelf.mainTableView reloadData];
        
        [WeakSelf.mainTableView.mj_header endRefreshing];
        
        
        
    };
}

-(void)setHeadViewState:(NSDictionary *)dict{
    
    self.headView.logoUrl = self.storeInfoDict[@"s_logo"];
    self.headView.s_introduce = self.storeInfoDict[@"s_introduce"];
    self.headView.s_name = self.storeInfoDict[@"s_name"];
    
    self.group_id = [dict objectForKey:@"group_id"];
    
    GroupInfoModel *model = [GroupInfoModel objectWithDictionary:dict];
    self.headView.model = model;
    
//    NSString *Str = [NSString stringWithFormat:@"已拼 %@/ %@ 件, 人数共 %@人",dict[@"buy_number"],dict[@"group_number"],dict[@"user_number"]];
//    self.headView.groupStr = Str;
}

//去付款
-(void)payBtnClick{
    
    if (self.cartMutArray.count < 1) {
        [MBManager showError:@"购物车为空！"];
        return;
    }
    NSMutableArray *attribArr = [NSMutableArray array];
    for (GroupBuyAttrModel *model in self.cartMutArray) {
        if (model.number > 0) {
            
            NSMutableDictionary *dict = [NSMutableDictionary dictionary];
            dict[@"pro_id"] = @(model.pro_id);
            dict[@"attribute"] = model.pro_attrName;
            dict[@"number"] = @(model.number);
            [attribArr addObject:dict];
        }
    }
    
    NSString *jsonStr = [Utils jsonStrTransform:attribArr];
    
    NSMutableDictionary *parmrs = [NSMutableDictionary dictionary];
    parmrs[@"store_id"] = self.storeId;
    parmrs[@"group_id"] = self.group_id;
    parmrs[@"goods"] = jsonStr;
    
    GroupOrderSucceedCtl *Vc = [GroupOrderSucceedCtl new];
    Vc.params = parmrs;
    Vc.type = isGroup_Order;
    [self.navigationController pushViewController:Vc animated:YES];
}

-(void)popCarList{
    __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-55-kBottomMargeHeight)];
    float height = 70*self.cartMutArray.count+(kHeight(80));
    CartListView *whiteView = [[CartListView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height-55-kBottomMargeHeight, SCREEN_WIDTH, height) withObjects:self.cartMutArray];
    whiteView.backgroundColor = [UIColor whiteColor];
    
    self.coverV = coverV;
    whiteView.updateCartListBlock = ^{
        if (weakSelf.cartMutArray.count < 1) {
            [coverV dismissContactView];
        }
        [weakSelf count];
    };
    [coverV addSubview:whiteView];
    [coverV showView];

}
-(void)dealloc{
    NSLog(@"dealloc");
}


//  数组个数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return self.is_GroupDataArray.count;
    }else{
        return self.dataArray.count;
    }
}

#pragma mark ------- 数据源
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MyStoreCell *cell = [tableView dequeueReusableCellWithIdentifier:GroupBuyingId];
    
    // 重用
    if(cell == nil){
        cell = [[MyStoreCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:GroupBuyingId];
    }
    cell.delegate = self;
    if (indexPath.section == 0) {
        cell.model = self.is_GroupDataArray[indexPath.row];
    }else if (indexPath.section == 1){
        cell.model = self.dataArray[indexPath.row];
    }
    
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        if (self.dataArray.count > 0) {
            return 40;
        }
        
    }
    return 0;
    
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (section == 1) {
        if (self.dataArray.count > 0) {
            UIView *bgv = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
            bgv.backgroundColor= [UIColor colorWithHex:UI_COLOR_BGCOLOR];
            UILabel *label = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"未参与拼团的商品"];
            label.frame = CGRectMake(10, 0, 200, 40);
            [bgv addSubview:label];
            return bgv;
        }
        
    }
    return nil;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

-(void)ImageVClick:(MyStoreCell *)cell{
    NSIndexPath *indexPath = [self.mainTableView indexPathForCell:cell];
    MyStoreModel *model;
    if (indexPath.section == 0) {
        model = self.is_GroupDataArray[indexPath.row];
    }else if (indexPath.section == 1){
        model = self.dataArray[indexPath.row];
    }
   // MyStoreModel *model = self.dataArray[indexPath.row];
    
    XLPhotoBrowser *browser = [XLPhotoBrowser showPhotoBrowserWithImages:model.detail_img currentImageIndex:0];
    // 自定义pageControl的一些属性
    browser.pageDotColor = [UIColor grayColor];
    browser.currentPageDotColor = [UIColor redColor];
    browser.pageControlStyle = XLPhotoBrowserPageControlStyleClassic;
}

-(void)ProductPriceClick:(MyStoreCell *)cell WithType:(int)type{
    NSIndexPath *indexPath = [self.mainTableView indexPathForCell:cell];
    
    if (![LoginUtils isLogin]) { //未登录
        [Utils loginController:self];
    }else{
        [self popAttribsView:indexPath WithType:type];
    }
    
}

-(void)popAttribsView:(NSIndexPath *)indexPath WithType:(int)type{
    //__weak typeof (self)weakSelf = self;
   // MyStoreModel *model = self.dataArray[indexPath.row];
    MyStoreModel *model;
    if (indexPath.section == 0) {
        model = self.is_GroupDataArray[indexPath.row];
    }else if (indexPath.section == 1){
        model = self.dataArray[indexPath.row];
    }
    
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:self.view.bounds];
    float height = SCREEN_HEIGHT*0.6+(kHeight(30));
    GroupBuyAttrV *whiteView = [[GroupBuyAttrV alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height) withObjects:model.pro_attr isPayType:type WithDict:model];
    whiteView.closeView = ^{
        [coverV dismissContactView];
    };
     self.whiteView = whiteView;
    self.coverV = coverV;
    self.whiteView.delegete = self;
    
    [coverV addSubview:whiteView];
    [coverV showView];
}

#pragma mark --  GroupBuyAttrvDelegate
-(void)SeletedAttrSucceed:(NSArray *)numberArray WithStoreModel:(MyStoreModel *)storeModel WithType:(int)type{
    
    [self.coverV dismissContactView];
    
 
    if (type == 1 || type == 2) { //直接购买
        NSMutableArray *attribArr = [NSMutableArray array];
        for (GroupBuyAttrModel *model in numberArray) {
            if (model.number > 0) {
                
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                dict[@"pro_id"] = @(model.pro_id);
                dict[@"attribute"] = model.pro_attrName;
                dict[@"number"] = @(model.number);
                [attribArr addObject:dict];
            }
        }
        
        NSString *jsonStr = [Utils jsonStrTransform:attribArr];
        
        NSMutableDictionary *parmrs = [NSMutableDictionary dictionary];
        parmrs[@"store_id"] = @(storeModel.store_id);
        parmrs[@"goods"] = jsonStr;
        
        GroupOrderSucceedCtl *Vc = [GroupOrderSucceedCtl new];
       
        if (type == 1) {
            Vc.type = isOrder;
        }else if (type == 2){
            Vc.type = isGroup_Order;
            parmrs[@"group_id"] = self.group_id;
        }
         Vc.params = parmrs;
        [self.navigationController pushViewController:Vc animated:YES];
        
    }else if (type == 3){ //加入购物车
        
        for (GroupBuyAttrModel *model in numberArray) {
            if (model.number > 0) {
                if (self.cartMutArray.count!=0) {
                    
                    BOOL flage = YES;
                    for (GroupBuyAttrModel *model1 in self.cartMutArray) {
                        if (model1.pro_id == storeModel.pro_id && [model1.pro_attrName isEqualToString:model.pro_attrName]){
                            
                            model1.number += model.number;
                            flage = NO;
                            break;
                        }
                    }
                    if(flage){
                        [self.cartMutArray addObject:model];
                    }
                    
                }else{
                    
                    [self.cartMutArray addObject:model];
                }
            }
            
        }
        [self count]; //更新
        
    }

}

-(void)count{
    
    if (self.cartMutArray.count > 0) {
        self.footv.iconV.hidden = NO;
        self.footv.rangeLabel.hidden = NO;
        
        //self.footv.rangeLabel.text = [NSString stringWithFormat:@"%ld",self.cartMutArray.count];
        
        float totalPrice = 0.00;
        NSInteger count = 0;
        for (GroupBuyAttrModel *model in self.cartMutArray) {
            float price = model.number * [model.price floatValue];
            totalPrice +=price;
            count +=model.number;
        }
        self.footv.rangeLabel.text = [NSString stringWithFormat:@"%ld",count];
        self.footv.priceLabel.text = [NSString stringWithFormat:@"¥ %.2f",totalPrice];
    }else{
        self.footv.iconV.hidden = YES;
        self.footv.rangeLabel.hidden = YES;
        self.footv.priceLabel.text = @"¥ 0.00";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
