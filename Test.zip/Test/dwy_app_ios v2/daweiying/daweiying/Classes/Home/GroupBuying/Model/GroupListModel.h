//
//  GroupListModel.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/28.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"
@class GroupProModel;

@interface GroupListModel : BaseModel

/** 团号 */
@property(nonatomic,copy)NSString *group_id;
/** 团标题 */
@property(nonatomic,copy)NSString *group_title;
/** 团购人数 */
@property(nonatomic,copy)NSString *user_number;
/** 店铺名 */
@property(nonatomic,copy)NSString *s_name;
/** 店铺id */
@property(nonatomic,copy)NSString *s_id;
/** 团购总数 */
@property(nonatomic,copy)NSString *group_number;
/** 购买数 */
@property(nonatomic,copy)NSString *buy_number;
/** 创建时间 */
@property(nonatomic,copy)NSString *c_time;
/** model */
@property(nonatomic,strong)GroupProModel *goods;


@end

@interface GroupProModel : BaseModel

/** 创建时间 */
@property(nonatomic,copy)NSString *c_time;
/** 团购价 */
@property(nonatomic,copy)NSString *group_price;
/** 原价 */
@property(nonatomic,copy)NSString *price;
/** 商品名 */
@property(nonatomic,copy)NSString *pro_name;
/** 商品图片 */
@property(nonatomic,copy)NSString *pro_img;
/** 商品图片 */
//@property(nonatomic,strong)NSArray *detail_img;


@end
