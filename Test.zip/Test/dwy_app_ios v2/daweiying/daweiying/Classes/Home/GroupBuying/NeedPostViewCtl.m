//
//  NeedPostViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/22.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "NeedPostViewCtl.h"

@interface NeedPostViewCtl () 


@end


@implementation NeedPostViewCtl



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"需求发布";
    self.view.backgroundColor = [UIColor whiteColor];

    UIImageView *bgV = [[UIImageView alloc] initWithFrame:CGRectMake(20, 80, SCREEN_WIDTH-40, SCREEN_HEIGHT*0.7)];
    [bgV setImage:[UIImage imageNamed:@"demand_pic"]];
    [self.view addSubview:bgV];

    UILabel *label = [Utils labelTextColor:[UIColor orangeColor] fontSize:18 numberOfLines:1 text:@"页面正在开发中，敬请期待"];
    label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:label];
    label.sd_layout
    .topSpaceToView(bgV, 10)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(30);
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
