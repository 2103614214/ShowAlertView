//
//  GroupOrderModel.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/29.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface GroupOrderModel : BaseModel

/** pro_id */
@property(nonatomic,assign)int pro_id;
/** 团购价 */
@property(nonatomic,copy)NSString *group_price;
/** 正常价格 */
@property(nonatomic,copy)NSString *pro_price;
/** 商品名 */
@property(nonatomic,copy)NSString *pro_name;
/** 数量 */
@property(nonatomic,assign)NSInteger pro_number;
/** 商品图片 */
@property(nonatomic,copy)NSString *pro_img;
/** 商品属性 */
@property(nonatomic,copy)NSString *pro_attribute;
/** 单位 */
@property(nonatomic,copy)NSString *units;
/** 邮费类型 */
@property(nonatomic,assign)int postage_type;


@end
