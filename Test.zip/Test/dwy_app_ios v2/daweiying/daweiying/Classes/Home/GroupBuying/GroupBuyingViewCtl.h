//
//  GroupBuyingViewCtl.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"

@interface GroupBuyingViewCtl : BaseViewController

/** store_id */
@property(nonatomic,copy)NSString *storeId;
/** 团购标题 */
@property(nonatomic,copy)NSString *titleStr;

@end
