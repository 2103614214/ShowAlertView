//
//  GroupBuyAttrV.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyStoreModel;
@class GroupBuyAttrModel;

@protocol GroupBuyAttrvDelegate <NSObject>

-(void)SeletedAttrSucceed:(NSArray *)numberArray WithStoreModel:(MyStoreModel *)storeModel WithType:(int)type;
@end

@interface GroupBuyAttrV : UIView <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSMutableArray *objects;

@property(nonatomic,strong)MyStoreModel *dict;
/** 原价/拼团 */
@property(nonatomic,assign)int type;

@property (nonatomic,strong) UITableView *tableView;

@property(nonatomic,weak)UIButton *stockBtn;

@property(nonatomic,weak)UILabel *priceLabel;;
/** 关闭 */
@property(nonatomic,copy) void (^closeView)();

/** 属性选择确定代理 */
@property(nonatomic,assign)id<GroupBuyAttrvDelegate> delegete;

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSArray *)objects isPayType:(int)isPayType WithDict:(MyStoreModel *)dict;

@end
