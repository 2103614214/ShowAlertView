//
//  GroupOrderCell.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/29.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupOrderCell.h"
#import "GroupOrderModel.h"
@implementation GroupOrderCell
{
    UIImageView *_logV;
    UILabel *_nameLabel;
    UILabel *_AttrLabel;
    UILabel *_priceLabel;
    UILabel *_numberLabel;
    UILabel *_totalLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //初始化cell
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        UIView *bgV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(110))];
        bgV.backgroundColor = [UIColor colorWithHex:0xfafafa];
        [self.contentView addSubview:bgV];
        
        UIImageView *logV = [[UIImageView alloc] initWithFrame:CGRectMake(kWidth(10), kHeight(10), kWidth(90), kHeight(90))];
        [bgV addSubview:logV];
        _logV = logV;
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:0 text:@""];
        nameLabel.frame = CGRectMake(kWidth(110), kHeight(10), SCREEN_WIDTH-(kWidth(110)), kHeight(40));
        [bgV addSubview:nameLabel];
        _nameLabel = nameLabel;
        
        UILabel *AttrLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:0 text:@""];
        AttrLabel.frame = CGRectMake(kWidth(110), kHeight(50), SCREEN_WIDTH-(kWidth(110)), kHeight(20));
        [bgV addSubview:AttrLabel];
        _AttrLabel = AttrLabel;
        
        
        UILabel *priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:0 text:@""];
        priceLabel.frame = CGRectMake(kWidth(110), kHeight(80), kWidth(110), kHeight(20));
        [bgV addSubview:priceLabel];
        _priceLabel = priceLabel;
        
        UILabel *numberLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:0 text:@""];
        numberLabel.frame = CGRectMake(SCREEN_WIDTH-(kWidth(150)), kHeight(80), kWidth(140), kHeight(20));
        numberLabel.textAlignment = NSTextAlignmentRight;
        [bgV addSubview:numberLabel];
        _numberLabel = numberLabel;
        
        UILabel *totalLabel = [Utils labelTextColor:[UIColor orangeColor] fontSize:14 numberOfLines:0 text:@""];
        [bgV addSubview:totalLabel];
        totalLabel.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:totalLabel];
        totalLabel.sd_layout
        .topSpaceToView(bgV, 0).xIs(0).widthIs(SCREEN_WIDTH-(kWidth(10))).heightIs(kHeight(40));
        _totalLabel = totalLabel;
    }
    return self;
}

-(void)setModel:(GroupOrderModel *)model{
    _model = model;
    [_logV sd_setImageWithURL:[NSURL URLWithString:model.pro_img] placeholderImage:[UIImage imageNamed:placeImageName]];
    
    _nameLabel.text = model.pro_name;
    _AttrLabel.text = model.pro_attribute;
    NSString *strPrice;
    if (self.type == 1) {
        strPrice = model.pro_price;
    }else{
        strPrice = model.group_price;
    }
    _priceLabel.text = [NSString stringWithFormat:@"¥%@/%@",strPrice,model.units];
    _numberLabel.text = [NSString stringWithFormat:@"x %ld%@",model.pro_number,model.units];
    float totalPrie = model.pro_number * [strPrice floatValue];
    _totalLabel.text = [NSString stringWithFormat:@"总共 ¥%.2f",totalPrie];
}

-(void)setType:(int)type{
    _type = type;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
