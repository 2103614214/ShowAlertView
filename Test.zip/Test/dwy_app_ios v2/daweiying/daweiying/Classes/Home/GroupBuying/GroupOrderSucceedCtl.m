//
//  GroupOrderSucceedCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/29.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupOrderSucceedCtl.h"
#import "GroupOrderCell.h"
#import "GroupOrderModel.h"
#import "NSObject+Property.h"

#import "DWYAffirmHeadView.h"
#import "DWYManageAddressCtl.h"
#import "ShowAnimationView.h"
#import "ConfirmPayView.h"
#import "WeChatManager.h"
#import "PayTypeView.h"
#import "PayPasswordViewCtl.h"
#import "OrderManager.h"

#import <WXApi.h>
#import "OrderCountCtl.h"
@interface GroupOrderSucceedCtl () <UITableViewDelegate,UITableViewDataSource,sendAddressDelegate>

/** talbeview */
@property(nonatomic,strong)UITableView *tableView;
// 数据源
@property (nonatomic, strong) NSMutableArray *dataArray;
/** 总价 */
@property(nonatomic,weak)UILabel *priceLabel;
/** 立即支付 */
@property(nonatomic,weak)UIButton *payBtn;
/** 店铺名 */
@property(nonatomic,copy)NSString *storeName;
/** headView */
@property(nonatomic,strong)DWYAffirmHeadView *headView;
/** 地址主键id */
@property(nonatomic,copy)NSString *addressID;
/** 总价 */
@property(nonatomic,copy)NSString *totalPrice;
/** 支付方式 */
@property(nonatomic,copy)NSString *payStr;
/** 保存订单号 */
@property(nonatomic,copy)NSString *tempOrderNumber;

/** 邮费 */
@property(nonatomic,copy)NSString *total_freight;
/** 邮费类型 */
@property(nonatomic,assign)int freight_status;

/** 分享 */
@property(nonatomic,strong)NSDictionary *shareDict;
@end

static NSString * const GroupOrderSucceedId = @"GroupOrderSucceedId";
@implementation GroupOrderSucceedCtl

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"确认订单";
    
    self.addressID = [appDelegate.appDefault objectForKey:@"address_id"];
   
    
    //  添加 主tableView
    __weak typeof (self)weakSelf = self;
    self.headView = [[DWYAffirmHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(81))];
    //添加tap
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) { //跳转地址选择
        
        DWYManageAddressCtl *address  = [DWYManageAddressCtl new];
        address.delegate = weakSelf;
        [weakSelf.navigationController pushViewController:address animated:YES];
        
    }];
    [self.headView.addressView addGestureRecognizer:tap];
    
    //  添加tableView
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 55-kBottomMargeHeight) style:UITableViewStyleGrouped];
    //设置背景色
    self.tableView.backgroundColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR];
    // tableView多余cell空白
    self.tableView.tableFooterView = [[UIView alloc]init];
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        _tableView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, 0, 0);
        _tableView.scrollIndicatorInsets = _tableView.contentInset;
    }
    self.tableView.tableHeaderView = self.headView;
    self.tableView.rowHeight = kHeight(150);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle =  UITableViewCellSeparatorStyleNone;
    // 注册 重用名
    [self.tableView registerClass:[GroupOrderCell class] forCellReuseIdentifier:GroupOrderSucceedId];
    [self.view addSubview: self.tableView];
    
    [self setupFootViewSubViews];
    
    //  网络请求
    [self MJRequestData];
    
    //payWXSuccess
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"payWXSuccess" object:nil] subscribeNext:^(NSNotification *notification) {
        
        //NSLog(@"%@",weakSelf.payStr);
        if ([weakSelf.payStr isEqualToString:@"微信支付"]) {
            OrderCountCtl *vc = [[OrderCountCtl alloc] init];
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }
    
        if (weakSelf.type == isGroup_Order) {
             [weakSelf getShareInfo];
        }
       
    }];
    
    //支付失败
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"fujiaPayFail" object:nil] subscribeNext:^(NSNotification *notification) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            OrderCountCtl *vc = [[OrderCountCtl alloc] init];
            vc.jumpType = 1;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
        
    }];
    
}

-(void)dealloc{
    NSLog(@"确认订单");
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)getShareInfo{
    
    id storeId = [appDelegate.appDefault objectForKey:@"store_id"];
    NSDictionary *parameters = @{ @"store_id":storeId};
    //网络请求
    NSString *urlString = [Utils V2GetMemberLoginUrl:@"store_share"];
    
    __weak typeof (self)weakSelf = self;
    [super PostRequsetDataUrlString:urlString Parameters:parameters];
    self.PostSuccess=^(id responseObject){
        //解析
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
            id dataObjct = [responseObject objectForKey:@"data"];
            weakSelf.shareDict = [dataObjct objectForKey:@"share"];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf shareBtnClick];
            });
            
            
        }else{
            [MBManager showError:hint];
        }
        
    };
    
}

//分享
-(void)shareBtnClick{
    
    [WeChatManager sharePaySuccessClick:self.view.bounds WithDict:self.shareDict];
    
}



-(void)setupFootViewSubViews{
    UIView *bgV = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-55-kBottomMargeHeight, SCREEN_WIDTH, kHeight(55))];
    bgV.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:bgV];
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [bgV addSubview:line];
    
    UIButton *payBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [payBtn setTitle:@"立即付款" forState:0];
    payBtn.frame = CGRectMake(SCREEN_WIDTH-(kWidth(100)), 1, kWidth(100), 54);
    [payBtn setTitleColor:[UIColor whiteColor] forState:0];
    payBtn.backgroundColor = [UIColor colorWithHex:0xcccccc];
    [payBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xdd6500]] forState:UIControlStateHighlighted];
    payBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [payBtn addTarget:self action:@selector(payBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [bgV addSubview:payBtn];
    self.payBtn = payBtn;
    
    UILabel *priceLabel = [Utils labelTextColor:[UIColor orangeColor] fontSize:18 numberOfLines:1 text:@""];
    priceLabel.frame = CGRectMake(0, 1, SCREEN_WIDTH-(kWidth(120)), 54);
    priceLabel.textAlignment = NSTextAlignmentRight;
    [bgV addSubview:priceLabel];
    self.priceLabel = priceLabel;
    
    if ([self.addressID integerValue] > 0) {
        payBtn.backgroundColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
    }
}

-(void)payBtnClick{
 
    if ([self.addressID floatValue] >0) {
        
         [self confirmPayType];
        
    }else{
        [MBManager showError:@"请选择收货地址"];
        return;
    }
}

#pragma mark - 确认付款
-(void)confirmPayType{ //130 100
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:@"isGroup" forKey:@"pathwayType"];
    [ud synchronize];
    
    __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:self.view.bounds];
    //装载商品信息的视图
    float height = 2*(kHeight(50))+(kHeight(230));
    ConfirmPayView *whiteView = [[ConfirmPayView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height) WithStr:@"钱包余额" WithPrice:self.totalPrice];
    whiteView.closeView = ^{
        [coverV dismissContactView];
        
    };
    //支付
    whiteView.payBlock = ^(NSString *payType) {
        [coverV dismissContactView];
        weakSelf.payStr = payType;
        if (weakSelf.type == isOrder) { //普通购买
            [weakSelf putOrderWithGoods];
            
        }else if (weakSelf.type == isGroup_Order){ //团购
            
            [weakSelf putOrderWithCart];
        }
    };
    [coverV addSubview:whiteView];
    [coverV showView];
}


#pragma mark - 商品结算---从商品页直接跳转，直接买单
-(void)putOrderWithGoods{

    [MBManager showLoadingInView:self.view];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"goods"] = self.params[@"goods"];
    params[@"address_id"] = self.addressID;
    params[@"store_id"] = self.params[@"store_id"];

    NSString *urlStr = [Utils V2GetMemberServiceUrl:@"common_order"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSString *orderNum = [dataObject objectForKey:@"o_number"];

            self.tempOrderNumber = orderNum;
            if ([self.payStr isEqualToString:@"钱包余额"]) {
                //余额
                [self PayType:orderNum];
            }else if ([self.payStr isEqualToString:@"微信支付"]){
                //发起微信支付
                [WeChatManager sendWechatPay:self.totalPrice WithOrderNum:orderNum];
            }
            
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        // NSLog(@"%@",error);
        [MBManager showError];
    }];
    
}

#pragma mark - 购物车结算---从购物车页直接跳转
-(void)putOrderWithCart{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    params[@"group_id"] = self.params[@"group_id"];
     params[@"store_id"] = self.params[@"store_id"];
    params[@"address_id"] = self.addressID;
    params[@"goods"] = self.params[@"goods"];
    
    NSString *urlStr = [Utils V2GetMemberServiceUrl:@"create_order"];
 
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSString *orderNum = [dataObject objectForKey:@"o_number"];
            self.tempOrderNumber = orderNum;

            if ([self.payStr isEqualToString:@"钱包余额"]) {
                //余额，
                [self PayType:orderNum];

            }else if ([self.payStr isEqualToString:@"微信支付"]){
                //发起微信支付
                [WeChatManager sendWechatPay:self.totalPrice WithOrderNum:orderNum];
            }
        }else{
            [MBManager showError:hint];
        }
        
    } failure:^(NSError * _Nonnull error) {
        //NSLog(@"%@",error);
        [MBManager showError];
    }];
    
}



//钱包余额，
-(void)PayType:(NSString *)orderNum{

    __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:self.view.bounds];
    //装载商品信息的视图
    //NSString *payStr = @"付甲一方";
    float height = (kHeight(170))+216;
    PayTypeView *whiteView = [[PayTypeView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    whiteView.closeBtnBlock = ^{
        [coverV dismissContactView];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            for (UIViewController *controller in weakSelf.navigationController.viewControllers) {
//                if ([controller isKindOfClass:[MainTabBarController class]]) {
//                    [weakSelf.navigationController popToViewController:controller animated:YES];
//                }
//            }
            OrderCountCtl *vc = [[OrderCountCtl alloc] init];
            vc.jumpType = 1;
            [weakSelf.navigationController pushViewController:vc animated:YES];
            
        });
    };
    //忘记密码
    whiteView.forgetBtnBlock = ^{
        [coverV dismissContactView];
 
        PayPasswordViewCtl *vc = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });

    };
    whiteView.inputView.inputFinish = ^(NSString *pwd) { //输入正确
        [coverV dismissContactView];
        //weakSelf.signStr = pwd;  // 保存支付签名

        [OrderManager Wallet:weakSelf.totalPrice WithSign:pwd WithOrderNum:orderNum WithController:weakSelf];

    };
    whiteView.inputView.forgetBtnBlock = ^{
        [coverV dismissContactView];

        PayPasswordViewCtl *vc = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
    };
    [coverV addSubview:whiteView];
    [coverV showView];

}



// 请求数据
- (void)MJRequestData{

    __weak typeof(self) WeakSelf = self;
    
    //网络请求
    NSString *urlString ;
    if (self.type == isOrder) {
        urlString  = [Utils V2GetMemberServiceUrl:@"orders"];
    }else{
        urlString = [Utils V2GetMemberServiceUrl:@"comfirm_order"];
    }
   
    //NSLog(@"%@",self.params);
    [super PostRequsetDataUrlString:urlString Parameters:self.params];
    self.PostSuccess=^(id responseObject){
        //解析
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            id dataObjct = [responseObject objectForKey:@"data"];
            NSString *price = [dataObjct objectForKey:@"total_money"];
            WeakSelf.totalPrice = price;
            WeakSelf.total_freight = [dataObjct objectForKey:@"total_freight"];
            WeakSelf.freight_status = [[dataObjct objectForKey:@"freight_status"]intValue];
            NSMutableAttributedString *bString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"合计: ¥ %@",price]];
            [bString
             addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12]range:NSMakeRange(0, 3
                                                                                                  )];
            [bString
             addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor]range:NSMakeRange(0, 3
                                                                                                  )];
            WeakSelf.priceLabel.attributedText = bString;
            WeakSelf.storeName = [dataObjct objectForKey:@"store_name"];
            NSArray *rootArray = dataObjct[@"goods"];
            for (NSDictionary *dic in rootArray) {
                
                GroupOrderModel *model = [GroupOrderModel objectWithDictionary:dic];
                //处理数据，转模型之类的
                [WeakSelf.dataArray addObject:model];
                
            }
        //刷新数据
        [WeakSelf.tableView reloadData];
        }else{
            [MBManager showError:hint];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [WeakSelf.navigationController popViewControllerAnimated:YES];
            });
        }
        
    };
}

//  数组个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

#pragma mark ------- 数据源
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    GroupOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:GroupOrderSucceedId];
    
    // 重用
    if(cell == nil){
        cell = [[GroupOrderCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:GroupOrderSucceedId];
    }
   
    if (self.type == isOrder) {
        cell.type = 1;
    }else{
        cell.type = 2;
    }
    cell.model = self.dataArray[indexPath.row];
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return kHeight(50);
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return kHeight(40);
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(50))];
    
    UIView *bgV = [[UIView alloc] initWithFrame:CGRectMake(0, kHeight(10), SCREEN_WIDTH, kHeight(40))];
    bgV.backgroundColor = [UIColor whiteColor];
    [headV addSubview:bgV];
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(kWidth(10), kHeight(10), kWidth(20), kHeight(20))];
    image.image = [UIImage imageNamed:@"list_icon_store_15_15"];
    [bgV addSubview:image];
    
    UILabel *label = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:self.storeName];
    label.frame = CGRectMake(kWidth(40), 0, kWidth(180), kHeight(40));
    [bgV addSubview:label];
    
    return headV;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *footV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(40))];
    footV.backgroundColor = [UIColor whiteColor];
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [footV addSubview:line];
    
    UILabel *label = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@"运费"];
    label.frame = CGRectMake(kWidth(10), 0, kWidth(100), kHeight(40));
    [footV addSubview:label];
    
    NSString *freightStr;
    if (self.freight_status == 1) {
        freightStr = [NSString stringWithFormat:@"邮费(%@,部分到付)",self.total_freight];
    }else{
        freightStr = [NSString stringWithFormat:@"邮费(%@)",self.total_freight];
    }
    UILabel *freightLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:freightStr];
    freightLabel.textAlignment = NSTextAlignmentRight;
    freightLabel.adjustsFontSizeToFitWidth = YES;
    freightLabel.frame = CGRectMake(SCREEN_WIDTH-(kWidth(210)), 0, kWidth(200), kHeight(40));
    [footV addSubview:freightLabel];
    
    return footV;
}

#pragma mark -- 地址回调代理方法
-(void)sendMessage:(NSString *)Name withTel:(NSString *)tel WithAddress:(NSString *)adddress WithID:(int)addressID{
    self.headView.placeLabel.hidden = YES;
    self.headView.nameLabel.text = Name;
    self.headView.telLabel.text = tel;
    self.headView.addressLabel.text = adddress;
    self.addressID = NSStringFormat(@"%d",addressID);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
