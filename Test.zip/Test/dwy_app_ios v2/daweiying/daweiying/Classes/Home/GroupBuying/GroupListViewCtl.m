//
//  GroupListViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/23.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GroupListViewCtl.h"
#import "GroupListCell.h"
#import "CreateGroupViewCtl.h"
#import "GroupBuyingViewCtl.h"
#import "GroupListModel.h"
#import "NSObject+Property.h"
#import "LoginUtils.h"
#import "ApplyStoreViewCtl.h"
#import "MyStoreViewCtl.h"
@interface GroupListViewCtl () <UITableViewDelegate,UITableViewDataSource,GroupListCellDelegate>


//  数据数组
@property (nonatomic, strong) NSMutableArray *dataArray;

//  上拉、下拉   页码
@property (nonatomic, assign)NSInteger pageIndex;


/** 是否开团 */
@property(nonatomic,assign)int user_group_status;

@end

static NSString * const GroupListId = @"GroupListId";
@implementation GroupListViewCtl

- (NSMutableArray *)dataArray{
    if (_dataArray == nil){
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"拼团采购";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"发团" style:UIBarButtonItemStylePlain target:self action:@selector(sendGroup)];
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
    
    // 初始值  通过修改该数组来增加请求数
    self.pageIndex = 1;
    
    //  添加  下拉  上拉
    __weak typeof(self) WeakSelf = self;
    [self createMJRefresh:isAll actionBlock:^{
        [WeakSelf MJRequestData];
    }];
    
    
    //  网络请求
    [self MJRequestData];
    
    
    //  添加 主tableView
    self.mainTableView.rowHeight = 175;
    self.mainTableView.delegate = self;
    self.mainTableView.dataSource = self;
    // 注册 重用名
    [self.mainTableView registerClass:[GroupListCell class] forCellReuseIdentifier:GroupListId];
    [self.view addSubview: self.mainTableView];
    
    
    //通知
    __weak typeof (self)weakSelf = self;
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"setupSendGroupData" object:nil] subscribeNext:^(NSNotification *notification) {
        [weakSelf MJRequestData];
    }];
}

-(void)dealloc{
    NSLog(@"----dealloc");
}

//发团
-(void)sendGroup{
    
    if (![LoginUtils isLogin]) { //未登录
        
        [Utils loginController:self];
        
    }else{ //登录
        id storeId = [appDelegate.appDefault objectForKey:@"store_id"];
        
        
        if (self.user_group_status == 0) { //无发团
            CreateGroupViewCtl *vc = [CreateGroupViewCtl new];
            vc.storeId = [NSString stringWithFormat:@"%@",storeId];
            [self.navigationController pushViewController:vc animated:YES];
        }else if (self.user_group_status == 1){  //无店铺

            [MBManager showBriefAlert:@"您有进行中的团购"];
        }
        
      
    }
    

}

//  mj 请求数据
- (void)MJRequestData{
    if (self.judge == 10) {
        // 下拉时 清空数据数组 重新请求添加
        self.pageIndex = 1;
        
    } else if (self.judge == 11){
        // 上拉时  数组中添加内容
        self.pageIndex++;
    }
    __weak typeof(self) weakSelf = self;
    
    //转换一下
    NSString *Number = [NSString stringWithFormat:@"%ld",(long)self.pageIndex];
    
    NSDictionary *parameters = @{@"page": Number, @"pageSize":@"10"};
    
    //网络请求
    NSString *urlString;
    if ([LoginUtils isLogin]) {
         urlString = [Utils V2GetMemberServiceUrl:@"group_list"];
    }else{
        urlString = [Utils V2GetMemberLoginUrl:@"group_list"];
    }
    
    [super PostRequsetDataUrlString:urlString Parameters:parameters];
    self.PostSuccess=^(id responseObject){
    
        //下拉刷新清空数据
        if (weakSelf.judge == 10) {
            [weakSelf.dataArray removeAllObjects];
        }
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        if ([status isEqualToString:@"200"]) {
            
           
             id dataObjct = [responseObject objectForKey:@"data"];
            weakSelf.user_group_status = [dataObjct[@"user_group_status"] intValue];
            //解析
            NSArray *rootArray = dataObjct[@"list"];
            for (NSDictionary *dict in rootArray) {
                
                GroupListModel *model = [GroupListModel objectWithDictionary:dict];
                [weakSelf.dataArray addObject:model];
                
            }
            
            if (rootArray.count == 0) {
                // 为零时 实现没有更多数据
                [weakSelf.mainTableView.mj_footer endRefreshingWithNoMoreData];
            } else {
                [weakSelf.mainTableView.mj_footer endRefreshing];
            }
            if (weakSelf.dataArray.count > 0) {
                 [weakSelf.mainTableView hideBlankPageView];
            }else{
                 [weakSelf.mainTableView showBlankPageView:12];
            }
           
        }else if ([status isEqualToString:@"201"]){
            
            [weakSelf.mainTableView.mj_footer endRefreshingWithNoMoreData];
        }
        //刷新数据
        [weakSelf.mainTableView reloadData];
        
        [weakSelf.mainTableView.mj_header endRefreshing];
        
        
    };
}



//  数组个数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

#pragma mark ------- 数据源
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    GroupListCell *cell = [tableView dequeueReusableCellWithIdentifier:GroupListId];
    
    // 重用
    if(cell == nil){
        cell = [[GroupListCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:GroupListId];
    }
    cell.delegate = self;
    cell.model = self.dataArray[indexPath.section];
    
   
    return cell;
    
}

#pragma mark - GroupListCellDelegate
-(void)GroupListCellClick:(GroupListCell *)cell{
    NSIndexPath *indexPath = [self.mainTableView indexPathForCell:cell];
    
    GroupListModel *model = self.dataArray[indexPath.section];
    id storeId = [appDelegate.appDefault objectForKey:@"store_id"];
    if ([model.s_id intValue] == [storeId intValue]) { //自己店铺
        MyStoreViewCtl *vc = [MyStoreViewCtl new];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        GroupBuyingViewCtl *vc = [GroupBuyingViewCtl new];
        vc.storeId = model.s_id;
        vc.titleStr = model.group_title;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];


}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *bgv = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
    return bgv;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
