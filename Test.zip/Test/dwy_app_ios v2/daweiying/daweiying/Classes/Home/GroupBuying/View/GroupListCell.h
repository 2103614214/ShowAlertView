//
//  GroupListCell.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/23.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class GroupListModel;
@class GroupListCell;

@protocol GroupListCellDelegate <NSObject>

-(void)GroupListCellClick:(GroupListCell *)cell;

@end

@interface GroupListCell : UITableViewCell

/** model */
@property(nonatomic,strong)GroupListModel *model;


@property(nonatomic,weak)id <GroupListCellDelegate> delegate;

@end
