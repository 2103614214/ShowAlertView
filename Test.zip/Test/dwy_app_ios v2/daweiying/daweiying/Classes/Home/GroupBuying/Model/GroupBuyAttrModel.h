//
//  GroupBuyAttrModel.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/28.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface GroupBuyAttrModel : BaseModel


@property(nonatomic,copy)NSString *pro_attrName;
/** 数量 */
@property(nonatomic,assign)NSInteger number;

/** 标识 */
//@property(nonatomic,assign)int isSelected;

//单位
@property(nonatomic,copy)NSString *units;
//价格
@property(nonatomic,copy)NSString *price;

/** 商品名 */
@property(nonatomic,copy)NSString *pro_name;
/** pro_id */
@property(nonatomic,assign)int pro_id;

@end



////购物车
//@interface CartBuyAttrModel : BaseModel
//
//
//@property(nonatomic,copy)NSString *pro_attrName;
///** 数量 */
//@property(nonatomic,assign)NSInteger number;
////单位
//@property(nonatomic,copy)NSString *units;
////价格
//@property(nonatomic,copy)NSString *price;
//
///** 商品名 */
//@property(nonatomic,copy)NSString *pro_name;
///** pro_id */
//@property(nonatomic,assign)int pro_id;
////store_id
////@property(nonatomic,assign)int store_id;
//
////-(instancetype)initWithDic:(NSDictionary *)dic;
//
//@end

