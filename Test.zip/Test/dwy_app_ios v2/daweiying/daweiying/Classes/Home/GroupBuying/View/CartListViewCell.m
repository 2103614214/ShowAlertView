//
//  CartListViewCell.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/26.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CartListViewCell.h"
#import "GroupBuyAttrModel.h"

@implementation CartListViewCell
{
    UILabel *_nameLabel;
    UILabel *_attrLabel;
    UILabel *_numberLabel;
    UILabel *_priceLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
        nameLabel.frame = CGRectMake(kWidth(10), kHeight(10), kWidth(150), kHeight(30));
        [self.contentView addSubview:nameLabel];
        _nameLabel = nameLabel;
        
        UILabel *attrLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:@""];
        attrLabel.frame = CGRectMake(kWidth(10), kHeight(40), kWidth(150), kHeight(20));
        [self.contentView addSubview:attrLabel];
        _attrLabel = attrLabel;
        
        UILabel *numberLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@""];
        numberLabel.frame = CGRectMake(kWidth(170), 0, kWidth(100), kHeight(70));
        numberLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:numberLabel];
        _numberLabel = numberLabel;
        
        UILabel *priceLabel = [Utils labelTextColor:[UIColor orangeColor] fontSize:14 numberOfLines:1 text:@""];
        priceLabel.textAlignment = NSTextAlignmentCenter;
        priceLabel.frame = CGRectMake(kWidth(270), 0, SCREEN_WIDTH-(kWidth(270)), numberLabel.height);
        [self.contentView addSubview:priceLabel];
        _priceLabel = priceLabel;
    }
    return self;
}

-(void)setModel:(GroupBuyAttrModel *)model{
    _model = model;
    _nameLabel.text = model.pro_name;
    _attrLabel.text = model.pro_attrName;
    _numberLabel.text = [NSString stringWithFormat:@"%ld%@",model.number,model.units];

    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"¥%@",model.price]];
    [aString
     addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:10]range:NSMakeRange(0, 1
                                                                                          )];
    _priceLabel.attributedText = aString;
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
