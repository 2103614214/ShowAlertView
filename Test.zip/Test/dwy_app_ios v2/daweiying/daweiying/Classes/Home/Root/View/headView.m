//
//  headView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/15.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "headView.h"
#import "UISearchBar+SearchBarPlaceholder.h"

@interface headView() <UISearchBarDelegate>



@end

@implementation headView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];
    
    __weak typeof (self)weakSelf = self;
    //创建一个View,把地区名跟下拉图标包起
//    UIView *areaView = [UIView new];
//    areaView.frame = CGRectMake(0, 0, self.width/5, self.height);
////    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
////    [[tap rac_gestureSignal] subscribeNext:^(id x) {
////        //定位跳转
////        self.locationBlock();
////    }];
////    [areaView addGestureRecognizer:tap];
//    [self addSubview:areaView];
    
    //地区名
    NSString *cityStr = [appDelegate.appDefault objectForKey:@"currentCity"];
    _areaLabel = [UILabel new];
    _areaLabel.text = [Utils getString:@"currentCity"];
    _areaLabel.font = [UIFont systemFontOfSize:14.0f];
    _areaLabel.adjustsFontSizeToFitWidth = YES;
    _areaLabel.text = cityStr;
    _areaLabel.frame = CGRectMake(kWidth(5), 0, kWidth(60), self.height);
    _areaLabel.textColor = [UIColor whiteColor];
    _areaLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *locationTap = [[UITapGestureRecognizer alloc] init];
    [[locationTap rac_gestureSignal] subscribeNext:^(id x) {
        //定位跳转
        self.locationBlock();
    }];
    [_areaLabel addGestureRecognizer:locationTap];
    _areaLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_areaLabel];

//    UIImage *image = [UIImage imageNamed:@"homepage_btn_bottom_13_9"];
//    UIImageView *pullDown = [[UIImageView alloc] initWithImage:image];
//    [areaView addSubview:pullDown];
//    pullDown.sd_layout
//    .topSpaceToView(areaView, 15)
//    .leftSpaceToView(_areaLabel, 2)
//    .widthIs(15)
//    .heightIs(15);
//    _imageDown = pullDown;
    
    
    UIButton *saoBtn = [UIButton new];
    [saoBtn setImage:[UIImage imageNamed:@"homepage_btn_scan_20_20"] forState:0];
    [[saoBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        //打开扫码页
        weakSelf.scanCodeBlock();
    }];
    [self addSubview:saoBtn];
    saoBtn.sd_layout
    .topSpaceToView(self, 5)
    .rightSpaceToView(self, 5)
    .widthIs(30)
    .heightIs(30);
    _saoBtn = saoBtn;
    
    UIView *searchBarV = [[UIView alloc] initWithFrame:CGRectMake(kWidth(65), 5, SCREEN_WIDTH-saoBtn.width-(kWidth(70)), 30)];
    searchBarV.backgroundColor = [UIColor whiteColor];
    searchBarV.hidden = YES;
    searchBarV.userInteractionEnabled = YES;
    searchBarV.layer.cornerRadius = 10;
    [self addSubview:searchBarV];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        //搜索
        weakSelf.searchBlock();
    }];
    [searchBarV addGestureRecognizer:tap];
    
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"3chat_icon_search_20_20"]];
    imageV.frame = CGRectMake(kWidth(10), 5, 20, 20);
    [searchBarV addSubview:imageV];
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"商品名称"];
    remarkLabel.frame = CGRectMake(CGRectGetMaxX(imageV.frame)+10, 5, 100, 20);
    [searchBarV addSubview:remarkLabel];
    
    //搜索
//    _searchBar = [[UISearchBar alloc] init];
//    _searchBar.keyboardType =UIKeyboardTypeNumbersAndPunctuation;
//    [_searchBar changeLeftPlaceholder:@"商品名称"];
//    UIImage* searchBarBg = [self GetImageWithColor:[UIColor clearColor] andHeight:32.0f];
//    [_searchBar setBackgroundImage:searchBarBg];
//    _searchBar.delegate = self;
//    [self addSubview:_searchBar];
//    _searchBar.sd_layout
//    .xIs(kWidth(15))
//    .yIs(0)
//    .widthIs(self.width-saoBtn.width-(kWidth(20)))
//    .heightIs(35);
    
    
}

-(void)setLocationStr:(NSString *)locationStr{
    _locationStr = locationStr;
    
    _areaLabel.text = _locationStr;
}

#pragma mark 实现搜索条背景透明化

- (UIImage*) GetImageWithColor:(UIColor *)color andHeight:(CGFloat)height{
    
    CGRect r= CGRectMake(0.0f, 0.0f, 1.0f, height);
    
    UIGraphicsBeginImageContext(r.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    
    CGContextFillRect(context, r);
    
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
