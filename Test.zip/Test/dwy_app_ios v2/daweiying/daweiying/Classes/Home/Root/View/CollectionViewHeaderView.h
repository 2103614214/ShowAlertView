//
//  CollectionViewHeaderView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <SDCycleScrollView.h>
#import "categoryView.h"
#import "hotSellView.h"
#import "selectionView.h"
#import "generalizeView.h"
#import "headView.h"

@protocol imageViewClickDelegate <NSObject>

// 头部view点击事件
- (void)ViewTapClick:(NSString *)type WithModel:(storeModel *)model;

//分类点击
- (void)ViewTapClick:(NSString *)type WithTag:(NSInteger)tag;

//广告图点击
-(void)AdClickIndex:(NSInteger)index;

//点击分类头部
-(void)titleLabelClick:(NSInteger)tag;
@end

@interface CollectionViewHeaderView : UICollectionReusableView

@property (nonatomic,weak) id<imageViewClickDelegate> delegate;


/** 轮播图 */
@property(nonatomic,strong)SDCycleScrollView *cycleScrollView;
/** 分类 */
@property(nonatomic,strong)categoryView *categoryView;
/** 热销 */
@property(nonatomic,strong)hotSellView *hotSell;
/** 精选 */
@property(nonatomic,strong)selectionView *selectionView;
/** 推选 */
@property(nonatomic,strong)hotSellView *chooseView;
/** 品牌推广 */
@property(nonatomic,strong)generalizeView *generalizeView;
/** 顶部视图 */
@property(nonatomic,strong)headView *headView;
/** 全国特选 */
@property(nonatomic,strong)chanceView *chanceV;

/** 轮播广告数据源 */
@property(nonatomic,strong)NSArray *dataArray;


@end
