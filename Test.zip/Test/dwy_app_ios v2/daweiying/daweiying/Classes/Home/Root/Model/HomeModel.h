//
//  HomeModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>


//商品
@interface HomeModel : NSObject

@property (nonatomic,copy) NSString *logo_url; //图片
@property (nonatomic,copy) NSString *pro_name; //商品名称
@property(nonatomic,copy)NSString *price;  //价格
@property(nonatomic,assign)int store_id;  //商家id
@property(nonatomic,assign)int pro_id;  //商品id
@property(nonatomic,assign)int type;  //商品属于哪种店铺类型
/** 销量 */
@property(nonatomic,copy)NSString *sell_number;

@end

//品牌推广
@interface storeModel : NSObject

@property (nonatomic,copy) NSString *t_img_url; //图片
@property (nonatomic,copy) NSString *t_name; //名
@property(nonatomic,assign)int t_type; //类型
@property(nonatomic,copy)NSString *t_introduce; //简介
@property(nonatomic,assign)int t_column;
@property(nonatomic,assign)int t_pro_id; //商品id

@end

//分类
@interface catetorysModel : NSObject

@property (nonatomic,copy) NSString *cate_url; //图片
@property (nonatomic,copy) NSString *cate_name;
@property(nonatomic,assign)int cate_id;  //分类id号
@property(nonatomic,assign)int type;  //类型
@end

//轮播图广告
@interface AdvModel : NSObject

@property (nonatomic,copy) NSString *b_introduce;
@property (nonatomic,copy) NSString *b_logo; //图片
@property (nonatomic,copy) NSString *b_name;
@property(nonatomic,assign)int b_id;  //广告id号
@property(nonatomic,assign)int type;

//0或6时，网页链接
@property (nonatomic,copy) NSString *type_value;

/** 分享标题 */
@property(nonatomic,copy)NSString *share_title;
//url
@property(nonatomic,copy)NSString *share_url;
//内容
@property(nonatomic,copy)NSString *share_content;

@end


