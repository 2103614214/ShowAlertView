//
//  HomeViewController.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "HomeViewController.h"
#import "headView.h"
#import "HomeModel.h"

#import "publicCollectionViewCell.h"
#import "publicCollectionFlowLayout.h"
#import "CollectionViewHeaderView.h"

#import "AppDelegate.h"
//定位信息
#import "WLLocation.h"
#import "WLAreaDataManager.h"
#import "WLCityViewController.h"

//相机授权
#import <AVFoundation/AVFoundation.h>
#import "SGQRCodeScanningVC.h"

#import "RetailViewCtl.h"
#import "StoreViewCtl.h"
#import "DWYDetailsViewCtl.h"
#import "DWYServiceCtl.h"

#import "CompanyMakeCtl.h"

#import "PYSearch.h"
#import "SearchResultViewController.h"

#import "RetailCategoryCtl.h"
#import "IssueRetailProViewtl.h"
#import "InviteViewCtl.h"
#import "ApplyFujiaViewCtl.h"
#import "DWYDetailsViewCtl.h"
#import "CompanyMakeViewCtl.h"
#import "RetailListViewCtl.h"
#import "LoginViewController.h"
#import "LoginUtils.h"
#import "FujiaViewCtl.h"
#import "CourseTableCtl.h"
#import "BaseWebViewCtl.h"

#import "NeedPostViewCtl.h"
#import "GroupListViewCtl.h"
#import "SpecialApplyViewCtl.h"
//WLLocationDelegate  WLCityViewControllerDelegate
@interface HomeViewController () <UICollectionViewDelegate, UICollectionViewDataSource,imageViewClickDelegate,PYSearchViewControllerDelegate,WLLocationDelegate,WLCityViewControllerDelegate>


/** 顶部视图 */
@property(nonatomic,strong)headView *headView;


/** 大众推荐 */
@property (nonatomic, strong) UICollectionView *collectionView;

/** 城市定位管理器*/
@property (nonatomic, strong) WLLocation *locationManager;
/** 城市数据管理器*/
@property (nonatomic, strong) WLAreaDataManager *manager;

/** 热销数据源 */
@property(nonatomic,strong)NSMutableArray *hotMutableArr;
/** 零售数据源 */
@property(nonatomic,strong)NSMutableArray *selectionMutableArr;
/** 服务业数据源 */
@property(nonatomic,strong)NSMutableArray *servesMutableArr;
/** 品牌推广数据源 */
@property(nonatomic,strong)NSMutableArray *generalizeMutableArr;
/** collectionView数据源 */
@property(nonatomic,strong)NSMutableArray *productMutableArr;
/** 轮播图广告页数据源 */
@property(nonatomic,strong)NSMutableArray *AdvMutableArr;
/** 分类(大类)数据源 */
@property(nonatomic,strong)NSMutableArray *categoryMutableArr;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;

@property(nonatomic,strong)NSArray *hotSeaches; //热搜词
/** 状态栏颜色 */
@property(nonatomic,strong)UIColor *statusColor;

@end

static NSString *ID = @"publicCollectionViewCell";
static NSString *headerViewIdentifier = @"hederview";

@implementation HomeViewController

- (WLAreaDataManager *)manager {
    if (!_manager) {
        _manager = [WLAreaDataManager shareInstance];
        [_manager areaSqliteDBData];
    }
    return _manager;
}

-(NSMutableArray *)generalizeMutableArr{
    if (!_generalizeMutableArr) {
        _generalizeMutableArr = [NSMutableArray array];
    }
    return _generalizeMutableArr;
}
-(NSMutableArray *)hotMutableArr{
    if (!_hotMutableArr) {
        _hotMutableArr = [NSMutableArray array];
    }
    return _hotMutableArr;
}
-(NSMutableArray *)selectionMutableArr{
    if (!_selectionMutableArr) {
        _selectionMutableArr = [NSMutableArray array];
    }
    return _selectionMutableArr;
}
-(NSMutableArray *)productMutableArr{
    if (!_productMutableArr) {
        _productMutableArr = [NSMutableArray array];
    }
    return _productMutableArr;
}

-(NSMutableArray *)servesMutableArr{
    if (!_servesMutableArr) {
        _servesMutableArr = [NSMutableArray array];
    }
    return _servesMutableArr;
}

-(NSMutableArray *)AdvMutableArr{
    if (!_AdvMutableArr) {
        _AdvMutableArr = [NSMutableArray array];
    }
    return _AdvMutableArr;
}

-(NSMutableArray *)categoryMutableArr{
    if (!_categoryMutableArr) {
        _categoryMutableArr = [NSMutableArray array];
    }
    return _categoryMutableArr;
}

- (UICollectionView *)collectionView { 

    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:[[publicCollectionFlowLayout alloc] init]];
        [_collectionView registerClass:[publicCollectionViewCell class] forCellWithReuseIdentifier:ID];
        //注册头视图
        [_collectionView registerClass:[CollectionViewHeaderView class]
            forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                   withReuseIdentifier:headerViewIdentifier];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor colorWithHex:0xedf0f3];

    }
    return _collectionView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self viewDidLoad:YES];
    
    self.view.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    self.statusColor = [UIColor clearColor];
    //定位管理
    self.locationManager = [[WLLocation alloc] init];
    _locationManager.delegate = self;
    
    
    //collectionView
    [self.view addSubview:self.collectionView];

    
    __weak typeof(self)weakSelf = self;
    //顶部视图
    self.headView = [[headView alloc] initWithFrame:CGRectMake(0, kStatusBarHeight, SCREEN_WIDTH, 44)];
//    self.headView.locationBlock = ^{
//         [weakSelf jumpSearchView]; //跳转搜索页
//    };
    self.headView.searchBlock = ^{
        [weakSelf jumpSearchView]; //跳转搜索页
    };
    self.headView.locationBlock = ^{

//        WLCityViewController *cityViewController = [[WLCityViewController alloc] init];
//        cityViewController.delegate = weakSelf;
//        cityViewController.title = @"城市";
//        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:cityViewController];
//        [weakSelf presentViewController:navigationController animated:YES completion:nil];
    };
    //相机授权信息调用
    self.headView.scanCodeBlock = ^{
         [weakSelf cameraAuthorization];
    };
    [self.view addSubview:self.headView];
    
    // 添加刷新控件
    [self setupRefresh];
    
    [self loadHotValue]; //热搜请求

}

-(void)jumpSearchView{
    
    // 1.创建热门搜索
    if (self.hotSeaches.count < 1) {
        return;
    }
    
    // 2. 创建控制器
    PYSearchViewController *searchViewController = [PYSearchViewController searchViewControllerWithHotSearches:self.hotSeaches searchBarPlaceholder:@"商品名称" didSearchBlock:^(PYSearchViewController *searchViewController, UISearchBar *searchBar, NSString *searchText) {
        // 开始搜索执行以下代码
        
        // 如：跳转到指定控制器
        SearchResultViewController *vc = [[SearchResultViewController alloc] init];
        vc.keywords = searchText;
        [searchViewController.navigationController pushViewController:vc animated:YES];
    }];
    // 3. 设置风格
    searchViewController.hotSearchStyle = PYHotSearchStyleColorfulTag; // 热门搜索风格为默认
    searchViewController.searchHistoryStyle = 2; // 搜索历史风格根据选择
    
    // 4. 设置代理
    searchViewController.delegate = self;
    // 5. 跳转到搜索控制器
    [self.navigationController pushViewController:searchViewController animated:YES];
}


-(void)loadHotValue{
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    NSString *urlStr = [Utils getMemberServiceUri:@"topSearch"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            self.hotSeaches = [dataObject objectForKey:@"top_search"];
        }else{
            [MBManager showError:@"获取热搜词失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}


//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self setStatusBarBackgroundColor:self.statusColor];
    self.navigationController.navigationBar.hidden = YES;
   // [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent; //字体白色
}

-(void)viewWillDisappear:(BOOL)animated{
    [self setStatusBarBackgroundColor:[UIColor clearColor]];
    self.navigationController.navigationBar.hidden = NO;
    //[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault; //字体黑色
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //搜索键盘消失
    [self.headView.searchBar resignFirstResponder];
    self.headView.searchBar.text = nil;
    
    if ([scrollView isKindOfClass:[UICollectionView class]]) {
        CGFloat contentOffsetY = scrollView.contentOffset.y;
        
        if (contentOffsetY > 64) {
            self.headView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
            self.statusColor = [UIColor colorWithHex:0xedf0f3];
            [self setStatusBarBackgroundColor:self.statusColor];
            
            //设置扫码按钮图牌颜色
             [self.headView.saoBtn setImage:[UIImage imageNamed:@"homepage_btn_scan2_22_22"] forState:0];
            UIImage *image = [UIImage imageNamed:@"homepage_btn_bottom2_13_9"];
            [self.headView.imageDown setImage:image];
            self.headView.areaLabel.textColor = [UIColor blackColor];
            
        }else{
            self.statusColor = [UIColor clearColor];
            self.headView.backgroundColor = [UIColor clearColor];
            [self setStatusBarBackgroundColor:self.statusColor];
            
             [self.headView.saoBtn setImage:[UIImage imageNamed:@"homepage_btn_scan_20_20"] forState:0];
            UIImage *image = [UIImage imageNamed:@"homepage_btn_bottom_13_9"];
            [self.headView.imageDown setImage:image];
            self.headView.areaLabel.textColor = [UIColor whiteColor];
        }
    }
    
}

-(void)setupRefresh{
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.collectionView.mj_header.automaticallyChangeAlpha = YES;
    [self.collectionView.mj_header beginRefreshing];
    
    self.collectionView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
    //self.collectionView.mj_footer.ignoredScrollViewContentInsetBottom = 0;
}


//首次请求，下拉刷新请求
-(void)loadData{
    
    // 结束上拉
    [self.collectionView.mj_header endRefreshing];
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *urlStr = [Utils getMemberLoginUri:@"recommend"];
    //[Utils getTestUrl:@"recommend"];
    
    
    //NSLog(@"---%@",urlStr);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
            //DLog(@"%@",[Utils transformUnicode:responseObject]);
        
            [self.collectionView.mj_header endRefreshing];
            NSMutableDictionary *ret = [Utils didResponse:responseObject];
            NSString *status = [ret objectForKey:@"status"];


            if ([status isEqualToString:@"200"]) {

                id dataObject = [responseObject objectForKey:@"data"];
                id abc = [dataObject objectForKey:@"page_total"];
                self.page_total = [abc integerValue];
                
                //移到异步线程做
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                    //品牌推广数据源
                    NSDictionary *hotDict = [dataObject objectForKey:@"make"];
                    self.hotMutableArr = [storeModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    hotDict = [dataObject objectForKey:@"retails"];
                    self.selectionMutableArr = [storeModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    hotDict = [dataObject objectForKey:@"serves"];
                    self.servesMutableArr = [storeModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    hotDict = [dataObject objectForKey:@"brands"];
                    self.generalizeMutableArr = [storeModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    hotDict = [dataObject objectForKey:@"products"];
                    self.productMutableArr = [HomeModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    hotDict = [dataObject objectForKey:@"banner"];
                    self.AdvMutableArr = [AdvModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    hotDict = [dataObject objectForKey:@"categorys"];
                    self.categoryMutableArr = [catetorysModel mj_objectArrayWithKeyValuesArray:hotDict];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        //不发通知传值过去， 轮播图不自动轮播
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"HomeNotification" object:self.AdvMutableArr];
                        //3、回到主线程，刷新tableview等
                        [self.collectionView reloadData];
                    });
                });

                
            }else{
                [MBManager showError:@"获取数据失败"];
            }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        if (self.params != params) return;
        [self.collectionView.mj_header endRefreshing];
    }];


}

//上拉刷新请求
-(void)loadMoreDatas{
    // 结束下拉
    [self.collectionView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"没有更多数据了"];
        [self.collectionView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"recommend"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
    
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            //异步线程
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                NSDictionary *hotDict = [dataObject objectForKey:@"products"];
                NSArray *newProducts = [HomeModel mj_objectArrayWithKeyValuesArray:hotDict];
                [self.productMutableArr addObjectsFromArray:newProducts];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    //3、回到主线程，刷新tableview等
                    [self.collectionView reloadData];
                });
            });

        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.collectionView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_footer endRefreshing];
        if (self.params != params) return;
       
    }];

}
#pragma mark -- 相机授权
-(void)cameraAuthorization{
    
    // 1、 获取摄像设备
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    if (device) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusNotDetermined) {
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                if (granted) {
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        SGQRCodeScanningVC *vc = [[SGQRCodeScanningVC alloc] init];
                        [self.navigationController pushViewController:vc animated:YES];
                    });
                    // 用户第一次同意了访问相机权限
                    NSLog(@"用户第一次同意了访问相机权限 - - %@", [NSThread currentThread]);
                    
                } else {
                    // 用户第一次拒绝了访问相机权限
                    NSLog(@"用户第一次拒绝了访问相机权限 - - %@", [NSThread currentThread]);
                }
            }];
        } else if (status == AVAuthorizationStatusAuthorized) { // 用户允许当前应用访问相机
            SGQRCodeScanningVC *vc = [[SGQRCodeScanningVC alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        } else if (status == AVAuthorizationStatusDenied) { // 用户拒绝当前应用访问相机
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请去-> [设置 - 隐私 - 相机 - 大维营] 打开访问开关" preferredStyle:(UIAlertControllerStyleAlert)];
            UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            
            [alertC addAction:alertA];
            [self presentViewController:alertC animated:YES completion:nil];
            
        } else if (status == AVAuthorizationStatusRestricted) {
            NSLog(@"因为系统原因, 无法访问相册");
        }
    } else {
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"未检测到您的摄像头" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alertC addAction:alertA];
        [self presentViewController:alertC animated:YES completion:nil];
    }

}




#pragma mark - WLCityViewControllerDelegate

- (void)cityName:(NSString *)name {
    self.headView.locationStr = name;
    [appDelegate.appDefault setObject:name forKey:@"currentCity"];
}

#pragma mark --- WLLocationDelegate
//定位中...
- (void)locating {
    NSLog(@"定位中...");
}

//定位成功
- (void)currentLocation:(NSDictionary *)locationDictionary {
    NSString *cityStr = [locationDictionary valueForKey:@"City"];
    NSString *city = [cityStr stringByReplacingOccurrencesOfString:@"市" withString:@""]; //去除"市"
        if (![self.headView.areaLabel.text isEqualToString:city]) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:[NSString stringWithFormat:@"您定位到%@，确定切换城市吗？",city] preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            self.headView.areaLabel.text = city;

            [appDelegate.appDefault setObject:city forKey:@"locationCity"];
            [appDelegate.appDefault setObject:city forKey:@"currentCity"];
            [self.manager cityNumberWithCity:city cityNumber:^(NSString *cityNumber) {
                [appDelegate.appDefault setObject:cityNumber forKey:@"cityNumber"];
            }];
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:okAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

/// 拒绝定位
- (void)refuseToUsePositioningSystem:(NSString *)message {
    NSLog(@"%@",message);
}

// 定位失败
- (void)locateFailure:(NSString *)message {
    NSLog(@"%@",message);
}



#pragma mark UICollectionViewDataSource 数据源方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.productMutableArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    publicCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    cell.model = self.productMutableArr[indexPath.row];
    return cell;
}

#pragma mark UICollectionView 代理方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    //DLog(@"点击了%ld----%ld",indexPath.section,indexPath.row);
    HomeModel *model = self.productMutableArr[indexPath.row];
    DWYDetailsViewCtl *productCtl = [[DWYDetailsViewCtl alloc] init];
    productCtl.productID = model.pro_id;
    productCtl.type = isHome;
    [self.navigationController pushViewController:productCtl animated:YES];
}


//  返回头视图
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    //如果是头视图
    CollectionViewHeaderView *view = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                        withReuseIdentifier:headerViewIdentifier
                                                                               forIndexPath:indexPath];
    view.delegate = self;
    if ([kind isEqualToString:UICollectionElementKindSectionHeader])
    {
        //刷新头部数据源
        view.hotSell.dataArray = self.hotMutableArr;
        view.selectionView.dataArray = self.selectionMutableArr;
        //view.chooseView.servrsArray = self.servesMutableArr;
        view.generalizeView.dataArray = self.generalizeMutableArr;

        view.categoryView.dataArray = self.categoryMutableArr;
    }
    //全国特选点击
    __weak typeof (self)weakSelf = self;
    view.chanceV.chanceClickBlock = ^{
        BaseWebViewCtl *webV = [[BaseWebViewCtl alloc] init];
        webV.titleStr = @"全国特选";
        webV.urlStr = @"http://www.dwying.com/chance";
        [weakSelf.navigationController pushViewController:webV animated:YES];
    };
    return view;
}

#pragma mark -- 头部视图点击代理方法

-(void)titleLabelClick:(NSInteger)tag{
    if (tag == 1000) {
        CompanyMakeCtl *vc = [[CompanyMakeCtl alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if (tag == 1001){
        RetailCategoryCtl *retailCtl = [RetailCategoryCtl new];
        [self.navigationController pushViewController:retailCtl animated:YES];
    }
}

-(void)ViewTapClick:(NSString *)type WithTag:(NSInteger)tag{
    
    if (tag  == 100) {
        //CompanyMakeCtl *vc = [[CompanyMakeCtl alloc] init];
        GroupListViewCtl *vc = [[GroupListViewCtl alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if (tag == 101){
       // RetailCategoryCtl *retailCtl = [RetailCategoryCtl new];
        // NeedPostViewCtl *retailCtl = [NeedPostViewCtl new];
        SpecialApplyViewCtl *retailCtl = [SpecialApplyViewCtl new];
        [self.navigationController pushViewController:retailCtl animated:YES];
        
    }else if (tag == 102){
        DWYServiceCtl *service = [DWYServiceCtl new];
        [self.navigationController pushViewController:service animated:YES];
    }
}
// 分类:category  制造业热销:hotSell  零售业精选:selection  服务业推选:serves 品牌推广:generalize
-(void)ViewTapClick:(NSString *)type WithModel:(storeModel *)model{

    //NSLog(@"%@----%d----%d",type,model.t_type,model.t_column);

    
    if (model.t_column == 0) { //制造
        if (model.t_type == 0) {//商品
            DWYDetailsViewCtl *storeCtl = [[DWYDetailsViewCtl alloc] init];
            storeCtl.productID = model.t_pro_id;
            [self.navigationController pushViewController:storeCtl animated:YES];
        }else if (model.t_type == 1){ //分类
            CompanyMakeCtl *vc = [[CompanyMakeCtl alloc] init];
            vc.cateType = model.t_pro_id;
            vc.jumpType = 1;
            [self.navigationController pushViewController:vc animated:YES];
        }else if (model.t_type == 2){ //店铺
            StoreViewCtl *vc = [[StoreViewCtl alloc] init];
            vc.store_id = model.t_pro_id;
            [self.navigationController pushViewController:vc animated:YES];
        }
    }else if (model.t_column == 1){ //零售
        if (model.t_type == 0) {
            DWYDetailsViewCtl *storeCtl = [[DWYDetailsViewCtl alloc] init];
            storeCtl.productID = model.t_pro_id;
            [self.navigationController pushViewController:storeCtl animated:YES];
        }else if (model.t_type == 1){
            RetailCategoryCtl *vc = [[RetailCategoryCtl alloc] init];
            vc.cateType = model.t_pro_id;
            vc.jumpType = 1;
            [self.navigationController pushViewController:vc animated:YES];
        }else if (model.t_type == 2){
            StoreViewCtl *vc = [[StoreViewCtl alloc] init];
            vc.store_id = model.t_pro_id;
            [self.navigationController pushViewController:vc animated:YES];
        }
    }else if (model.t_column == 2){

        if (model.t_pro_id > 0) {
            StoreViewCtl *vc = [[StoreViewCtl alloc] init];
            vc.store_id = model.t_pro_id;
            [self.navigationController pushViewController:vc animated:YES];
        }

    }

}

//广告点击
-(void)AdClickIndex:(NSInteger)index{
    
    AdvModel *model = self.AdvMutableArr[index];
   
    switch (model.type) {
        case 0:
        {
            
            BaseWebViewCtl *webV = [BaseWebViewCtl new];
            webV.titleStr = model.b_name;
            if ([LoginUtils isLogin]) {
                NSString *uid = [appDelegate.appDefault objectForKey:@"user_id"];
                 webV.urlStr = [NSString stringWithFormat:@"%@?uid=%@",model.type_value,uid];
            }else{
                 webV.urlStr = model.type_value;
            }
           
            if (![Utils isBlankString:model.share_url]) {
                webV.share_title = model.share_title;
                webV.share_url = model.share_url;
                webV.share_content = model.share_content;
                webV.type = 1;
            }
            [self.navigationController pushViewController:webV animated:YES];
            
        } 
            break;
        case 1:
        {
            StoreViewCtl *vc = [[StoreViewCtl alloc] init];
            vc.store_id = [model.type_value intValue];
            [self.navigationController pushViewController:vc animated:YES];
            
        }
            break;
        case 2:
        {
            DWYDetailsViewCtl *productCtl = [[DWYDetailsViewCtl alloc] init];
            productCtl.productID = [model.type_value intValue];
            productCtl.type = isHome;
            [self.navigationController pushViewController:productCtl animated:YES];
            
        }
            break;
        case 3:
        {
            if (![LoginUtils isLogin]) {
                 [Utils loginController:self];
            }else{
                InviteViewCtl *vc = [[InviteViewCtl alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }
          
        }
            break;
        case 4:
        {

            id fjyf = [appDelegate.appDefault objectForKey:@"fjyf_status"];
            
            if ([fjyf intValue] == 0) { //未开通
                ApplyFujiaViewCtl *vc = [[ApplyFujiaViewCtl alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }else{ //已开通
                FujiaViewCtl *vc = [[FujiaViewCtl alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }

        }
            break;
            
        case 5:
        {
            CourseTableCtl *vc = [[CourseTableCtl alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
            
        }
            break;
        case 6:
        {
            NSString *uid = [appDelegate.appDefault objectForKey:@"user_id"];
            BaseWebViewCtl *webV = [BaseWebViewCtl new];
            webV.titleStr = model.b_name;
            webV.urlStr = [NSString stringWithFormat:@"%@?uid=%@",model.type_value,uid];
            if (![Utils isBlankString:model.share_url]) {
                webV.share_title = model.share_title;
                webV.share_url = [NSString stringWithFormat:@"%@?uid=%@",model.share_url,uid];
                webV.share_content = model.share_content;
                webV.type = 1;
            }
            [self.navigationController pushViewController:webV animated:YES];
            
        }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
