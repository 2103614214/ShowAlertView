//
//  SPecialModel.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface SPecialModel : BaseModel

/** 专场名 */
@property(nonatomic,copy)NSString *activity_title;
/** 图片 */
@property(nonatomic,copy)NSString *activity_img;
/** definestore_id */
@property(nonatomic,assign)int store_id;
/** group_id */
@property(nonatomic,assign)int group_id;
/** 时间 */
@property(nonatomic,copy)NSString *add_time;
/** 活动号 */
@property(nonatomic,assign)int activity_id;

@end



