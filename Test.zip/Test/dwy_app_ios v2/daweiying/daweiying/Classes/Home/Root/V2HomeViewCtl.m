//
//  V2HomeViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "V2HomeViewCtl.h"
#import "headView.h"

#import "V2HomeHeadView.h"
#import "HomeModel.h"
#import "GroupListViewCtl.h"
#import "SpecialApplyViewCtl.h"
#import "NeedPostViewCtl.h"
#import "BaseWebViewCtl.h"
#import "StoreViewCtl.h"
#import "DWYDetailsViewCtl.h"
#import "LoginUtils.h"
#import "InviteViewCtl.h"
#import "ApplyFujiaViewCtl.h"
#import "CourseTableCtl.h"
#import "FujiaViewCtl.h"

#import "SPecialModel.h"
#import "SpecialCell.h"
#import "SGQRCodeScanningVC.h"

//定位信息
#import "WLLocation.h"
#import "WLAreaDataManager.h"
#import "WLCityViewController.h"

#import "PYSearchViewController.h"
#import "PYSearch.h"
#import "SearchResultViewController.h"
#import "GroupBuyingViewCtl.h"
@interface V2HomeViewCtl () <UITableViewDelegate,UITableViewDataSource,PYSearchViewControllerDelegate,imageViewClickDelegate,WLLocationDelegate,WLCityViewControllerDelegate>

/** 顶部视图 */
@property(nonatomic,strong)headView *headView;
/** tableHeadV */
@property(nonatomic,strong)V2HomeHeadView *tableViewHeadV;
//专场列表数据数组
@property (nonatomic, strong) NSMutableArray *dataArray;
/** 分类(大类)数据源 */
@property(nonatomic,strong)NSMutableArray *categoryMutableArr;
/** 轮播图广告页数据源 */
@property(nonatomic,strong)NSMutableArray *AdvMutableArr;

/** 状态栏颜色 */
@property(nonatomic,strong)UIColor *statusColor;

/** 城市定位管理器*/
@property (nonatomic, strong) WLLocation *locationManager;
/** 城市数据管理器*/
@property (nonatomic, strong) WLAreaDataManager *manager;

@end

static NSString * const V2HomeViewCellId = @"V2HomeViewCellId";
@implementation V2HomeViewCtl

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableArray *)AdvMutableArr{
    if (!_AdvMutableArr) {
        _AdvMutableArr = [NSMutableArray array];
    }
    return _AdvMutableArr;
}

-(NSMutableArray *)categoryMutableArr{
    if (!_categoryMutableArr) {
        _categoryMutableArr = [NSMutableArray array];
    }
    return _categoryMutableArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    __weak typeof(self)weakSelf = self;
    
    self.statusColor = [UIColor clearColor];

    //定位管理
    self.locationManager = [[WLLocation alloc] init];
    _locationManager.delegate = self;
    
    //  添加 主tableView
    float y = -kStatusBarHeight;
    float h = kStatusBarHeight;
    if (@available(iOS 11.0, *)) {
        y = -kNavBarStatusHeight;
        h = kNavBarStatusHeight;
    }
    self.mainTableView.frame = CGRectMake(0,y, SCREEN_WIDTH, SCREEN_HEIGHT-kTabBarHeight+h);
    self.tableViewHeadV = [[V2HomeHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(420))];
    self.tableViewHeadV.delegate = self;
    self.mainTableView.tableHeaderView = self.tableViewHeadV;
    self.mainTableView.rowHeight = kHeight(190);
    self.mainTableView.delegate = self;
    self.mainTableView.dataSource = self;
    // 注册 重用名
    [self.mainTableView registerClass:[SpecialCell class] forCellReuseIdentifier:V2HomeViewCellId];
    [self.view addSubview: self.mainTableView];
    
    
    //顶部视图
    self.headView = [[headView alloc] initWithFrame:CGRectMake(0, kStatusBarHeight, SCREEN_WIDTH, 44)];
 
    self.headView.searchBlock = ^{
   
        [weakSelf jumpSearchView]; //跳转搜索页
    };
    self.headView.locationBlock = ^{
        
    };
    //相机授权信息调用
    self.headView.scanCodeBlock = ^{
         [weakSelf cameraAuthorization];
    };
    [self.view addSubview:self.headView];
    
    //  添加下拉
    [self createMJRefresh:isUp actionBlock:^{
        [weakSelf RequestData];
    }];
    
    [self RequestData];
    
}

//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self setStatusBarBackgroundColor:self.statusColor];
    self.navigationController.navigationBar.hidden = YES;
    //[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent; //字体白色
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
     [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent; //字体白色
}

-(void)viewWillDisappear:(BOOL)animated{
    [self setStatusBarBackgroundColor:[UIColor clearColor]];
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault; //字体黑色
}


-(void)scrollViewDidScroll:(UIScrollView *)scrollView{

    //搜索键盘消失
    [self.headView.searchBar resignFirstResponder];
    self.headView.searchBar.text = nil;
    
    if ([scrollView isKindOfClass:[UICollectionView class]]) {
        CGFloat contentOffsetY = scrollView.contentOffset.y;
        
        if (contentOffsetY > 64) {
            self.headView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
            self.statusColor = [UIColor colorWithHex:0xedf0f3];
            [self setStatusBarBackgroundColor:self.statusColor];
            
            //设置扫码按钮图牌颜色
            [self.headView.saoBtn setImage:[UIImage imageNamed:@"homepage_btn_scan2_22_22"] forState:0];
            UIImage *image = [UIImage imageNamed:@"homepage_btn_bottom2_13_9"];
            [self.headView.imageDown setImage:image];
            self.headView.areaLabel.textColor = [UIColor blackColor];
            
        }else{
            self.statusColor = [UIColor clearColor];
            self.headView.backgroundColor = [UIColor clearColor];
            [self setStatusBarBackgroundColor:self.statusColor];
            
            [self.headView.saoBtn setImage:[UIImage imageNamed:@"homepage_btn_scan_20_20"] forState:0];
            UIImage *image = [UIImage imageNamed:@"homepage_btn_bottom_13_9"];
            [self.headView.imageDown setImage:image];
            self.headView.areaLabel.textColor = [UIColor whiteColor];
        }
    }
    
}

-(void)jumpSearchView{
    
    // 1.创建热门搜索
//    if (self.hotSeaches.count < 1) {
//        return;
//    }
    
    // 2. 创建控制器
    PYSearchViewController *searchViewController = [PYSearchViewController searchViewControllerWithHotSearches:nil searchBarPlaceholder:@"商品名称" didSearchBlock:^(PYSearchViewController *searchViewController, UISearchBar *searchBar, NSString *searchText) {
        // 开始搜索执行以下代码
        
        // 如：跳转到指定控制器
        SearchResultViewController *vc = [[SearchResultViewController alloc] init];
        vc.keywords = searchText;
        [searchViewController.navigationController pushViewController:vc animated:YES];
    }];
    // 3. 设置风格
    searchViewController.hotSearchStyle = PYHotSearchStyleColorfulTag; // 热门搜索风格为默认
    searchViewController.searchHistoryStyle = 2; // 搜索历史风格根据选择
    
    // 4. 设置代理
    searchViewController.delegate = self;
    // 5. 跳转到搜索控制器
    [self.navigationController pushViewController:searchViewController animated:YES];
}


#pragma mark -- 相机授权
-(void)cameraAuthorization{
    
    // 1、 获取摄像设备
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    if (device) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusNotDetermined) {
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                if (granted) {
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        SGQRCodeScanningVC *vc = [[SGQRCodeScanningVC alloc] init];
                        [self.navigationController pushViewController:vc animated:YES];
                    });
                    // 用户第一次同意了访问相机权限
                    NSLog(@"用户第一次同意了访问相机权限 - - %@", [NSThread currentThread]);
                    
                } else {
                    // 用户第一次拒绝了访问相机权限
                    NSLog(@"用户第一次拒绝了访问相机权限 - - %@", [NSThread currentThread]);
                }
            }];
        } else if (status == AVAuthorizationStatusAuthorized) { // 用户允许当前应用访问相机
            SGQRCodeScanningVC *vc = [[SGQRCodeScanningVC alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        } else if (status == AVAuthorizationStatusDenied) { // 用户拒绝当前应用访问相机
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请去-> [设置 - 隐私 - 相机 - 大维营] 打开访问开关" preferredStyle:(UIAlertControllerStyleAlert)];
            UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            
            [alertC addAction:alertA];
            [self presentViewController:alertC animated:YES completion:nil];
            
        } else if (status == AVAuthorizationStatusRestricted) {
            NSLog(@"因为系统原因, 无法访问相册");
        }
    } else {
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"未检测到您的摄像头" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alertC addAction:alertA];
        [self presentViewController:alertC animated:YES completion:nil];
    }
    
}




//  mj 请求数据
- (void)RequestData{

    if (self.judge == 10) {
        // 下拉时 清空数据数组 重新请求添加
       // [self.dataArray removeAllObjects];
    }
    __weak typeof(self) WeakSelf = self;
    
    //2
    NSDictionary *parameters = @{@"page": @(1)};
    
    //网络请求
    NSString *urlString = [Utils V2GetMemberLoginUrl:@"index"];
    
    [super PostRequsetDataUrlString:urlString Parameters:parameters];
    self.PostSuccess=^(id responseObject){
        //解析
        if (WeakSelf.judge == 10) {
            // 下拉时 清空数据数组 重新请求添加
            [WeakSelf.dataArray removeAllObjects];
        }
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        if ([status isEqualToString:@"200"]) {
            
          
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            //移到异步线程做
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                //品牌推广数据源
                NSDictionary *hotDict = [dataObject objectForKey:@"list"];
        
                WeakSelf.dataArray = [SPecialModel mj_objectArrayWithKeyValuesArray:hotDict];
                
                hotDict = [dataObject objectForKey:@"banner"];
                WeakSelf.AdvMutableArr = [AdvModel mj_objectArrayWithKeyValuesArray:hotDict];
                
                hotDict = [dataObject objectForKey:@"categorys"];
                WeakSelf.categoryMutableArr = [catetorysModel mj_objectArrayWithKeyValuesArray:hotDict];
                 
                dispatch_async(dispatch_get_main_queue(), ^{
                    //不发通知传值过去， 轮播图不自动轮播
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"HomeNotification" object:WeakSelf.AdvMutableArr];
                    
                    WeakSelf.tableViewHeadV.categoryView.dataArray = WeakSelf.categoryMutableArr;
                    //3、回到主线程，刷新tableview等
                    [WeakSelf.mainTableView reloadData];
                });
            });
            
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
        [WeakSelf.mainTableView.mj_header endRefreshing];
    };
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.dataArray.count;
}

#pragma mark ------- 数据源
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    SpecialCell *cell = [tableView dequeueReusableCellWithIdentifier:V2HomeViewCellId];
    // 重用
    if(cell == nil){
        cell = [[SpecialCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:V2HomeViewCellId];
    }
    cell.model = self.dataArray[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    SPecialModel *model = self.dataArray[indexPath.row];
    
    GroupBuyingViewCtl *vc = [GroupBuyingViewCtl new];
    vc.storeId = [NSString stringWithFormat:@"%d",model.store_id];
    vc.titleStr = model.activity_title;
    [self.navigationController pushViewController:vc animated:YES];
    
}




-(void)ViewTapClick:(NSString *)type WithTag:(NSInteger)tag{
    
    if (tag  == 100) {
        //CompanyMakeCtl *vc = [[CompanyMakeCtl alloc] init];
        GroupListViewCtl *vc = [[GroupListViewCtl alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else if (tag == 101){
        // RetailCategoryCtl *retailCtl = [RetailCategoryCtl new];
         NeedPostViewCtl *retailCtl = [NeedPostViewCtl new];
       // SpecialApplyViewCtl *retailCtl = [SpecialApplyViewCtl new];
        [self.navigationController pushViewController:retailCtl animated:YES];
    }
}

-(void)SpecialApply{
    SpecialApplyViewCtl *retailCtl = [SpecialApplyViewCtl new];
    [self.navigationController pushViewController:retailCtl animated:YES];
}
//广告点击
-(void)AdClickIndex:(NSInteger)index{
    
    AdvModel *model = self.AdvMutableArr[index];
    
    switch (model.type) {
        case 0:
        {
            
            BaseWebViewCtl *webV = [BaseWebViewCtl new];
            webV.titleStr = model.b_name;
            if ([LoginUtils isLogin]) {
                NSString *uid = [appDelegate.appDefault objectForKey:@"user_id"];
                webV.urlStr = [NSString stringWithFormat:@"%@?uid=%@",model.type_value,uid];
            }else{
                webV.urlStr = model.type_value;
            }
            
            if (![Utils isBlankString:model.share_url]) {
                webV.share_title = model.share_title;
                webV.share_url = model.share_url;
                webV.share_content = model.share_content;
                webV.type = 1;
            }
            [self.navigationController pushViewController:webV animated:YES];
            
        }
            break;
        case 1:
        {
            StoreViewCtl *vc = [[StoreViewCtl alloc] init];
            vc.store_id = [model.type_value intValue];
            [self.navigationController pushViewController:vc animated:YES];
            
        }
            break;
        case 2:
        {
            DWYDetailsViewCtl *productCtl = [[DWYDetailsViewCtl alloc] init];
            productCtl.productID = [model.type_value intValue];
            productCtl.type = isHome;
            [self.navigationController pushViewController:productCtl animated:YES];
            
        }
            break;
        case 3:
        {
            if (![LoginUtils isLogin]) {
                [Utils loginController:self];
            }else{
                InviteViewCtl *vc = [[InviteViewCtl alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }
            
        }
            break;
        case 4:
        {
            
            id fjyf = [appDelegate.appDefault objectForKey:@"fjyf_status"];
            
            if ([fjyf intValue] == 0) { //未开通
                ApplyFujiaViewCtl *vc = [[ApplyFujiaViewCtl alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }else{ //已开通
                FujiaViewCtl *vc = [[FujiaViewCtl alloc] init];
                [self.navigationController pushViewController:vc animated:YES];
            }
            
        }
            break;
            
        case 5:
        {
            CourseTableCtl *vc = [[CourseTableCtl alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
            
        }
            break;
        case 6:
        {
            NSString *uid = [appDelegate.appDefault objectForKey:@"user_id"];
            BaseWebViewCtl *webV = [BaseWebViewCtl new];
            webV.titleStr = model.b_name;
            webV.urlStr = [NSString stringWithFormat:@"%@?uid=%@",model.type_value,uid];
            if (![Utils isBlankString:model.share_url]) {
                webV.share_title = model.share_title;
                webV.share_url = [NSString stringWithFormat:@"%@?uid=%@",model.share_url,uid];
                webV.share_content = model.share_content;
                webV.type = 1;
            }
            [self.navigationController pushViewController:webV animated:YES];
            
        }
            break;
            
        default:
            break;
    }
}


#pragma mark - WLCityViewControllerDelegate

- (void)cityName:(NSString *)name {
    self.headView.locationStr = name;
    [appDelegate.appDefault setObject:name forKey:@"currentCity"];
}

#pragma mark --- WLLocationDelegate
//定位中...
- (void)locating {
    NSLog(@"定位中...");
}

//定位成功
- (void)currentLocation:(NSDictionary *)locationDictionary {
    NSString *cityStr = [locationDictionary valueForKey:@"City"];
    NSString *city = [cityStr stringByReplacingOccurrencesOfString:@"市" withString:@""]; //去除"市"
    if (![self.headView.areaLabel.text isEqualToString:city]) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:[NSString stringWithFormat:@"您定位到%@，确定切换城市吗？",city] preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            self.headView.areaLabel.text = city;
            
            [appDelegate.appDefault setObject:city forKey:@"locationCity"];
            [appDelegate.appDefault setObject:city forKey:@"currentCity"];
            [self.manager cityNumberWithCity:city cityNumber:^(NSString *cityNumber) {
                [appDelegate.appDefault setObject:cityNumber forKey:@"cityNumber"];
            }];
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:okAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

/// 拒绝定位
- (void)refuseToUsePositioningSystem:(NSString *)message {
    NSLog(@"%@",message);
}

// 定位失败
- (void)locateFailure:(NSString *)message {
    NSLog(@"%@",message);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

