//
//  headView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/15.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^locationClick)();
typedef void (^scanCodeBlock)();
typedef void (^searchBlock)();

@interface headView : UIView

@property (nonatomic,copy) NSString *locationStr;
@property (nonatomic,copy) locationClick locationBlock;
@property (nonatomic,copy) scanCodeBlock scanCodeBlock;
@property (nonatomic,copy) searchBlock searchBlock;
/** 地区名称 */
@property(nonatomic,strong)UILabel *areaLabel;
/** 下拉箭头 */
@property(nonatomic,strong)UIImageView *imageDown;
/** 扫码btn */
@property(nonatomic,strong)UIButton *saoBtn;

//搜索
@property (nonatomic, strong) UISearchBar *searchBar;


@end
