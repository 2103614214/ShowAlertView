//
//  selectionView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//  零售精选

#import <UIKit/UIKit.h>
@class storeModel;
typedef void (^imageViewClickBlock)(NSString *type,storeModel *model);

@interface selectionView : UIView

@property (nonatomic,copy) imageViewClickBlock imageViewBlock;

/** 数据源 */
@property(nonatomic,strong)NSArray *dataArray;


@property(nonatomic,strong)UILabel *titleLabel;

@end
