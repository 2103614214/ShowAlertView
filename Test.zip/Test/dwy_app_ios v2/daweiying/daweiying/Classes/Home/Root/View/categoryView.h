//
//  categoryView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^categoryTapBlock)(NSString *type,NSInteger tag);

@interface categoryView : UIView

/** 数据源 */
@property(nonatomic,strong)NSArray *dataArray;

@property (nonatomic,copy) categoryTapBlock categoryTapBlock;

@end


//全国特选
@interface chanceView : UIView

/** 点击事件 */
@property(nonatomic,copy) void (^chanceClickBlock)();

@end
