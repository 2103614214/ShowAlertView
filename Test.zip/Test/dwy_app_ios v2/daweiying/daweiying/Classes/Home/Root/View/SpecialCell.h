//
//  SpecialCell.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SPecialModel;

@interface SpecialCell : UITableViewCell

/** model */
@property(nonatomic,strong)SPecialModel *model;

@end
