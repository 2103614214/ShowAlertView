//
//  generalizeView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/15.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "generalizeView.h"
#import "HomeModel.h"

@interface generalizeView ()

//上栏
@property(nonatomic,strong)UIImageView *imageView1;
@property(nonatomic,strong)UIImageView *imageView2;
@property(nonatomic,strong)UIImageView *imageView3;
//下栏
@property(nonatomic,strong)UIImageView *imageView4;
@property(nonatomic,strong)UIImageView *imageView5;
@property(nonatomic,strong)UIImageView *imageView6;

@end

@implementation generalizeView
{
    UILabel *_line1;
    UILabel *_line4;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor whiteColor];
    
    self.titleLabel = [UILabel new];
    NSString *titleStr = @"品牌推广";
//    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:titleStr];
//    [aString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHex:0xf4a81f]range:NSMakeRange(0, 2)];
//    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial Rounded MT Bold"  size:(18.0)]range:NSMakeRange(0, 3)];
//    _titleLabel.userInteractionEnabled = YES;
    _titleLabel.text= titleStr;
    _titleLabel.font = [UIFont systemFontOfSize:15];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_titleLabel];
    _titleLabel.sd_layout
    .yIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(39))
    .xIs(0);
    
    _line1 = [UILabel new];
    _line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:_line1];
    _line1.sd_layout
    .topSpaceToView(_titleLabel, 5)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    float height = self.height-_titleLabel.height;
    float width = (SCREEN_WIDTH-2)/3;
    
    //中间竖线
    UILabel *line2 = [UILabel new];
    line2.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line2];
    line2.sd_layout
    .topSpaceToView(_line1, 0)
    .leftSpaceToView(self, width)
    .widthIs(1)
    .heightIs(height);
    
    //中间竖线
    UILabel *line3 = [UILabel new];
    line3.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line3];
    line3.sd_layout
    .topSpaceToView(_line1, 0)
    .leftSpaceToView(self, width*2)
    .widthIs(1)
    .heightIs(height);
    
    
    //中间横线
    UILabel *line4 = [UILabel new];
    line4.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line4];
    _line4 = line4;
    line4.sd_layout
    .topSpaceToView(_line1,height/2)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    __weak typeof (self)weakSelf = self;
    float subViewH = (self.height-_titleLabel.height-17)/2;
    for (int i=0; i<6; i++) {
        UIImageView *imageV = [[UIImageView alloc] init];
        imageV.userInteractionEnabled = YES;
        imageV.tag = 100 + i;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            
            [weakSelf categoryClick:i];
            //self.imageViewBlock(@"generalize", imageV.tag);
            
        }];
        [imageV addGestureRecognizer:tap];
        [self addSubview:imageV];
        if (i < 3) {
            
            imageV.sd_layout
            .topSpaceToView(_line1, 1)
            .leftSpaceToView(self, (SCREEN_WIDTH-2)/3*i+2)
            .widthIs((SCREEN_WIDTH-10)/3)
            .heightIs(subViewH);
        }else if (i>2 && i<6){
            
            imageV.sd_layout
            .topSpaceToView(_line4, 2)
            .leftSpaceToView(self, (SCREEN_WIDTH-2)/3*(i-3)+2)
            .widthIs((SCREEN_WIDTH-10)/3)
            .heightIs(subViewH);
        }
        if (i == 0) {
            self.imageView1 = imageV;
        }else if (i == 1){
            self.imageView2 = imageV;
        }else if (i == 2){
            self.imageView3 = imageV;
        }else if (i == 3){
            self.imageView4 = imageV;
        }else if (i == 4){
            self.imageView5 = imageV;
        }else if (i == 5){
            self.imageView6 = imageV;
        }
    
    }
}

-(void)categoryClick:(int)type{
    
    storeModel *model = self.dataArray[type];
    if (model.t_pro_id > 0) {
        if (self.imageViewBlock) {
           // self.imageViewBlock(@"generalize", model.t_pro_id);
    
           // self.imageViewBlock(@"generalize", model.t_pro_id, model.t_type);
            self.imageViewBlock(@"generalize", model);
        }
    }
}

-(void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    
    for (int i =0; i < _dataArray.count; i++) {
        storeModel *model = _dataArray[i];
        if (i == 0) {
            [self.imageView1 sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 1){
            [self.imageView2 sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 2){
            [self.imageView3 sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 3){
            [self.imageView4 sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 4){
            [self.imageView5 sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 5){
            [self.imageView6 sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }
        else{
            
            return;
        }
    }
}


@end

@implementation publicHeadView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    self.backgroundColor = [UIColor whiteColor];

    UILabel *margeLabel = [[UILabel alloc] initWithFrame:self.bounds];
    margeLabel.text = @"大众推荐";
    margeLabel.font = [UIFont systemFontOfSize:15];
    margeLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:margeLabel];
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line1];
    line1.sd_layout
    .bottomSpaceToView(self, 1)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
}
@end
