//
//  publicCollectionViewCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "publicCollectionViewCell.h"


@interface publicCollectionViewCell()

/** 图标 */
@property(nonatomic,strong)UIImageView *imageV;
/** 名称 */
@property(nonatomic,strong)UILabel *nameLabel;
/** 价格 */
@property(nonatomic,strong)UILabel *priceLabel;
/** 销量 */
@property(nonatomic,strong)UILabel *sellNumberlabel;
/** type */
@property(nonatomic,strong)UIImageView *imageType;

@end

@implementation publicCollectionViewCell


- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        //图片
        CGFloat itemW = (SCREEN_WIDTH-5)/ 2;
        UIImageView *imageV = [[UIImageView alloc] init];
        [self.contentView addSubview:imageV];
        imageV.sd_layout
        .topSpaceToView(self.contentView, 0)
        .leftSpaceToView(self.contentView, 0)
        .widthIs(self.contentView.width)
        .heightIs(itemW);
        self.imageV = imageV;
        

        //商品名
        UILabel *label = [[UILabel alloc] init];
        label.textColor = [UIColor grayColor];
        label.numberOfLines = 0;
        label.textAlignment = NSTextAlignmentLeft;
        label.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:label];
        label.sd_layout
        .topSpaceToView(imageV, 0)
        .leftSpaceToView(self.contentView, 10)
        .widthIs(self.contentView.width-20)
        .heightIs(kHeight(50));
        self.nameLabel = label;
        
        
        UIImageView *imageType = [[UIImageView alloc] init];
        [self.contentView addSubview:imageType];
        imageType.sd_layout
        .topSpaceToView(imageV, 5)
        .leftSpaceToView(self.contentView, 5)
        .widthIs(kWidth(25))
        .heightIs(kHeight(18));
        self.imageType = imageType;
       
        
        //商品价格
        UILabel *pricelabel = [[UILabel alloc] init];
        pricelabel.textColor = [UIColor colorWithHex:0xf67100];
        pricelabel.textAlignment = NSTextAlignmentLeft;
        pricelabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:pricelabel];
        pricelabel.sd_layout
        .topSpaceToView(label, 0)
        .leftSpaceToView(self.contentView, 10)
        .widthIs(self.contentView.width/2)
        .heightIs(kHeight(30));
        self.priceLabel = pricelabel;
        
        
        //销量
        UILabel *sellNumberlabel = [[UILabel alloc] init];
        sellNumberlabel.textColor = [UIColor grayColor];
        sellNumberlabel.adjustsFontSizeToFitWidth = YES;
        sellNumberlabel.textAlignment = NSTextAlignmentLeft;
        sellNumberlabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:sellNumberlabel];
        sellNumberlabel.sd_layout
        .topSpaceToView(label, 0)
        .leftSpaceToView(pricelabel, 0)
        .widthIs(self.contentView.width/2)
        .heightIs(kHeight(30));
        self.sellNumberlabel = sellNumberlabel;
        
        
    }
    return self;
}

-(void)setModel:(HomeModel *)model{
    _model = model;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:model.logo_url] placeholderImage:[UIImage imageNamed:placeImageName]];
    self.nameLabel.text = [NSString stringWithFormat:@"      %@",model.pro_name];
  
    NSString *balance =[NSString stringWithFormat:@"¥ %@",model.price];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:balance];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(14.0)]range:NSMakeRange(0, 1)];
    self.priceLabel.attributedText= aString;
    self.sellNumberlabel.text = [NSString stringWithFormat:@"销量:%@",model.sell_number];


    //NSLog(@"%@----%ld",model.pro_name,model.pro_name.length);
   

    if (model.type == 1) { //日常零售
        [self.imageType setImage:[UIImage imageNamed:@"img_store_23_15"]];
    }else if (model.type == 2){ //企业制造
        [self.imageType setImage:[UIImage imageNamed:@"img_make_23_15"]];
    }
    
//     CGFloat itemW = (SCREEN_WIDTH-5)/ 2;
//    if (model.pro_name.length<9) {
//
//        //self.imageType.frame = CGRectMake(10, itemW+15, kWidth(25), kHeight(18));
//        [self.imageType setMj_y:itemW+15];
//    }else{
//        [self.imageType setMj_y:itemW+5];
//       // self.imageType.frame = CGRectMake(10, itemW+5, kWidth(25), kHeight(18));
//    }
//    [self setNeedsLayout];
}

@end
