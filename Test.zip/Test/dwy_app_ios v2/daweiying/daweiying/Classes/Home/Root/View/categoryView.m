//
//  categoryView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "categoryView.h"
#import "HomeModel.h"

#define CURRENT_SIZE(_size) _size / 375.0 * SCREEN_WIDTH



@implementation categoryView
{
    UIImageView *_leftImageView;
    UIImageView *_middleImageView;
    UIImageView *_rightImageView;
    
    UILabel *_leftLabel;
    UILabel *_middleLabel;
    UILabel *_rightLabel;
    
    UILabel *_leftRemarkLabel;
    UILabel *_middleRemarkLabel;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    self.backgroundColor = [UIColor whiteColor];

    
    [self createMZActivity];

}

/** 创建分类的方法 */
- (void)createMZActivity{
    
    for (int i=0; i<2; i++) {
        
        
        UIView * vi = [[UIView alloc] initWithFrame:CGRectMake((self.width / 2.0 ) * i, 0, self.width / 2.0, self.height)];
        vi.userInteractionEnabled = YES;
        vi.tag = 100 +i;
        __weak typeof (self)weakSelf = self;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            //触发点击事件
            weakSelf.categoryTapBlock(@"category", vi.tag);
        }];
        [vi addGestureRecognizer:tap];
        
        //图标
        UIImageView * imageV = [[UIImageView alloc] initWithFrame:CGRectMake((vi.width-kWidth(90))/2, kHeight(10), kWidth(90), kHeight(105))];
        [vi addSubview:imageV];
        
        //分类名
        UILabel * label = [Utils labelTextColor:[UIColor blackColor] fontSize:16 numberOfLines:1 text:@""];
        label.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:label];
        label.sd_layout
        .xIs(0)
        .topSpaceToView(imageV, 0)
        .widthIs(vi.width)
        .heightIs(25);
        
        //备注
        UILabel * remarklabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
        remarklabel.adjustsFontSizeToFitWidth = YES;
        remarklabel.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:remarklabel];
        remarklabel.sd_layout
        .topSpaceToView(label, 0)
        .xIs(0)
        .widthIs(vi.width)
        .heightIs(20);
        
      
        [self addSubview:vi];
        
        if (i == 0) {
            _leftImageView = imageV;
            _leftLabel = label;
            _leftRemarkLabel = remarklabel;
        }else if (i == 1){
            _middleImageView = imageV;
            _middleLabel = label;
            _middleRemarkLabel = remarklabel;
        }else if (i == 2){
            _rightImageView = imageV;
            _rightLabel = label;
        }else{
            return;
        }

    }
    
    //分隔线
//    UILabel *line = [Utils lineWithFrame:CGRectMake(SCREEN_WIDTH/2, kHeight(10), 1, kHeight(80))];
//    [self addSubview:line];
    

}

-(void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    for (int i = 0; i <_dataArray.count; i++) {
        catetorysModel *model = _dataArray[i];
        if (i == 0) {
            [_leftImageView setImage:[UIImage imageNamed:@"homepage_icon_shopping_90_90"]];
            _leftLabel.text = @"拼团采购";
            //model.cate_name;
            _leftRemarkLabel.text = @"省成本、提销量";
        }else if (i == 1){
            [_middleImageView setImage:[UIImage imageNamed:@"homepage_icon_publish_90_90"]];
            _middleRemarkLabel.text = @"解决方案、服务";
            _middleLabel.text = @"需求发布";
            //model.cate_name;
        }else if (i == 2){
            [_rightImageView sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _rightLabel.text = model.cate_name;
        }else{
            return;
        }
    }
}





@end


#pragma mark -- 全国特选

@implementation chanceView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    //初始化
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor colorWithHex:0xfbac47] fontSize:23 numberOfLines:1 text:@"全国特选"];
    nameLabel.frame = CGRectMake(kWidth(20), kHeight(20), kWidth(180), kHeight(30));
    [self addSubview:nameLabel];
    
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:14 numberOfLines:1 text:@"乙级商家商品展示首页"];
    remarkLabel.frame = CGRectMake(kWidth(20), kHeight(50), kWidth(180), kHeight(30));
    [self addSubview:remarkLabel];
    
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"img_level"]];
    imageV.frame = CGRectMake(SCREEN_WIDTH-kWidth(150), kHeight(10), kWidth(110), kHeight(80));
    [self addSubview:imageV];
    
    @weakify(self);
    self.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        @strongify(self);
        if (self.chanceClickBlock) {
            self.chanceClickBlock();
        }
    }];
    [self addGestureRecognizer:tap];
    
}

@end
