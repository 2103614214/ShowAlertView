//
//  hotSellView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "hotSellView.h"
#import "HomeModel.h"

@implementation hotSellView
{
    
    UIImageView *_leftImageView;
    UIImageView *_rightUpImageView;
    UIImageView *_rightDownImageView;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLabel = [UILabel new];
    titleLabel.font = [UIFont systemFontOfSize:15];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:titleLabel];
    titleLabel.userInteractionEnabled = YES;
    titleLabel.sd_layout
    .yIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(39))
    .xIs(0);
    self.titleLabel = titleLabel;
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line1];
    line1.sd_layout
    .topSpaceToView(titleLabel, 0)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    __weak typeof (self)weakSelf = self;
    //左侧图片
    UIImageView *leftImageView = [[UIImageView alloc] init];
    leftImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf categoryClick:0];
//        if (self.viewTypeChoose == isHotSellView) {
//            self.imageTapBlock(@"hotSell", 100);
//        }else{
//            self.imageTapBlock(@"serves", 100);
//        }
        
    }];
    [leftImageView addGestureRecognizer:tap];
    [self addSubview:leftImageView];
    leftImageView.sd_layout
    .topSpaceToView(line1, 1)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH*0.43)
    .heightIs(SCREEN_WIDTH*0.43);
    _leftImageView = leftImageView;
    
    //中间竖线
    UILabel *line2 = [UILabel new];
    line2.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line2];
    line2.sd_layout
    .topSpaceToView(line1, 0)
    .leftSpaceToView(leftImageView, 0)
    .widthIs(1)
    .heightIs(leftImageView.height);
    
 
    //右侧图片 (上)
    UIImageView *rightUpImageView = [[UIImageView alloc] init];
    rightUpImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf categoryClick:1];
//        if (self.viewTypeChoose == isHotSellView) {
//            self.imageTapBlock(@"hotSell", 101);
//        }else{
//            self.imageTapBlock(@"serves", 101);
//        }
        
    }];
    [rightUpImageView addGestureRecognizer:tap1];
    [self addSubview:rightUpImageView];
    rightUpImageView.sd_layout
    .topSpaceToView(line1, 1)
    .leftSpaceToView(leftImageView, 1)
    .widthIs(SCREEN_WIDTH-leftImageView.width-1)
    .heightIs(leftImageView.height /2-1);
    _rightUpImageView = rightUpImageView;
    
    //中间横线
    UILabel *line3 = [UILabel new];
    line3.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line3];
    line3.sd_layout
    .topSpaceToView(rightUpImageView, 0)
    .leftSpaceToView(leftImageView, 0)
    .widthIs(rightUpImageView.width+1)
    .heightIs(1);
    
    //右侧图片 (下)
    UIImageView *rightDownImageView = [[UIImageView alloc] init];
    rightDownImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] init];
    [[tap2 rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf categoryClick:2];
//        if (self.viewTypeChoose == isHotSellView) {
//            self.imageTapBlock(@"hotSell", 102);
//        }else{
//            self.imageTapBlock(@"serves", 102);
//        }
        
    }];
    [rightDownImageView addGestureRecognizer:tap2];
    [self addSubview:rightDownImageView];
    rightDownImageView.sd_layout
    .topSpaceToView(line3, 1)
    .leftSpaceToView(leftImageView, 1)
    .widthIs(SCREEN_WIDTH-leftImageView.width-1)
    .heightIs(leftImageView.height /2-1);
    _rightDownImageView = rightDownImageView;
    

}

-(void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    for (int i =0; i < _dataArray.count; i++) {
        storeModel *model = _dataArray[i];
        if (i == 0) {
            [_leftImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 1){
            [_rightUpImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 2){
            [_rightDownImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else{
            
            return;
        }
    }
}

-(void)categoryClick:(int)type{
    
    storeModel *model = self.dataArray[type];
    if (model.t_pro_id > 0) {
        if (self.imageTapBlock) {
            //self.imageTapBlock(@"hotSell", model.t_pro_id);
            //self.self.imageTapBlock(@"hotSell", model.t_pro_id, model.t_type);
            self.imageTapBlock(@"hotSell",model);
        }
    }
}

-(void)setServrsArray:(NSArray *)servrsArray{
    _servrsArray = servrsArray;
    for (int i =0; i < _servrsArray.count; i++) {
        storeModel *model = _servrsArray[i];
        if (i == 0) {
            [_leftImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 1){
            [_rightUpImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 2){
            [_rightDownImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else{
            
            return;
        }
    }
    
}

-(void)setHeadTitleStr:(NSString *)headTitleStr{
    _headTitleStr = headTitleStr;
    
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:_headTitleStr];
    [aString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHex:0xf4a81f]range:NSMakeRange(0, 3)];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial Rounded MT Bold"  size:(17.0)]range:NSMakeRange(0, 3)];
    self.titleLabel.attributedText= aString;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
