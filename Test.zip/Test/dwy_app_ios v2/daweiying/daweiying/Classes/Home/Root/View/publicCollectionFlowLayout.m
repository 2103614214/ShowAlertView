//
//  publicCollectionFlowLayout.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "publicCollectionFlowLayout.h"

@implementation publicCollectionFlowLayout

/// 准备布局
- (void)prepareLayout {
    [super prepareLayout];
    //设置item尺寸
    CGFloat itemW = (self.collectionView.frame.size.width-5)/ 2;
    self.itemSize = CGSizeMake(itemW, itemW+(kHeight(80)));
    //CGSizeMake(itemW, kHeight(SCREEN_HEIGHT*0.25));
    
    //设置最小间距
    self.minimumLineSpacing = 5;
    self.minimumInteritemSpacing = 5;
    self.sectionInset = UIEdgeInsetsMake(0, 0, kNavBarStatusHeight, 0);
    self.headerReferenceSize=CGSizeMake(SCREEN_WIDTH, SCREEN_WIDTH/3+SCREEN_WIDTH*0.43+(kHeight(570))); //设置collectionView头视图的宽高
    
    //605 + 285*w
}

@end
