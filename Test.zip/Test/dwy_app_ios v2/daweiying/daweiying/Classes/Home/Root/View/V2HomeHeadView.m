//
//  V2HomeHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "V2HomeHeadView.h"
#import "HomeModel.h"

@implementation V2HomeHeadView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    //设置轮播图
    self.cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(230)) delegate:self placeholderImage:[UIImage imageNamed:@""]];
    
    self.cycleScrollView.autoScrollTimeInterval = 3.0;
    _cycleScrollView.currentPageDotColor = [UIColor whiteColor];
    _cycleScrollView.pageDotColor = [UIColor colorWithHex:0xffffff alpha:0.5];
    _cycleScrollView.pageControlDotSize = CGSizeMake(8, 8);
    
    // 不设置标题
    self.cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleClassic;
    self.cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    
    self.cycleScrollView.bannerImageViewContentMode = UIViewContentModeScaleToFill;
    [self addSubview:self.cycleScrollView];

    
    __weak typeof (self)weakSelf = self;
    //分类
    float y = self.cycleScrollView.height-(kHeight(50));
    CGRect ret = CGRectMake(kWidth(10), y, SCREEN_WIDTH-(kWidth(20)), kHeight(200));
    self.categoryView = [[categoryView alloc] initWithFrame:ret];
    //阴影
    self.categoryView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.categoryView.layer.shadowOffset = CGSizeMake(2, 2);
    self.categoryView.layer.shadowOpacity = 1;
    self.categoryView.layer.shadowRadius = 5.0;
    self.categoryView.layer.cornerRadius = 5.0;
    self.categoryView.clipsToBounds = NO;
    
    self.categoryView.categoryTapBlock = ^(NSString *type, NSInteger tag) {
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(ViewTapClick:WithTag:)]) {
            [weakSelf.delegate ViewTapClick:type WithTag:tag];
        }
    };
    [self addSubview:self.categoryView];
    


 
    
    
    y +=self.categoryView.height;
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"我要申请专场" forState:0];
    [btn setTitleColor:[UIColor blackColor] forState:0];
    btn.titleLabel.font = [UIFont systemFontOfSize:15];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    btn.frame = CGRectMake(SCREEN_WIDTH-(kWidth(130)), y, kWidth(120), kHeight(40));
    [self addSubview:btn];
    
    UIImageView *imageMore = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"homepage_icon_goto_7_7"]];
    imageMore.frame = CGRectMake(SCREEN_WIDTH-(kWidth(20)), y+kHeight(12), kWidth(15), kHeight(15));
    [self addSubview:imageMore];
    
}

-(void)btnClick{
  
    if ( self.delegate && [self.delegate respondsToSelector:@selector(SpecialApply)]) {
        [self.delegate SpecialApply];
    }

}

-(void)test:(NSNotification *)noti{
    NSMutableArray *array = [NSMutableArray array];
    NSArray *arr = noti.object;

    for (int i =0; i <arr.count; i++) {
        AdvModel *model = arr[i];
        [array addObject:model.b_logo];
    }
    
    self.cycleScrollView.imageURLStringsGroup = array;
}

//移除通知方法
- (void)willMoveToWindow:(UIWindow *)newWindow {
    if (newWindow == nil) {
        // Will be removed from window, similar to -viewDidUnload.
        // Unsubscribe from any notifications here.
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"HomeNotification" object:nil];
    }
    
}

//添加通知方法
- (void)didMoveToWindow {
    if (self.window) {
        // Added to a window, similar to -viewDidLoad.
        // Subscribe to notifications here.
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(test:) name:@"HomeNotification" object:nil];
    }
    
}


/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    //DLog(@"%ld",index);
    
    if ( self.delegate && [self.delegate respondsToSelector:@selector(AdClickIndex:)]) {
        [self.delegate AdClickIndex:index];
    }
 
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
