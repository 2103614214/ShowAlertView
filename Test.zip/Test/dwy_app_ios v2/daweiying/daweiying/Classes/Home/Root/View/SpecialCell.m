//
//  SpecialCell.m
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "SpecialCell.h"
#import "SPecialModel.h"

@implementation SpecialCell
{
    UIImageView *_imageV;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.backgroundColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(180))];
        //[imageV setImage:[UIImage imageNamed:placeImageName]];
        [self.contentView addSubview:imageV];
        _imageV = imageV;
    }
    return self;
}

-(void)setModel:(SPecialModel *)model{
    _model = model;
    [_imageV sd_setImageWithURL:[NSURL URLWithString:model.activity_img]];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
