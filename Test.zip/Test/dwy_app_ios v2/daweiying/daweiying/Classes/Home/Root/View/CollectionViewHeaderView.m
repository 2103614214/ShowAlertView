//
//  CollectionViewHeaderView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CollectionViewHeaderView.h"


#import "HomeModel.h"

@interface CollectionViewHeaderView() <SDCycleScrollViewDelegate>




@end

@implementation CollectionViewHeaderView

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self)
    {
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    //200 100 40+160*w(*0.43)  40+125*w(/3)  165  40 20 = 605 + 285*w

    //设置轮播图
    self.cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(200)) delegate:self placeholderImage:[UIImage imageNamed:@""]];
    
    self.cycleScrollView.autoScrollTimeInterval = 3.0;
    _cycleScrollView.currentPageDotColor = [UIColor whiteColor];
    _cycleScrollView.pageDotColor = [UIColor colorWithHex:0xffffff alpha:0.5];
    _cycleScrollView.pageControlDotSize = CGSizeMake(8, 8);
  
    // 不设置标题
    self.cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleClassic;
    self.cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    
    self.cycleScrollView.bannerImageViewContentMode = UIViewContentModeScaleToFill;
    [self addSubview:self.cycleScrollView];
    //[SDCycleScrollView clearImagesCache]; 自动清楚缓存
    
    __weak typeof (self)weakSelf = self;
    
    float interval = kHeight(10);
    float y = self.cycleScrollView.height+interval;
    //全国特选
    CGRect ret = CGRectMake(0, y, SCREEN_WIDTH, kHeight(100));
    self.chanceV = [[chanceView alloc] initWithFrame:CGRectMake(kWidth(10), y, SCREEN_WIDTH-kWidth(20), kHeight(100))];
    self.chanceV.layer.cornerRadius = 15;
    self.chanceV.layer.masksToBounds = YES;
    [self addSubview:self.chanceV];
    
    
    //分类
    y += self.chanceV.height +interval;
    ret = CGRectMake(0, y, SCREEN_WIDTH, kHeight(100));
    self.categoryView = [[categoryView alloc] initWithFrame:ret];
    self.categoryView.categoryTapBlock = ^(NSString *type, NSInteger tag) {
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(ViewTapClick:WithTag:)]) {
            [weakSelf.delegate ViewTapClick:type WithTag:tag];
        }
    };
    [self addSubview:self.categoryView];
    
    //制造业热销
    y += self.categoryView.height +interval;
    ret = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_WIDTH*0.43+(kHeight(40)));
    self.hotSell = [[hotSellView alloc] initWithFrame:ret];
    self.hotSell.viewTypeChoose = isHotSellView;
    self.hotSell.headTitleStr = @"制造业热销";
    self.hotSell.imageTapBlock = ^(NSString *type, storeModel *model) {
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(ViewTapClick:WithModel:)]) {
            [weakSelf.delegate ViewTapClick:type WithModel:model];
        }
    };
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(titleLabelClick:)]) {
            [weakSelf.delegate titleLabelClick:1000];
        }
    }];
    [self.hotSell.titleLabel addGestureRecognizer:tap];
    
    [self addSubview:self.hotSell];
    
    //零售业精选
    y += self.hotSell.height +interval;
    ret = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_WIDTH/3+(kHeight(40)));
    self.selectionView = [[selectionView alloc] initWithFrame:ret];
    self.selectionView.imageViewBlock = ^(NSString *type,storeModel *model) {
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(ViewTapClick:WithModel:)]) {
            [weakSelf.delegate ViewTapClick:type WithModel:model];
        }
    };
    
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(titleLabelClick:)]) {
            [weakSelf.delegate titleLabelClick:1001];
        }
    }];
    [self.selectionView.titleLabel addGestureRecognizer:tap1];
    [self addSubview:self.selectionView];
    
    //服务业推选
    y += self.selectionView.height +interval;
//    ret = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_HEIGHT*0.25);
//    self.chooseView = [[hotSellView alloc] initWithFrame:ret];
//    self.chooseView.viewTypeChoose = isChooseView;
//    self.chooseView.headTitleStr = @"服务业推选";
//    self.chooseView.imageTapBlock = ^(NSString *type, NSInteger tag) {
//        if (self.delegate && [self.delegate respondsToSelector:@selector(ViewTapClick:WithTag:)]) {
//            [weakSelf.delegate ViewTapClick:type WithTag:tag];
//        }
//    };
//    [self addSubview:self.chooseView];
//
//    //品牌推广
//    y += self.chooseView.height +interval;
    
//    ret = CGRectMake(0, y, SCREEN_WIDTH, kHeight(165));
//    self.generalizeView = [[generalizeView alloc] initWithFrame:ret];
//    self.generalizeView.imageViewBlock = ^(NSString *type, storeModel *model) {
//        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(ViewTapClick:WithModel:)]) {
//            [weakSelf.delegate ViewTapClick:type WithModel:model];
//        }
//    };
//    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] init];
//    [[tap2 rac_gestureSignal] subscribeNext:^(id x) {
//        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(titleLabelClick:)]) {
//            [weakSelf.delegate titleLabelClick:1002];
//        }
//    }];
//    [self.generalizeView.titleLabel addGestureRecognizer:tap2];
//    [self addSubview:self.generalizeView];

    
   // y += self.generalizeView.height +interval;
    ret = CGRectMake(0, y, SCREEN_WIDTH, kHeight(40));
    UIView *margeView = [[publicHeadView alloc] initWithFrame:ret];
    [self addSubview:margeView];

}



-(void)test:(NSNotification *)noti{
        NSMutableArray *array = [NSMutableArray array];
        NSArray *arr = noti.object;
        self.dataArray = noti.object;
        for (int i =0; i <arr.count; i++) {
            AdvModel *model = arr[i];
            [array addObject:model.b_logo];
        }
    
    self.cycleScrollView.imageURLStringsGroup = array;
}

//移除通知方法
- (void)willMoveToWindow:(UIWindow *)newWindow {
    if (newWindow == nil) {
        // Will be removed from window, similar to -viewDidUnload.
        // Unsubscribe from any notifications here.
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"HomeNotification" object:nil];
    }
    
}

//添加通知方法
- (void)didMoveToWindow {
    if (self.window) {
        // Added to a window, similar to -viewDidLoad.
        // Subscribe to notifications here.
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(test:) name:@"HomeNotification" object:nil];
    }
   
}

/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    //DLog(@"%ld",index);
   
    if ( self.delegate && [self.delegate respondsToSelector:@selector(AdClickIndex:)]) {
        [self.delegate AdClickIndex:index];
    }
    
    
}


@end
