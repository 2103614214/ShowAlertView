//
//  hotSellView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//  制造业热销与服务业推选共用视图

#import <UIKit/UIKit.h>
@class storeModel;
typedef void (^imageTapBlock)(NSString *type,storeModel *model);

typedef enum {
    isHotSellView,
    isChooseView
} viewType;

@interface hotSellView : UIView

/** 分类页面选择 */
@property (nonatomic, assign) viewType viewTypeChoose;

/** 数据源 */
@property(nonatomic,strong)NSArray *dataArray;
/** 服务业推选 */
@property(nonatomic,strong)NSArray *servrsArray;

@property (nonatomic,copy) imageTapBlock imageTapBlock;

@property (nonatomic,copy) NSString *headTitleStr;


@property(nonatomic,strong)UILabel *titleLabel;;

@end
