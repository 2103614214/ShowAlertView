//
//  HomeModel.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel

@end


//商铺详情
@implementation storeModel


@end


//分类
@implementation catetorysModel



@end

//轮播图广告
@implementation AdvModel



@end
