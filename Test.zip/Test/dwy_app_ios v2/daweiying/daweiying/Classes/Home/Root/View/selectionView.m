//
//  selectionView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "selectionView.h"
#import "HomeModel.h"

@interface selectionView()

@property(nonatomic,strong)UIImageView *leftImageView;
@property(nonatomic,strong)UIImageView *middleImageView;
@property(nonatomic,strong)UIImageView *rightImageView;

@end

@implementation selectionView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLabel = [UILabel new];
    titleLabel.font = [UIFont systemFontOfSize:15];
    NSString *titleStr = @"零售业精选";
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:titleStr];
    [aString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHex:0xf4a81f]range:NSMakeRange(0, 3)];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial Rounded MT Bold"  size:(17.0)]range:NSMakeRange(0, 3)];
    titleLabel.attributedText= aString;
    titleLabel.userInteractionEnabled = YES;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:titleLabel];
    titleLabel.sd_layout
    .yIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(39))
    .xIs(0);
    self.titleLabel = titleLabel;
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line1];
    line1.sd_layout
    .topSpaceToView(titleLabel, 0)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    //左侧图片
    __weak typeof (self)weakSelf = self;
    UIImageView *leftImageView = [[UIImageView alloc] init];
    leftImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        [weakSelf categoryClick:0];
       // self.imageViewBlock(@"selection", 100);

    }];
    [leftImageView addGestureRecognizer:tap];
    [self addSubview:leftImageView];
    leftImageView.sd_layout
    .topSpaceToView(line1, 1)
    .leftSpaceToView(self, 0)
    .widthIs((SCREEN_WIDTH-2)/3)
    .heightIs(SCREEN_WIDTH/3);
    self.leftImageView = leftImageView;
    
    
    //中间竖线
    UILabel *line2 = [UILabel new];
    line2.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line2];
    line2.sd_layout
    .topSpaceToView(line1, 0)
    .leftSpaceToView(leftImageView, 0)
    .widthIs(1)
    .heightIs(leftImageView.height+1);
    
    
    //中间图片
    UIImageView *middleImageView = [[UIImageView alloc] init];
    middleImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf categoryClick:1];
        //self.imageViewBlock(@"selection", 101);
        
    }];
    [middleImageView addGestureRecognizer:tap1];
    [self addSubview:middleImageView];
    middleImageView.sd_layout
    .topSpaceToView(line1, 1)
    .leftSpaceToView(leftImageView, 1)
    .widthIs(leftImageView.width)
    .heightIs(leftImageView.height);
    self.middleImageView = middleImageView;
    
    //中间竖线
    UILabel *line3 = [UILabel new];
    line3.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [self addSubview:line3];
    line3.sd_layout
    .topSpaceToView(line1, 0)
    .leftSpaceToView(middleImageView, 0)
    .widthIs(1)
    .heightIs(leftImageView.height+1);
    
    //右侧图片
    UIImageView *rightImageView = [[UIImageView alloc] init];
    rightImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] init];
    [[tap3 rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf categoryClick:2];
       // self.imageViewBlock(@"selection", 102);
        
    }];
    [rightImageView addGestureRecognizer:tap3];
    [self addSubview:rightImageView];
    rightImageView.sd_layout
    .topSpaceToView(line1, 1)
    .leftSpaceToView(middleImageView, 1)
    .widthIs(leftImageView.width)
    .heightIs(leftImageView.height);
    self.rightImageView = rightImageView;
}

-(void)categoryClick:(int)type{
    
    storeModel *model = self.dataArray[type];
    if (model.t_pro_id > 0) {
        if (self.imageViewBlock) {
           // self.imageViewBlock(@"selection", model.t_pro_id);
           //self.imageViewBlock(@"selection", model.t_pro_id, model.t_type);
            self.imageViewBlock(@"selection",model);
        }
    }
}

-(void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    for (int i =0; i < _dataArray.count; i++) {
        storeModel *model = _dataArray[i];
        if (i == 0) {
            [self.leftImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 1){
            [self.middleImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 2){
            [self.rightImageView sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else{
            
            return;
        }
    }
}

@end
