//
//  V2HomeHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2018/3/31.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SDCycleScrollView.h>
#import "categoryView.h"

@protocol imageViewClickDelegate <NSObject>

//分类点击
- (void)ViewTapClick:(NSString *)type WithTag:(NSInteger)tag;

//广告图点击
-(void)AdClickIndex:(NSInteger)index;
//点击我要申请专场
-(void)SpecialApply;

@end

@interface V2HomeHeadView : UIView <SDCycleScrollViewDelegate>

/** 轮播图 */
@property(nonatomic,strong)SDCycleScrollView *cycleScrollView;
/** 分类 */
@property(nonatomic,strong)categoryView *categoryView;

@property (nonatomic,weak) id<imageViewClickDelegate> delegate;

@end
