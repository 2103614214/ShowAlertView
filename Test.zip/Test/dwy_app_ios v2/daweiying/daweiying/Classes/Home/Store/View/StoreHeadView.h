//
//  StoreHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface StoreHeadView : UIView


@property(nonatomic,strong)UIView *introView;

/** 头像url */
@property(nonatomic,copy)NSString *logoUrl;
/** 店铺名 */
@property(nonatomic,copy)NSString *storeNameStr;
/** 业务简介 */
@property(nonatomic,copy)NSString *introduceStr;

/** 点击分类 */
@property(nonatomic,copy) void (^categoryClickBlock)(NSInteger tag);

@end
