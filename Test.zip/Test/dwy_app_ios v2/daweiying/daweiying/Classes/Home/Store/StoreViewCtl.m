//
//  StoreViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "StoreViewCtl.h"
#import "StoreHeadView.h"

#import "CompanyCollectionCell.h"
#import "CompanyMakeLayout.h"
#import "makeMenuCateModel.h"
#import "DWYDetailsViewCtl.h"
#import "StoreIntroViewCtl.h"
#import "IQKeyboardManager.h"

@interface StoreViewCtl ()  <UICollectionViewDelegate, UICollectionViewDataSource,UITextFieldDelegate>

/** collectionView */
@property (nonatomic, strong) UICollectionView *collectionView;
/** 商品数据源 */
@property(nonatomic,strong)NSMutableArray *productMutableArr;
/** 头部视图 */
@property(nonatomic,strong)StoreHeadView *headView;
///** 头部数据源 */
//@property(nonatomic,strong)NSDictionary *headDataDict;
/** 搜索框 */
@property(nonatomic,strong)UITextField *searchText;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;
/** 请求类型 */
@property(nonatomic,assign)NSInteger requestID;

@end

static NSString * const StoreCellID = @"StoreCellID";
@implementation StoreViewCtl

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, kNavBarStatusHeight+self.headView.height, SCREEN_WIDTH, SCREEN_HEIGHT-self.headView.height-kNavBarStatusHeight) collectionViewLayout:[[CompanyMakeLayout alloc] init]];
        [_collectionView registerClass:[CompanyCollectionCell class] forCellWithReuseIdentifier:StoreCellID];
        
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        
    }
    return _collectionView;
}

-(NSMutableArray *)productMutableArr{
    if (!_productMutableArr) {
        _productMutableArr = [NSMutableArray array];
    }
    return _productMutableArr;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    self.navigationItem.titleView = [[UIView alloc] initWithFrame:CGRectMake(kWidth(40), 4, SCREEN_WIDTH-(kHeight(60)), 30)];
    self.navigationItem.titleView.backgroundColor = [UIColor whiteColor];
    self.navigationItem.titleView.layer.cornerRadius = 5;
    self.navigationItem.titleView.layer.masksToBounds = YES;
    self.navigationItem.titleView.userInteractionEnabled = YES;
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"food_btn_search_22_22"]];
    imageV.frame = CGRectMake(10, 6, 18, 18);
    [self.navigationItem.titleView addSubview:imageV];
    
    UITextField *searchText = [Utils addTextFieldWithFrame:CGRectMake(42, 0, 300, 30) AndStr:@"商品名称" AndFont:14 AndTextColor:[UIColor blackColor]];
    searchText.delegate = self;
    searchText.keyboardType = UIKeyboardTypeWebSearch;
    searchText.textAlignment = NSTextAlignmentLeft;
    [self.navigationItem.titleView addSubview:searchText];
    self.searchText = searchText;
    
   
    __weak typeof (self)weakSelf = self;
    CGRect ret = CGRectMake(0, kNavBarStatusHeight, SCREEN_WIDTH, kHeight(140));
    self.headView = [[StoreHeadView alloc] initWithFrame:ret];
    [self.view addSubview:self.headView];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        StoreIntroViewCtl *vc = [[StoreIntroViewCtl alloc] init];
        vc.store_id = weakSelf.store_id;
        [weakSelf.navigationController pushViewController:vc animated:YES];
    }];
    [self.headView.introView addGestureRecognizer:tap];
    self.headView.categoryClickBlock = ^(NSInteger tag) {
        weakSelf.requestID = tag -100;
        
        [weakSelf loadData]; //请求相应数据
    };
    [self.view addSubview:self.collectionView];
    
    //默认是综合1
    self.requestID = 1;
    // 添加刷新控件
    [self setupRefresh];
    

    //通知
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"delProduct" object:nil] subscribeNext:^(NSNotification *notification) {
        
        [weakSelf loadData];
    }];

}

-(void)setupRefresh{
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.collectionView.mj_header.automaticallyChangeAlpha = YES;
    [self.collectionView.mj_header beginRefreshing];
    
    self.collectionView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [IQKeyboardManager sharedManager].enableAutoToolbar = NO;
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [IQKeyboardManager sharedManager].enableAutoToolbar = YES;
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBar.hidden = NO;
}

-(void)loadData{
    [MBManager showLoading];
    
    [self.collectionView.mj_footer endRefreshing];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.store_id);
    params[@"order"] = @(self.requestID);
    NSString *urlStr = [Utils getMemberServiceUri:@"store"];
    
    //NSLog(@"%@",params);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        
        [self.collectionView.mj_header endRefreshing];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [[dataObject objectForKey:@"result"] objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            self.headView.storeNameStr = [[dataObject objectForKey:@"result"] objectForKey:@"s_name"];
            self.headView.logoUrl = [[dataObject objectForKey:@"result"] objectForKey:@"s_logo"];
            self.headView.introduceStr = [[dataObject objectForKey:@"result"] objectForKey:@"s_introduce"];
            
//            id s_id = [[dataObject objectForKey:@"result"] objectForKey:@"s_id"];
//            id s_type = [[dataObject objectForKey:@"result"] objectForKey:@"type"];
            //存储店铺信息
//            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
//            [ud setObject:s_id forKey:@"store_id"];
//            [ud setObject:s_type forKey:@"store_type"];  //店铺类型
//            [ud synchronize];
            
            
            //品牌推广数据源
            NSDictionary *hotDict = [[dataObject objectForKey:@"result"] objectForKey:@"goods"];
            self.productMutableArr = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            if (self.productMutableArr.count > 0) {
                [self.collectionView hideBlankPageView];
            }else{
                [self.collectionView showBlankPageView:10];
            }
            [self.collectionView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        //NSLog(@"%@",error);
        [MBManager showError];
        [self.collectionView.mj_header endRefreshing];
        if (self.params != params) return;
    }];
    
}

//上拉刷新请求
-(void)loadMoreDatas{
    // 结束下拉
    [self.collectionView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"到底了"];
        [self.collectionView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.store_id);
    params[@"order"] = @(self.requestID);
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"store"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *hotDict = [[dataObject objectForKey:@"result"] objectForKey:@"goods"];
            NSArray *newProducts = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            [self.productMutableArr addObjectsFromArray:newProducts];
            
            [self.collectionView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.collectionView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_footer endRefreshing];
        if (self.params != params) return;
    }];
    
}

#pragma mark UICollectionViewDataSource 数据源方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.productMutableArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CompanyCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:StoreCellID forIndexPath:indexPath];
    cell.model = self.productMutableArr[indexPath.row];
    return cell;
}

#pragma mark UICollectionView 代理方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    DLog(@"点击了%ld----%ld",indexPath.section,indexPath.row);
    companyMakeModel *model = self.productMutableArr[indexPath.row];
    DWYDetailsViewCtl *productCtl = [[DWYDetailsViewCtl alloc] init];
    productCtl.productID = model.pro_id;
    productCtl.type = isStore;
    [self.navigationController pushViewController:productCtl animated:YES];
}

#pragma mark --  textField代理方法
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField.text.length > 0) {
        [self searchText:textField.text];
    }
    [self.searchText resignFirstResponder];
    
    return YES;
    
}

-(void)searchText:(NSString *)keywords{
    [MBManager showLoading];
    
    [self.productMutableArr removeAllObjects];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"keywords"] = keywords;
    params[@"s_id"] = @(self.store_id);
    NSString *urlStr = [Utils getMemberServiceUri:@"searchGoods"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        [self.collectionView.mj_header endRefreshing];
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];

            //品牌推广数据源
            NSDictionary *hotDict = [dataObject objectForKey:@"goods"];
            self.productMutableArr = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            if (self.productMutableArr.count > 0) {
                [self.collectionView hideBlankPageView];
            }else{
                [self.collectionView showBlankPageView:5];
            }
     
            
        }else if ([status isEqualToString:@"401"]){ //没有商品
            [self.collectionView showBlankPageView:5];
        }
        else{
            [MBManager showError:@"获取数据失败"];
        }
        
        [self.collectionView reloadData];
 
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
