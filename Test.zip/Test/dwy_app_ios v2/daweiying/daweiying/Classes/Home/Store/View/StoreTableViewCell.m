//
//  StoreTableViewCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "StoreTableViewCell.h"
#import "StoreModel.h"

@implementation StoreTableViewCell
{
    UIImageView *_imageV;
    UILabel     *_productNameLabel;
    UILabel     *_productIntroLabel;
    UILabel     *_priceLabel;
    UIImageView *_shoppingCarImg;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)
reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        //图片
        _imageV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 100, 80)];
        _imageV.layer.borderColor = [UIColor colorWithHex:0xd7d7d7].CGColor;
        _imageV.layer.borderWidth = 1;
        [self.contentView addSubview:_imageV];
        
        //产品名称
        _productNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(120, 10, 200, 40)];
        _productNameLabel.font = [UIFont systemFontOfSize:15];
        _productNameLabel.numberOfLines = 2;
        [self.contentView addSubview:_productNameLabel];
        
        //产品简介
        _productIntroLabel = [[UILabel alloc] initWithFrame:CGRectMake(120, 50, self.width/2, 20)];
        _productIntroLabel.font = [UIFont systemFontOfSize:13];
        _productIntroLabel.textColor = [UIColor colorWithHex:0x999999];
        [self.contentView addSubview:_productIntroLabel];
        
        //价格
        _priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(120, 70, self.width/2, 20)];
        _priceLabel.font = [UIFont systemFontOfSize:15];
        _priceLabel.textColor = [UIColor colorWithHex:0xf67100];
        [self.contentView addSubview:_priceLabel];
        
        UIImage *img = [UIImage imageNamed:@"shopstore_btn_shoppingcart1_25_25"];
        _shoppingCarImg = [[UIImageView alloc] initWithImage:img];
        [self.contentView addSubview:_shoppingCarImg];
        _shoppingCarImg.sd_layout
        .bottomSpaceToView(self.contentView, 20)
        .rightSpaceToView(self.contentView, 10)
        .widthIs(35)
        .heightIs(35);
    }
    
    
    return self;
}

-(void)setModel:(StoreProductsModel *)model{
    _model = model;
    
    
    [_imageV sd_setImageWithURL:[NSURL URLWithString:model.logo_url] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    _productNameLabel.text = model.pro_name;
    
    
    _productIntroLabel.text = model.pro_attr;

    NSString *balance =[NSString stringWithFormat:@"¥ %.0f",model.price];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:balance];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(14.0)]range:NSMakeRange(0, 1)];
    _priceLabel.attributedText= aString;

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
