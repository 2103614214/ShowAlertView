//
//  StoreIntroViewCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/13.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"

@interface StoreIntroViewCtl : BaseViewController

/** 商铺id */
@property(nonatomic,assign)int store_id;

@end
