//
//  StoreIntroViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/13.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "StoreIntroViewCtl.h"
#import "RatingView.h"
#import "ChatViewController.h"


@interface StoreIntroViewCtl () <UITableViewDelegate,UITableViewDataSource>
/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSArray *dataArray;
/** 店铺评分 */
@property(nonatomic,assign)float score;
/** 电话 */
@property(nonatomic,copy)NSString *telStr;
/** 店铺聊天id */
@property(nonatomic,copy)NSString *c_id;
/** 店铺名 */
@property(nonatomic,copy)NSString *s_name;

@property(nonatomic,strong)UIButton *telBtn;
@property(nonatomic,strong)UIButton *ServiceBtn;


@end

@implementation StoreIntroViewCtl

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initWithTableView];
    
    [self loadDataWithServer];
}

-(void)initWithTableView{
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH,SCREEN_HEIGHT - (kHeight(56)))];
    [self.view addSubview:self.tableView];
    self.tableView.backgroundColor = [UIColor colorWithHex:0xefeff4];
    if (@available(iOS 11.0, *)) {
        _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        _tableView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, kTabBarHeight, 0);
        _tableView.scrollIndicatorInsets = _tableView.contentInset;
    }
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.tableView.showsVerticalScrollIndicator = NO;
    
    __weak typeof (self)weakSelf = self;
    //联系客服
    UIButton *ServiceBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-(kHeight(56)), SCREEN_WIDTH/2, kHeight(56))];
    [ServiceBtn setTitle:@"联系客服" forState:0];
    //ServiceBtn.backgroundColor = [UIColor colorWithHex:0xf7ebdd];
    [ServiceBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xf7ebdd]] forState:UIControlStateNormal];
    [ServiceBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xf7d7b2]] forState:UIControlStateHighlighted];
    ServiceBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [ServiceBtn setTitleColor:[UIColor orangeColor] forState:0];
    [[ServiceBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
       
        ChatViewController *chatController = [[ChatViewController alloc] initWithConversationChatter:weakSelf.c_id conversationType:EMConversationTypeChat];
        chatController.titleStr = weakSelf.s_name;
        [weakSelf.navigationController pushViewController:chatController animated:YES];
    
    }];
    [self.view addSubview:ServiceBtn];
    self.ServiceBtn = ServiceBtn;
    
    //拨打电话
    UIButton *telBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH/2, SCREEN_HEIGHT-(kHeight(56)), SCREEN_WIDTH/2, kHeight(56))];
    [telBtn setTitle:@"拨打电话" forState:0];
    //telBtn.backgroundColor = [UIColor colorWithHex:0xff9602];
    [telBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xff9602]] forState:UIControlStateNormal];
    [telBtn setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHex:0xe58703]] forState:UIControlStateHighlighted];
    telBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [[telBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {

        [Utils callTel:weakSelf.telStr];  //打电话
    }];
    [self.view addSubview:telBtn];
    self.telBtn = telBtn;
  
    
    
}

-(void)loadDataWithServer{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.store_id);
    NSString *urlStr = [Utils getMemberServiceUri:@"message"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSDictionary *dict = [dataObject objectForKey:@"message"];
            self.telStr = dict[@"s_phone"];
            id cid = [dict objectForKey:@"c_id"];
            id s_id = [dict objectForKey:@"s_id"];
            id me_id = [appDelegate.appDefault objectForKey:@"store_id"];
            if ([s_id intValue] == [me_id intValue]) { //判断是不是自己
                self.ServiceBtn.hidden = YES;
                self.telBtn.hidden = YES;
            }
            self.c_id = [NSString stringWithFormat:@"%d",[cid intValue]];
            self.s_name = dict[@"s_name"];
            id score = dict[@"grade"];
            self.score = [score floatValue];
            self.title = dict[@"s_name"];
            [self getData:dict];
            
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.tableView reloadData];
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}

-(void)getData:(NSDictionary *)dict{
    NSString *nameStr = [NSString stringWithFormat:@"店铺名称: %@",dict[@"s_name"]];
    id type = dict[@"type"];
    NSString *categoryStr;
    if ([type intValue]== 1) {
        categoryStr = @"经营大类: 日常零售";
    }else if ([type intValue] == 2){
        categoryStr = @"经营大类: 企业制造";
    }
    NSString *introduce = [NSString stringWithFormat:@"主营业务: %@",dict[@"s_introduce"]];
    id number = dict[@"goods_count"];
    NSString *numberStr = [NSString stringWithFormat:@"商品数量: %ld",[number integerValue]];
    //NSString *telStr = [NSString stringWithFormat:@"联系电话: %@",dict[@"s_phone"]];
   
    
    NSString *address = dict[@"s_place"];
    NSString *addressStr;
    if ([Utils isBlankString:address]) {
        addressStr = @"商家地址: ";
    }else{
        addressStr = [NSString stringWithFormat:@"商家地址: %@",address];
    }

    NSString *telName = dict[@"user_name"];
    NSString *storeRank;
    if ([Utils isBlankString:telName]) {
        storeRank = @"联系人: ";
    }else{
        storeRank = [NSString stringWithFormat:@"联系人: %@",telName];
    }
   // NSString *storeRank = [NSString stringWithFormat:@"联系电话: %@",dict[@"s_phone"]];
    self.dataArray = @[@[nameStr,introduce,numberStr],
                       @[storeRank,addressStr]];
}

#pragma mark -  代理 && 数据源
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 3;
    }else{
        return 2;
    }
//    else{
//        return 1;
//    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 1 && indexPath.row == 1) {
        return kHeight(80);
    }else{
        return kHeight(50);
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellID"];
    }
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.font = [UIFont systemFontOfSize:15];
    cell.textLabel.text = self.dataArray[indexPath.section][indexPath.row];
//    if (indexPath.section == 2 && indexPath.row == 0) {
//        RatingView * rView = [[RatingView alloc]initWithFrame:CGRectMake(kWidth(95), kHeight(10), kWidth(120), kHeight(30)) isEdit:NO];
//        //rView.ratingType = INTEGER_TYPE;//整颗星
////        NSLog(@"-----%@",str);
//        rView.score = self.score;
//        [cell addSubview:rView];
//    }
    return cell;
}

//格式化
- (NSString *)floatV:(float)floatV
{
    NSString *string = [NSString stringWithFormat:@"%.1f",self.score];
    
    
    
    return string;
    
}

//点击方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return kHeight(15);
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *bgV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(15))];
    
    return bgV;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
