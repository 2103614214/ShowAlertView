//
//  StoreModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StoreProductsModel : NSObject
/** 商品属性 */
@property (nonatomic,copy) NSString *pro_attr;
/** 商品名 */
@property (nonatomic,copy) NSString *pro_name;
/** 价格 */
@property (nonatomic,assign) float price;
/** 商品logo */
@property (nonatomic,copy) NSString *logo_url;
/** 商家id */
@property (nonatomic,assign) int store_id;
/** 商品id */
@property(nonatomic,assign)int pro_id;

/** 经度 */
@property(nonatomic,assign)double longitude;
/** 纬度 */
@property(nonatomic,assign)double latitude;

@end

