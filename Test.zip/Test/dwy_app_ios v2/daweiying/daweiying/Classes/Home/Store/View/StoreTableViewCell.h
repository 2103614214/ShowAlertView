//
//  StoreTableViewCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class StoreProductsModel;

@interface StoreTableViewCell : UITableViewCell

/** 数据 */
@property(nonatomic,strong)StoreProductsModel *model;
@end
