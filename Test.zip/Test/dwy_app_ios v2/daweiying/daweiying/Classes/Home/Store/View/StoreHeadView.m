//
//  StoreHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/21.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "StoreHeadView.h"
#import "StoreModel.h"

@implementation StoreHeadView
{
    UIImageView *_headLogo;
    UILabel     *_storeName;
    UILabel     *_introduceLabel;
    UIView *_categoryV;
    UIImageView *_priceStatus;
    BOOL _isSelected;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        [self initWithSubViews]; //初始化控件
    }
    return self;
}
//100 40
-(void)initWithSubViews{
    self.backgroundColor = [UIColor colorWithHex:0xefeff4];
    //商户简介视图
    UIView *introView = [[UIView alloc] init];
    introView.backgroundColor = [UIColor whiteColor];
    introView.userInteractionEnabled = YES;
    [self addSubview:introView];
    introView.sd_layout
    .topSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_HEIGHT)
    .heightIs(kHeight(90));
    self.introView = introView;
    
    UIImageView *logoImageV = [[UIImageView alloc] init];
    logoImageV.frame = CGRectMake(10, kHeight(10), introView.height-(kHeight(20)), introView.height-(kHeight(20)));
    logoImageV.layer.cornerRadius = logoImageV.width/2;
    logoImageV.layer.masksToBounds = YES;
    logoImageV.layer.borderColor = [UIColor colorWithHex:0xd7d7d7].CGColor;
    logoImageV.layer.borderWidth = 1;
    [introView addSubview:logoImageV];
    _headLogo = logoImageV;
    
    UILabel *storeName = [UILabel new];
    storeName.font = [UIFont systemFontOfSize:16.0f];
    [introView addSubview:storeName];
    storeName.sd_layout
    .yIs(kHeight(18))
    .leftSpaceToView(logoImageV, 10)
    .widthIs(180)
    .heightIs(21);
    _storeName = storeName;
    
    UILabel *introduceLabel = [UILabel new];
    introduceLabel.numberOfLines = 0;
    introduceLabel.font = [UIFont systemFontOfSize:13.0f];
    introduceLabel.textColor = [UIColor colorWithHex:0x999999];
    [introView addSubview:introduceLabel];
    introduceLabel.sd_layout
    .topSpaceToView(storeName, 5)
    .leftSpaceToView(logoImageV, 10)
    .widthIs(180)
    .heightIs(35);
    _introduceLabel = introduceLabel;
    
    UILabel *moreLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"更多信息"];
    moreLabel.textAlignment = NSTextAlignmentRight;
    moreLabel.frame = CGRectMake(SCREEN_WIDTH-(kWidth(115)), kHeight(30), kWidth(90), kHeight(30));
    [self addSubview:moreLabel];
    
    UIImageView *pullV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"shopstore_btn_goto_13_13"]];
    pullV.alpha = 0.7;
    pullV.frame = CGRectMake(SCREEN_WIDTH-25, kHeight(35), 15, 18);
    [self addSubview:pullV];
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, kHeight(90), SCREEN_WIDTH, 0.5)];
    [self addSubview:line];
    
    UIView *categoryV = [[UIView alloc] init];
    categoryV.backgroundColor = [UIColor whiteColor];
    [self addSubview:categoryV];
    categoryV.sd_layout
    .topSpaceToView(line, 0)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(49));
    _categoryV = categoryV;
    
    float labelW = SCREEN_WIDTH/4;
    float labelH = kHeight(49);
    float x = 0;
    NSArray *nameArr = [NSArray arrayWithObjects:@"综合",@"销量",@"新品",@"价格", nil];
    __weak typeof (self)weakSelf = self;
    for (int i = 0; i<4; i++) {
        UIButton *btn = [[UIButton alloc] init];
        [btn setTitle:nameArr[i] forState:0];
        btn.titleLabel.textAlignment = NSTextAlignmentCenter;
        btn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
        btn.frame = CGRectMake(x, 0, labelW, labelH);
        btn.tag = 101+i;
        [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
            [weakSelf btnClick:btn];
        }];
        [btn setTitleColor:[UIColor colorWithHex:0x666666] forState:0];
        [categoryV addSubview:btn];
        if (i == 0) {
            [btn setTitleColor:[UIColor colorWithHex:UI_COLOR_ORANGE] forState:0];
        }
        if (i >0) {
            UILabel *line = [Utils lineWithFrame:CGRectMake(x, kHeight(8), 1, kHeight(33))];
            [categoryV addSubview:line];
        }
 
        x +=btn.width;
        
    }
    
    UIImageView *priceStatus = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-(kWidth(25)), kHeight(17), kWidth(13), kHeight(15))];
    [categoryV addSubview:priceStatus];
    _priceStatus = priceStatus;
  
}

-(void)btnClick:(UIButton *)btn{
    btn.selected  = !btn.selected;
    for (UIButton *btn in _categoryV.subviews) {
        if ([btn isKindOfClass:[UIButton class]]) {
            [btn setTitleColor:[UIColor colorWithHex:0x666666] forState:0];
        }
    }
    
    [btn setTitleColor:[UIColor colorWithHex:UI_COLOR_ORANGE] forState:0];
    if (btn.tag == 104) {
        _isSelected = btn.selected;
        if (_isSelected) {
            [_priceStatus setImage:[UIImage imageNamed:@"search_btn_rankDown"]];
            if (self.categoryClickBlock) {
                self.categoryClickBlock(105);
            }
        }else{
            [_priceStatus setImage:[UIImage imageNamed:@"search_btn_rankUp"]];
            if (self.categoryClickBlock) {
                self.categoryClickBlock(104);
            }
        }
    }else{
        if (self.categoryClickBlock) {
            self.categoryClickBlock(btn.tag);
        }
    }
}
-(void)setLogoUrl:(NSString *)logoUrl{
    _logoUrl = logoUrl;
    [_headLogo sd_setImageWithURL:[NSURL URLWithString:logoUrl] placeholderImage:[UIImage imageNamed:@"shopstore_img_logo_45_45"]];
}

-(void)setStoreNameStr:(NSString *)storeNameStr{
    _storeNameStr = storeNameStr;
    _storeName.text = storeNameStr;
}

-(void)setIntroduceStr:(NSString *)introduceStr{
    _introduceStr = introduceStr;
    _introduceLabel.text = introduceStr;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
