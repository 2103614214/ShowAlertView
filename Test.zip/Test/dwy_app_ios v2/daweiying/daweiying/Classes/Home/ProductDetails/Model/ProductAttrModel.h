//
//  ProductAttrModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/8.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface ProductAttrModel : BaseModel

/** 单选,多选 */
@property(nonatomic,copy)NSString *check;
/** 属性名 */
@property(nonatomic,copy)NSString *attribute;
/** 属性 */
@property(nonatomic,assign)NSInteger repertory;

/** 购买数量 */
@property(nonatomic,assign)NSInteger buyNumber;

@end
