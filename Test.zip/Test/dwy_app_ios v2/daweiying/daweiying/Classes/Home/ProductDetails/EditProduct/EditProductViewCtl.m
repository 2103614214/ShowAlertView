//
//  EditProductViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2018/1/11.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "EditProductViewCtl.h"
#import "EditProCountCell.h"
#import "EditProductModel.h"

@interface EditProductViewCtl ()


@end

static NSString * const editProductId = @"editProductId";
@implementation EditProductViewCtl



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"库存";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:(UIBarButtonItemStylePlain) target:self action:@selector(saveBtnClick)];
    [self.navigationItem.rightBarButtonItem setTintColor:[UIColor orangeColor]];
    
    [self initWithTableView];
}

-(void)initWithTableView{
    
    // 代理&&数据源
    self.tableView.rowHeight = kHeight(100);
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        self.tableView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, kTabBarHeight, 0);
        self.tableView.scrollIndicatorInsets = self.tableView.contentInset;
    }
    [self.tableView registerClass:[EditProCountCell class] forCellReuseIdentifier:editProductId];
}

-(void)saveBtnClick{
   
    NSMutableArray *dataArr = [NSMutableArray array];
    for (EditProductModel *model in self.dataArray) {
        
        if ([Utils isBlankString:model.repertory]) {
            [MBManager showBriefAlert:@"库存数不能为空"];
            return;
        }else{
            NSMutableDictionary *dict = [NSMutableDictionary dictionary];
            dict[@"attribute"] = model.attribute;
            dict[@"number"] = model.repertory;
            [dataArr addObject:dict];
        }
    }
    NSString *jsonStr = [Utils jsonStrTransform:dataArr];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"pro_id"] = @(self.pro_id);
    params[@"attr"] = jsonStr;
    
    [MBManager showLoading];

    
    NSString *urlStr = [Utils getMemberServiceUri:@"updateGoodsRepertory"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"修改成功"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                KPostNotification(@"editProductCount", nil);
                [self.navigationController popViewControllerAnimated:YES];
            });
            
        }else{
            [MBManager showError:hint];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];

}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.dataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    EditProCountCell *cell = [tableView dequeueReusableCellWithIdentifier:editProductId forIndexPath:indexPath];
    if (!cell) {
        cell = [[EditProCountCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:editProductId];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone; //取消点中效果
    cell.model = self.dataArray[indexPath.section];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return kHeight(10);
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *bgv = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(10))];
    
    return bgv;
}


////点击方法
//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//
//
//
//}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
