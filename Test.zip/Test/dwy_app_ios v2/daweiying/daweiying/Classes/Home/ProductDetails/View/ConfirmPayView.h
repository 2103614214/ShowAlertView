//
//  ConfirmPayView.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ConfirmPayView : UIView <UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) NSArray *objects;
@property (nonatomic,strong) NSArray *imageArr;
/** 总价 */
@property(nonatomic,copy)NSString *totalPrice;

@property (nonatomic,strong) UITableView *tableView;

@property (nonatomic,copy) NSString *selectedStr;

/** 关闭 */
@property(nonatomic,copy) void (^closeView)();
/** 立即支付 */
@property(nonatomic,copy) void (^payBlock)(NSString *payType);

-(instancetype)initWithFrame:(CGRect)frame WithStr:(NSString *)str WithPrice:(NSString *)price;

@end
