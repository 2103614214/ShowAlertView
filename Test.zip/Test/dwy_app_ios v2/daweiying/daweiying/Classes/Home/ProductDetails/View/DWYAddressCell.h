//
//  DWYAddressCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/26.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DWYAddressModel;

typedef void (^cellClickBlock)(NSInteger tag);

@interface DWYAddressCell : UITableViewCell

/** 模型 */
@property(nonatomic,strong)DWYAddressModel *model;
@property (nonatomic,copy) cellClickBlock block;

@property(nonatomic,strong)UILabel *addressLabel;

@end
