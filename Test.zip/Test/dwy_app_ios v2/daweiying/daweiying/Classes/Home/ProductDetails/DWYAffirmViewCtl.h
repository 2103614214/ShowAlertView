//
//  DWYAffirmViewCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"

typedef NS_ENUM(NSInteger, CloseType){
    CloseTypeTypeGoodsNone,
    CloseTypeTypeCartNone
};

@interface DWYAffirmViewCtl : BaseViewController

/** 从商品详情跳转过来的json这符串 */
@property(nonatomic,copy)NSString *jsonStr;
/** 商品id */
@property(nonatomic,assign)int pro_id;
/** goodIDs */
@property(nonatomic,copy)NSString *goodIds;
/** 商品总价 */
@property(nonatomic,assign)float totalMoney;

/** 是直接买单，还是购物车跳转买单 */
@property(nonatomic,assign)CloseType type;
@end
