//
//  DWYFootView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DWYFootView : UIView

/** 购买 */
@property(nonatomic,strong)UIButton *buyButton;
/** 加入购物车 */
@property(nonatomic,strong)UIButton *addShoppingCarButton;
/** 聊天 */
@property(nonatomic,strong)UIView *IMView;
/** 收藏 */
@property(nonatomic,strong)UIView *collectView;
/** 进店 */
@property(nonatomic,strong)UIView *storeView;
/** 收藏文本 */
@property(nonatomic,strong)UILabel *collectLabel;
/** 是否收藏 */
@property(nonatomic,strong)UIImageView *collectImageV;

@end



@interface DWYIsMeFootView : UIView

-(instancetype)initWithFrame:(CGRect)frame Withtype:(int)type;

/** 删除 */
@property(nonatomic,strong)UIButton *delBtn;

/** 上/下架 */
@property(nonatomic,strong)UIButton *putawayBtn;

/** 库存 */
@property(nonatomic,strong)UIButton *countBtn;

@end
