//
//  DWYAffirmViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAffirmViewCtl.h"

#import "DWYAffirmCell.h"
#import "DWYAffirmModel.h"
#import "DWYAffirmHeadView.h"

#import "DWYManageAddressCtl.h"

#import "ShowAnimationView.h"
#import "DWYSelectView.h"
#import "NSObject+Property.h"
#import "DWYAffirmCartModel.h"
#import "NSObject+Property.h"
#import "WeChatManager.h"
#import "ConfirmPayView.h"

#import "PayPasswordViewCtl.h"
#import "PayTypeView.h"
#import "OrderManager.h"
#import "OrderCountCtl.h"
#import "addBoundViewCtl.h"
@interface DWYAffirmViewCtl () <UITableViewDelegate,UITableViewDataSource,sendAddressDelegate>

/** tableview */  // 500*500
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;
/** headView */
@property(nonatomic,strong)DWYAffirmHeadView *headView;
///** footView */
//@property(nonatomic,strong)DWYAffirmFootView *footView;

/** 底部蒙板层 */
@property(nonatomic,strong)ShowAnimationView *showView;

/** 配送方式 */
@property(nonatomic,strong)NSArray *sendTypeArr;
/** 数据模型 */
@property(nonatomic,strong)DWYAffirmModel *model;
/** 总计 */
@property(nonatomic,strong)UILabel *countPriceLabel;
/** 总价 */
@property(nonatomic,copy)NSString *totalPriceStr;

/** 分类数据源 */
@property(nonatomic,strong)NSMutableArray *categoryArr;
/** 地址主键id */
@property(nonatomic,copy)NSString *addressID;
/** 总价 */
@property(nonatomic,copy)NSString *totalPrice;

/** 支付方式 */
@property(nonatomic,copy)NSString *payStr;
/** 保存支付签名 */
@property(nonatomic,copy)NSString *signStr;
/** 邮费状态 */
@property(nonatomic,assign)int freightStatus;
/** 当状态为待议时， 邮费的值 */
@property(nonatomic,assign)float freightPrice;

/** 临时存储订单号 */
@property(nonatomic,copy)NSString *tempOrderNumber;

@end

static NSString * const AffirmCellID = @"AffirmCellID";
@implementation DWYAffirmViewCtl



-(NSArray *)sendTypeArr{
    if (!_sendTypeArr) {
        _sendTypeArr = [NSArray arrayWithObjects:@"快递",@"上门自取",@"同城配送", nil];
    }
    return _sendTypeArr;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableArray *)categoryArr{
    if (!_categoryArr) {
        _categoryArr = [NSMutableArray array];
    }
    return _categoryArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    

    [self setupTableView];  //初始化tableview
    
    [self initWithBottomView]; //初始化底部视图
    
    [self loadData];//请求数据
    
    self.addressID = [appDelegate.appDefault objectForKey:@"address_id"];
    
   // self.payStr = @"付甲一方";
    
    __weak typeof (self)weakSelf = self;
    //钱包余额，付甲一方支付成功
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"fujiaPaySuccess" object:nil] subscribeNext:^(NSNotification *notification) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // [weakSelf.navigationController popToRootViewControllerAnimated:YES];
            for (UIViewController *controller in self.navigationController.viewControllers) {
                if ([controller isKindOfClass:[MainTabBarController class]]) {
                    [weakSelf.navigationController popToViewController:controller animated:YES];
                }
            }
        });
       
    }];
    
    //钱包余额，付甲一方支付失败
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"fujiaPayFail" object:nil] subscribeNext:^(NSNotification *notification) {
        //[weakSelf PayType];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            OrderCountCtl *vc = [[OrderCountCtl alloc] init];
            vc.jumpType = 1;
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
    }];
    
}

-(void)dealloc{
    //DLog(@"---dealloc");
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)setupTableView{
    
    self.title = @"确认订单";
    __weak typeof (self)weakSelf = self;
    self.headView = [[DWYAffirmHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(81))];

//    self.footView = [[DWYAffirmFootView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(195))];
//    //更新总价
//    self.footView.countTotalPriceBlock = ^(float price) {
//        float oldePrice = [weakSelf.totalPrice floatValue];
//        float newPrice = oldePrice + price - weakSelf.freightPrice;
//        weakSelf.totalPrice = [NSString stringWithFormat:@"%.2f",newPrice];
//        weakSelf.countPriceLabel.text = [NSString stringWithFormat:@"¥ %.2f",newPrice];
//        weakSelf.footView.t_priceLabel.text = [NSString stringWithFormat:@"%.2f",price];
//        weakSelf.freightPrice = price;
//    };
    //添加tap
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) { //跳转地址选择
        
        DWYManageAddressCtl *address  = [DWYManageAddressCtl new];
        address.delegate = weakSelf;
        [weakSelf.navigationController pushViewController:address animated:YES];

    }];
    [self.headView.addressView addGestureRecognizer:tap];



    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-49) style:UITableViewStyleGrouped];
    if (@available(iOS 11.0, *)) {
        _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        _tableView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, kTabBarHeight, 0);
        _tableView.scrollIndicatorInsets = _tableView.contentInset;
    }
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 100;
    self.tableView.tableHeaderView = self.headView;
    //self.tableView.tableFooterView = self.footView;
    self.tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    self.tableView.showsVerticalScrollIndicator = NO;
    [self.tableView registerClass:[DWYAffirmCell class] forCellReuseIdentifier:AffirmCellID];
    [self.view addSubview:self.tableView];

}

//创建底部视图
-(void)initWithBottomView{
    UIView *bottomView = [[UIView alloc] init];
    bottomView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:bottomView];
    float marge = 0;
    if (kStatusBarHeight > 20) {
        marge = 20;
    }
    bottomView.sd_layout
    .bottomSpaceToView(self.view, marge)
    .leftSpaceToView(self.view, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(49);
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [bottomView addSubview:line];
    
    UILabel *count = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:14 numberOfLines:1 text:@"合计:"];
    count.frame = CGRectMake(10, 14, 45, 20);
    [bottomView addSubview:count];
    
    UILabel *countPriceLabel = [Utils labelTextColor:[UIColor colorWithHex:0xf67100] fontSize:15 numberOfLines:1 text:@"¥ 0.00"];
    countPriceLabel.frame = CGRectMake(60, 12, 150, 25);
    [bottomView addSubview:countPriceLabel];
    self.countPriceLabel = countPriceLabel;
    
    UIButton *affirmBtn = [UIButton addBtnImage:@"" WithTarget:self action:@selector(affirmBtnClick)];
    [affirmBtn setTitle:@"立即下单" forState:0];
    affirmBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    affirmBtn.backgroundColor = [UIColor colorWithHex:0xf67200];
    affirmBtn.layer.cornerRadius = 2;
    affirmBtn.layer.masksToBounds = YES;
    affirmBtn.frame = CGRectMake(SCREEN_WIDTH-130, 7, 120, 35);
    [bottomView addSubview:affirmBtn];
    
}

-(void)affirmBtnClick{

 
    if ([self.addressID floatValue] >0) {
 
        if (self.type == CloseTypeTypeCartNone) {
            for (int i =0; i < self.categoryArr.count; i++) {
                DWYAffirmCartModel *model = self.categoryArr[i];
                if (model.freight_status == 1) {
                    if ([model.store_freight floatValue] <0.01) {
                        [MBManager showBriefAlert:@"请输入邮费"];
                        return;
                    }
                }
            }
             [self confirmPayType];
           
        }else{
            
            if (self.model.freight_status >= 1) {
                if ([self.model.freight floatValue] > 0) {
                    [self confirmPayType];
                }else{
                    [MBManager showBriefAlert:@"请输入邮费"];
                    return;
                }
            }else{
                [self confirmPayType];
            }
        }
  

    }else{
        [MBManager showError:@"请选择收货地址"];
        return;
    }
    


}

-(void)updateNumber:(NSInteger)number{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"number"] = @(number);
    params[@"g_id"] = @(self.pro_id);
    NSString *urlStr = [Utils getMemberServiceUri:@"updateNumber"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
           // id dataObject = [responseObject objectForKey:@"data"];
            // [self loadData];//请求数据
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}

#pragma mark - 商品结算---从商品页直接跳转，直接买单
-(void)putOrderWithGoods{

//    [MBManager showLoading];
    [MBManager showLoadingInView:self.view];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"goods"] = self.jsonStr;
    params[@"remark"] = self.model.words;

    params[@"address_id"] = self.addressID;
    params[@"o_freight"] = self.model.freight;
    
   // NSLog(@"%@",params);
    NSString *urlStr = [Utils V1GetMemberServiceUrl:@"putOrder"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSString *orderNum = [dataObject objectForKey:@"o_number"];
            
            self.tempOrderNumber = orderNum;
            if ([self.payStr isEqualToString:@"付甲一方"]||[self.payStr isEqualToString:@"钱包余额"]) {
                //余额，付甲一方
                 [self PayType:orderNum];
            }else if ([self.payStr isEqualToString:@"微信支付"]){
                //发起微信支付
                [WeChatManager sendWechatPay:self.totalPrice WithOrderNum:orderNum];
            }
   
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
       // NSLog(@"%@",error);
        [MBManager showError];
    }];
    
}

#pragma mark - 购物车结算---从购物车页直接跳转
-(void)putOrderWithCart{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    params[@"ids"] = self.goodIds;
    params[@"address_id"] = self.addressID;
//    params[@"remark"] = self.footView.messageText.text;
    params[@"store"] = [self transformData];  //转换为json字符串
    
    NSString *urlStr = [Utils V1GetMemberServiceUrl:@"cartOrder"];
    //NSLog(@"------%@",[Utils transformUnicode:params]);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSString *orderNum = [dataObject objectForKey:@"o_number"];
             self.tempOrderNumber = orderNum;
            //发送通知，更新购物车数据
            KPostNotification(@"createOrderNum", nil);
            
            if ([self.payStr isEqualToString:@"付甲一方"]||[self.payStr isEqualToString:@"钱包余额"]) {
                //余额，付甲一方
                 [self PayType:orderNum];

            }else if ([self.payStr isEqualToString:@"微信支付"]){
                //发起微信支付
                [WeChatManager sendWechatPay:self.totalPrice WithOrderNum:orderNum];
            }
        }else{
            [MBManager showError:hint];
        }
        
    } failure:^(NSError * _Nonnull error) {
        //NSLog(@"%@",error);
        [MBManager showError];
    }];
    
}


#pragma mark - 确认付款
-(void)confirmPayType{ //130 100
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:@"isOrder" forKey:@"pathwayType"];
    [ud synchronize];
    
    __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:self.view.bounds];
    //装载商品信息的视图
    int number = 0;
    id fjStatus = [appDelegate.appDefault objectForKey:@"fjyf_status"];
    if ([fjStatus intValue] == 1) {
        number = 3;
    }else{
        number = 2;
    }
    float height = number*(kHeight(50))+(kHeight(230));
    ConfirmPayView *whiteView = [[ConfirmPayView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height) WithStr:@"钱包余额" WithPrice:self.totalPrice];
    whiteView.closeView = ^{
        [coverV dismissContactView];
        
    };
    //支付
    whiteView.payBlock = ^(NSString *payType) {
        [coverV dismissContactView];
        weakSelf.payStr = payType;
        if (weakSelf.type == CloseTypeTypeGoodsNone) { //商品跳转
            [weakSelf putOrderWithGoods];
        }else if (weakSelf.type == CloseTypeTypeCartNone){ //购物车跳转
            [weakSelf putOrderWithCart];
        }

    };
    [coverV addSubview:whiteView];
    [coverV showView];
}

//钱包余额，
-(void)PayType:(NSString *)orderNum{
    
    __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:self.view.bounds];
    //装载商品信息的视图
    //NSString *payStr = @"付甲一方";
    float height = (kHeight(170))+216;
    PayTypeView *whiteView = [[PayTypeView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height)];
    whiteView.backgroundColor = [UIColor whiteColor];
    whiteView.closeBtnBlock = ^{
         [coverV dismissContactView];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            for (UIViewController *controller in weakSelf.navigationController.viewControllers) {
                if ([controller isKindOfClass:[MainTabBarController class]]) {
                    [weakSelf.navigationController popToViewController:controller animated:YES];
                }
            }
        });
    };
    //忘记密码
    whiteView.forgetBtnBlock = ^{
         [coverV dismissContactView];
//        addBoundViewCtl *vc = [[addBoundViewCtl alloc] init];
//        vc.isBound = YES;
//        vc.type = isPayPassword;
        PayPasswordViewCtl *vc = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
        
    };
    whiteView.inputView.inputFinish = ^(NSString *pwd) { //输入正确
        [coverV dismissContactView];
        //weakSelf.signStr = pwd;  // 保存支付签名
        
         //[OrderManager WalletAndFujiaPay:weakSelf.totalPrice WithSign:pwd WithOrderNum:orderNum WithPayType:weakSelf.payStr];
        [OrderManager WalletAndFujiaPay:weakSelf.totalPrice WithSign:pwd WithOrderNum:orderNum WithPayType:weakSelf.payStr WithController:weakSelf];
      
    };
    whiteView.inputView.forgetBtnBlock = ^{
         [coverV dismissContactView];
//        addBoundViewCtl *vc = [[addBoundViewCtl alloc] init];
//        vc.isBound = YES;
//        vc.type = isPayPassword;
        PayPasswordViewCtl *vc = [[PayPasswordViewCtl alloc] init];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.navigationController pushViewController:vc animated:YES];
        });
    };
    [coverV addSubview:whiteView];
    [coverV showView];

}



-(NSString *)transformData{
    NSMutableArray *putlistArr = [NSMutableArray array];
    for (int i =0; i < self.categoryArr.count; i++) {
        DWYAffirmCartModel *model = self.categoryArr[i];
        
        NSMutableDictionary *parems = [NSMutableDictionary dictionary];
        parems[@"s_id"] = @(model.s_id);
        parems[@"remark"] = model.words;
        parems[@"s_freight"] = model.store_freight;
        //parems[@"store_total"] = model.store_total;
       // parems[@"s_name"] = model.s_name;
       
        NSMutableArray *array = [NSMutableArray array];
        for (DWYAffirmGoodsModel *f_model in self.dataArray[i]) {
            NSMutableDictionary *parems = [NSMutableDictionary dictionary];
            parems[@"pro_id"] = f_model.pro_id;
            //parems[@"pro_price"] = f_model.price;
            parems[@"pro_attr"] = f_model.attribute;
            parems[@"pro_number"] = f_model.number;
            //parems[@"pro_name"] = f_model.pro_name;
            
            [array addObject:parems];
        }
        parems[@"goods"] = array; //[array mj_JSONString];
        [putlistArr addObject:parems];
    }
    
   // NSLog(@"%@",[Utils transformUnicode:putlistArr]);
//    NSLog(@"%@",[Utils transformUnicode:putlistArr]);
//    NSData * jsonData = [NSJSONSerialization dataWithJSONObject:putlistArr options:NSJSONWritingPrettyPrinted error:nil];
//    NSString * jsonStr = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString * jsonStr = [Utils jsonStrTransform:putlistArr];  //转json字符串
    
    return jsonStr;
}

//请求数据
-(void)loadData{
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSString *urlStr;
    if (self.type == CloseTypeTypeGoodsNone) {
        params[@"goods"] = self.jsonStr;
        params[@"pro_id"] = @(self.pro_id);
        urlStr = [Utils getMemberServiceUri:@"goodsClose"];
    }else if (self.type == CloseTypeTypeCartNone){
        params[@"g_ids"] = self.goodIds;
        urlStr = [Utils getMemberServiceUri:@"cartClose"];
    }

    //NSLog(@"%@",urlStr);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];

        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        NSLog(@"%@",[Utils transformUnicode:responseObject]);
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            if (self.type == CloseTypeTypeGoodsNone) {
                //数据源
                NSDictionary *commentDict = [dataObject objectForKey:@"goods"];
                self.model = [DWYAffirmModel objectWithDictionary:commentDict];
                
                self.countPriceLabel.text = [NSString stringWithFormat:@"¥ %.2f",[self.model.total_money floatValue]];
                self.totalPrice = self.model.total_money;
                NSArray *attribArr = commentDict[@"pro_attribute"];
                self.dataArray = [AttribAffirmModel mj_objectArrayWithKeyValuesArray:attribArr];
            
            }else if (self.type == CloseTypeTypeCartNone){
                id price = [dataObject objectForKey:@"total_money"];
                self.totalPrice = [NSString stringWithFormat:@"%.2f",[price floatValue]];
                self.countPriceLabel.text = [NSString stringWithFormat:@"¥ %.2f",[self.totalPrice floatValue]];

                //商品信息
                NSMutableArray *storesArr = [dataObject objectForKey:@"cart"];

                for (NSDictionary *dict in storesArr) {

                    id sendType = dict[@"freight_status"];
                    self.freightStatus += [sendType intValue];

                    if([[dict allKeys] containsObject:@"goods"]){



                        DWYAffirmCartModel *model = [DWYAffirmCartModel objectWithDictionary:dict];
                      

                            [self.categoryArr addObject:model];

                            NSMutableArray *datas = [NSMutableArray array];
                            for (NSDictionary *f_model in  model.goods) {

                                DWYAffirmGoodsModel *model = [DWYAffirmGoodsModel objectWithDictionary:f_model];
                                [datas addObject:model];

                            }
                            [self.dataArray addObject:datas];
                        }

                  }
               
            }
            
            [self.tableView reloadData];
        }else{
            [MBManager showError:hint];
        }
        
    } failure:^(NSError * _Nonnull error) {
        //NSLog(@"%@",error);
        [MBManager showError];
        
    }];

    
}


#pragma mark - UITableView 代理，数据源方法
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.type == CloseTypeTypeGoodsNone?1:self.categoryArr.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.type == CloseTypeTypeGoodsNone?self.dataArray.count:[self.dataArray[section] count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return kHeight(40);
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return kHeight(195);
}
//底部view
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{

    NSString *viewIdentfier = [NSString stringWithFormat:@"iOS%ld",section];
    DWYAffirmFootView *sectionFootView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:viewIdentfier];
    
    if(!sectionFootView){
        
        sectionFootView = [[DWYAffirmFootView alloc] initWithReuseIdentifier:viewIdentfier];
    }
    
    if (self.type == CloseTypeTypeCartNone) {
        DWYAffirmCartModel *model = self.categoryArr[section];
        sectionFootView.jumpType = 1;
        sectionFootView.model = model;
        //更新总价
        __weak typeof (self)weakSelf = self;
        sectionFootView.countTotalPriceBlock = ^(float price) {
            float oldePrice = [weakSelf.totalPrice floatValue];
            float newPrice = oldePrice + price - [model.store_freight floatValue];
            weakSelf.totalPrice = [NSString stringWithFormat:@"%.2f",newPrice];
            weakSelf.countPriceLabel.text = [NSString stringWithFormat:@"¥ %.2f",newPrice];
            model.store_freight = [NSString stringWithFormat:@"%.2f",price];
            model.store_total = [NSString stringWithFormat:@"%.2f",newPrice];
            [weakSelf.tableView reloadData];
            
        };
    }else{
        sectionFootView.jumpType = 2;
        sectionFootView.goodsModel = self.model;
        //更新总价
        __weak typeof (self)weakSelf = self;
        sectionFootView.countTotalPriceBlock = ^(float price) {
            float oldePrice = [weakSelf.totalPrice floatValue];
            float newPrice = oldePrice + price - [weakSelf.model.freight floatValue];
            weakSelf.totalPrice = [NSString stringWithFormat:@"%.2f",newPrice];
            weakSelf.countPriceLabel.text = [NSString stringWithFormat:@"¥ %.2f",newPrice];
            self.model.freight = [NSString stringWithFormat:@"%.2f",price];
            [weakSelf.tableView reloadData];
            
        };
    }

    
    return sectionFootView;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *head = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(40))];
   // headV.backgroundColor = [UIColor whiteColor];
    
    UIView *headV = [[UIView alloc] initWithFrame:CGRectMake(0, kHeight(5), SCREEN_WIDTH, kHeight(35))];
    headV.backgroundColor = [UIColor whiteColor];
    [head addSubview:headV];
    
    NSString *storeName;
    NSString *logoUrl;
    if (self.type == CloseTypeTypeGoodsNone) {
        storeName = self.model.s_name;
        logoUrl = self.model.logo_url;
    }else{
        DWYAffirmCartModel *model = self.categoryArr[section];
        storeName = model.s_name;
        //logoUrl = model.logo_url;
    }
    
    UIImageView *storeLogoV = [[UIImageView alloc] initWithFrame:CGRectMake(10, (headV.height-25)/2, 25, 25)];
    [storeLogoV sd_setImageWithURL:[NSURL URLWithString:logoUrl] placeholderImage:[UIImage imageNamed:@"shoplist_icon_store_22_22"]];
    [headV addSubview:storeLogoV];
 
    
    UILabel *storeNameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:storeName];
    storeNameLabel.frame = CGRectMake(45, 0, 150, kHeight(34));
    [headV addSubview:storeNameLabel];
 
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, kHeight(34), SCREEN_WIDTH, 1)];
    [headV addSubview:line];
    
    return head;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DWYAffirmCell *cell = [tableView dequeueReusableCellWithIdentifier:AffirmCellID];
    if (!cell) {
        cell = [[DWYAffirmCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:AffirmCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    if (self.type == CloseTypeTypeGoodsNone) {
        [cell.imageV sd_setImageWithURL:[NSURL URLWithString:self.model.logo_url] placeholderImage:[UIImage imageNamed:@"placeholder"]];
        cell.nameLabel.text = self.model.pro_name;
        cell.pkgV.hidden = NO;
        cell.model = self.dataArray[indexPath.row];
        __weak typeof (self)weakSelf = self;
        cell.editNumberBlock = ^{
            [weakSelf editNumberData];
        };
    }else if (self.type == CloseTypeTypeCartNone){
        cell.goodsModel = self.dataArray[indexPath.section][indexPath.row];
        cell.pkgV.hidden = YES;
    }
    
    
    return cell;
}

//重新请求
-(void)editNumberData{
    
    NSMutableArray *attribArr = [NSMutableArray array];
    for (AttribAffirmModel *model in self.dataArray) {
       
            NSMutableDictionary *dict = [NSMutableDictionary dictionary];
//            dict[@"pro_id"] = @(self.pro_id);
            dict[@"attribute"] = model.attribute;
            dict[@"number"] = model.pro_number;
            [attribArr addObject:dict];
    }
    
    NSString *jsonStr = [Utils jsonStrTransform:attribArr];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"goods"] = jsonStr;
    params[@"pro_id"] = @(self.pro_id);
    NSString *urlStr = [Utils getMemberServiceUri:@"goodsClose"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        NSLog(@"%@",[Utils transformUnicode:responseObject]);
        if ([status isEqualToString:@"200"]) {

            id dataObject = [responseObject objectForKey:@"data"];
            
            //数据源
            NSDictionary *commentDict = [dataObject objectForKey:@"goods"];
            //self.dataArray = [DWYAffirmModel mj_objectArrayWithKeyValuesArray:commentDict];
            DWYAffirmModel *model = [DWYAffirmModel objectWithDictionary:commentDict];
            self.countPriceLabel.text = [NSString stringWithFormat:@"¥ %.2f",[model.total_money floatValue]];
            self.totalPrice = model.total_money;

            self.model = model;
            NSArray *attribArr = commentDict[@"pro_attribute"];
            self.dataArray = [AttribAffirmModel mj_objectArrayWithKeyValuesArray:attribArr];
            
            [self.tableView reloadData];
        }else{
            [MBManager showError:hint];
        }
     
    } failure:^(NSError * _Nonnull error) {
       
        [MBManager showError];
        
    }];

  
}

#pragma mark -- 地址回调代理方法
-(void)sendMessage:(NSString *)Name withTel:(NSString *)tel WithAddress:(NSString *)adddress WithID:(int)addressID{
    self.headView.placeLabel.hidden = YES;
    self.headView.nameLabel.text = Name;
    self.headView.telLabel.text = tel;
    self.headView.addressLabel.text = adddress;
    self.addressID = NSStringFormat(@"%d",addressID);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
