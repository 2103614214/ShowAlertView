//
//  UIView+WLExtension.h
//  WLSelectAttributes
//
//  Created by 汪亮 on 2017/11/16.
//  Copyright © 2017年 汪亮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (WLExtension)
@property(nonatomic,assign)CGFloat WL_x;
@property(nonatomic,assign)CGFloat WL_y;
@property(nonatomic,assign)CGFloat WL_width;
@property(nonatomic,assign)CGFloat WL_height;
@property(nonatomic,assign)CGSize WL_size;
@property(nonatomic,assign)CGPoint WL_origin;

@property(nonatomic,assign)CGFloat WL_centerX;
@property(nonatomic,assign)CGFloat WL_centerY;
@end
