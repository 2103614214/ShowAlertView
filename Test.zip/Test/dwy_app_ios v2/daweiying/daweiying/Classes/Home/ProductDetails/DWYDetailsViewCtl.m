//
//  DWYDetailsViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/22.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYDetailsViewCtl.h"
#import "DWYDetailsView.h"
#import "DWYFootView.h"

#import "DWYCommentCtl.h"
#import "DWYAffirmViewCtl.h"
#import "DWYManageAddressCtl.h"
#import "CollectTools.h"
#import "ChatViewController.h"
#import "DWYFoodsStoreCtl.h"
#import "ProductAttrModel.h"
#import "UIView+Extension.h"
#import "StoreViewCtl.h"

#import "ShowAnimationView.h"
#import "AttributeViewSelected.h"
#import "ProDetailsCell.h"
#import "LoginViewController.h"
#import "LoginUtils.h"
#import "EditProductViewCtl.h"
#import "EditProductModel.h"

#import "XLPhotoBrowser.h"
@interface DWYDetailsViewCtl () <UITableViewDelegate,UITableViewDataSource,viewClickDelegate>

/** tableview头部视图 */
@property(nonatomic,strong)DWYDetailsView *detailsView;
/** 底部工具栏 */
@property(nonatomic,strong)DWYFootView *footView;
/** 列表 */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;
/** 头部数据源 */
@property(nonatomic,strong)NSDictionary *headDict;
/** 商户id 聊天用 */
@property(nonatomic,copy)NSString *c_id;
/** 是否收藏 */
@property(nonatomic,assign)BOOL is_collect;


/** 返回 */
@property(nonatomic,strong)UIButton *backBtn;
/** 属性数组 */
@property(nonatomic,strong)NSArray *dataArr;

@property(nonatomic,strong)ShowAnimationView *coverV;

@property(nonatomic,strong)AttributeViewSelected *whiteView;


@end

static NSString * const DetailsCellID = @"DetailsCellID";
@implementation DWYDetailsViewCtl

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-50) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = SCREEN_WIDTH+(kHeight(15));
        _tableView.tableHeaderView = self.detailsView;
        _tableView.tableFooterView = [UIView new];
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone; //去除所有分割线
        _tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        [_tableView registerClass:[ProDetailsCell class] forCellReuseIdentifier:DetailsCellID];
    }
    return _tableView;
}
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self viewDidLoad:YES];
    
    [self setStatusBarBackgroundColor:[UIColor clearColor]];
    
  //  [self initWithTableView:2];
    
    //请求数据
    [self loadData];
    
    //左侧返回
    UIButton *backBtn = [UIButton addBtnImage:@"shopdt_btn_back_30_30" WithTarget:self action:@selector(back)];
    backBtn.frame = CGRectMake(10, kStatusBarHeight, 30, 30);
    backBtn.alpha = 0.5;
    //获取当前UIWindow 并添加一个视图
    UIApplication *ap = [UIApplication sharedApplication];
    [ap.keyWindow addSubview:backBtn];
    self.backBtn = backBtn;
    

    //通知
    __weak typeof (self)weakSelf = self;
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"editProductCount" object:nil] subscribeNext:^(NSNotification *notification) {
        
        [weakSelf loadData];
    }];
    
}

-(void)initWithTableView:(int)viewType WithData:(id)data WithCommentType:(int)type{
    
    __weak typeof (self)weakSelf = self;
    float headVH = 0;
    if (viewType == 1) { //日常零售
        if (type > 0) {
            headVH = kHeight(740);
        }else{
            headVH = kHeight(655);
        }
        
    }else if (viewType == 2){ //企业制造
        if (type > 0) {
             headVH = kHeight(760);
        }else{
             headVH = kHeight(675);
        }
       
    }
    self.detailsView = [[DWYDetailsView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, headVH) WithViewType:viewType WithData:data];
    self.detailsView.delegate = self;
    
    [self.view addSubview:self.tableView];
    

    id storeId = [[data objectForKey:@"product"] objectForKey:@"store_id"];
    id isMeStoreId = [appDelegate.appDefault objectForKey:@"store_id"];
    
    if ([storeId intValue] == [isMeStoreId intValue]) { //自己店铺
        id is_business = [[data objectForKey:@"product"] objectForKey:@"is_business"];
        DWYIsMeFootView *footView = [[DWYIsMeFootView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-kTabBarHeight, SCREEN_WIDTH, 49) Withtype:[is_business intValue]];
        [self.view addSubview:footView];
        
         id pro_id = [[data objectForKey:@"product"] objectForKey:@"pro_id"];
        int proId = [pro_id intValue];
        //删除
        [[footView.delBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
     
            [weakSelf changeProductStatus:2 proId:proId];
           
        }];
        //上/下架
        [[footView.putawayBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
            
            int status = 0;
            if ([is_business intValue] == 0) { //已上架
                status = 1;
            }else if ([is_business intValue]== 1){ //未上架
                status = 0;
            }
            [weakSelf changeProductStatus:status proId:proId];
        }];
       
        //库存
        [[footView.countBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
            
            NSMutableArray *dataArray = [NSMutableArray array];
            NSArray *arr = [data objectForKey:@"attribute"];

            dataArray = [EditProductModel mj_objectArrayWithKeyValuesArray:arr];
            
            EditProductViewCtl *vc = [[EditProductViewCtl alloc] init];
            vc.dataArray = dataArray;
            vc.pro_id = [pro_id intValue];
            if (viewType == 1) {
                vc.type = isRetailPro;
            }else if (viewType == 2){
                vc.type = isCompanyPro;
            }
            [weakSelf.navigationController pushViewController:vc animated:YES];
            
        }];
        
//        self.footView.IMView.userInteractionEnabled = NO;
//        self.footView.addShoppingCarButton.userInteractionEnabled = NO;
//        self.footView.buyButton.userInteractionEnabled = NO;
//        self.footView.buyButton.backgroundColor = [UIColor lightGrayColor];
//         self.footView.addShoppingCarButton.backgroundColor = [UIColor lightGrayColor];
    }else{  //不是自己店铺
        self.footView = [[DWYFootView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-kTabBarHeight, SCREEN_WIDTH, 49)];
        [self.view addSubview:self.footView];
        [self.footView.buyButton addTarget:self action:@selector(buyBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
        [self.footView.addShoppingCarButton addTarget:self action:@selector(addShoppingBtnClick:) forControlEvents:(UIControlEventTouchUpInside)];
        
        UITapGestureRecognizer *collectTap = [[UITapGestureRecognizer alloc] init];
        [[collectTap rac_gestureSignal] subscribeNext:^(id x) {
            if (weakSelf.is_collect) { //取消收藏
                [CollectTools delCollectStore:weakSelf.productID WithType:1]; //取消收藏商品
                [weakSelf.footView.collectImageV setImage:[UIImage imageNamed:@"shopdt_btn_uncollection_26_26"]];
                weakSelf.is_collect = NO;
                weakSelf.footView.collectLabel.text = @"收藏";
            }else{ //收藏
                [CollectTools collectProduct:weakSelf.productID]; //收藏商品
                [weakSelf.footView.collectImageV setImage:[UIImage imageNamed:@"shopdt_btn_collection_26_26"]];
                weakSelf.is_collect = YES;
                weakSelf.footView.collectLabel.text = @"已收藏";
            }
            
        }];
        [self.footView.collectView addGestureRecognizer:collectTap];
        
        UITapGestureRecognizer *ImTap = [[UITapGestureRecognizer alloc] init];
        [[ImTap rac_gestureSignal] subscribeNext:^(id x) {
            //开启会话
            ChatViewController *chatController = [[ChatViewController alloc] initWithConversationChatter:weakSelf.c_id conversationType:EMConversationTypeChat];
            //chatController.titleStr = model.s_name;
            [weakSelf.navigationController pushViewController:chatController animated:YES];
        }];
        [self.footView.IMView addGestureRecognizer:ImTap];
        
        //进店
        UITapGestureRecognizer *storeTap = [[UITapGestureRecognizer alloc] init];
        [[storeTap rac_gestureSignal] subscribeNext:^(id x) {
            
            if (weakSelf.type == isStore) {
                [weakSelf.navigationController popViewControllerAnimated:YES];
                
            }else{
                id storeId = [[data objectForKey:@"product"] objectForKey:@"store_id"];
                StoreViewCtl *vc = [[StoreViewCtl alloc] init];
                vc.store_id = [storeId intValue];
                [weakSelf.navigationController pushViewController:vc animated:YES];
            }
            
            
        }];
        [self.footView.storeView addGestureRecognizer:storeTap];
        
    }
    
    
}

#pragma mark -- 删除/上架/下架
-(void)changeProductStatus:(int)type proId:(int)proID{
  
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"pro_id"] = @(proID);
     params[@"status"] = @(type);
    NSString *urlStr = [Utils getMemberServiceUri:@"disposeGoods"];
    //NSLog(@"%@",params);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        NSString *hint = [responseObject objectForKey:@"hint"];
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"操作成功"];
            if (type == 2) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    KPostNotification(@"delProduct", nil);
                    [self.navigationController popViewControllerAnimated:YES];
                });
            }else{
                [self loadData]; //重新请求一下数据
            }
            
        }else{
            [MBManager showError:hint];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}

#pragma mark -- 点击立即购买
-(void)buyBtnClick{
    
    if (![LoginUtils isLogin]) { //未登录
        [MBManager showBriefAlert:@"您还未登录,请先登录!"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [Utils loginController:self];
        });
    }else{
        [self popAttribsView:NO];
    }
    

}

#pragma mark -- 点击加入购物车
-(void)addShoppingBtnClick:(UIButton *)sender{
    
    if (![LoginUtils isLogin]) { //未登录
        [MBManager showBriefAlert:@"您还未登录,请先登录!"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [Utils loginController:self];
        });
    }else{
         [self popAttribsView:YES];
    }
   

}


-(void)popAttribsView:(BOOL)isAddShoppingCar{
    
    int type = 0;
    if (isAddShoppingCar) {
        type = 1;
    }else{
        type = 2;
    }

    __weak typeof (self)weakSelf = self;
    ShowAnimationView *coverV = [[ShowAnimationView alloc] initWithFrame:weakSelf.view.bounds];
    float height = SCREEN_HEIGHT*0.6+(kHeight(30));
    AttributeViewSelected *whiteView = [[AttributeViewSelected alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-height, SCREEN_WIDTH, height) withObjects:self.dataArr isPayType:type WithDict:self.headDict];
    whiteView.closeView = ^{
        [coverV dismissContactView];
    };
    self.coverV = coverV;
    self.whiteView = whiteView;
    //立即购买
    [whiteView.buyBtn addTarget:self action:@selector(buyButtonClick) forControlEvents:UIControlEventTouchUpInside];
    //加入购物车按钮
    [whiteView.addBtn addTarget:self action:@selector(addGoodsCartBtnClick) forControlEvents:UIControlEventTouchUpInside];
    //加入购物车按钮
    [whiteView.stockBtn addTarget:self action:@selector(addGoodsCartBtnClick) forControlEvents:UIControlEventTouchUpInside];

    [coverV addSubview:whiteView];
    [coverV showView];

}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = YES;
    self.backBtn.hidden = NO;
}
-(void)viewWillDisappear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = NO;
    self.backBtn.hidden = YES;
}

-(void)dealloc{
    
    [self.backBtn removeFromSuperview];
}
-(void)back{
    
   // [self.navigationController popViewControllerAnimated:YES];
    
    for (UIViewController *controller in self.navigationController.viewControllers) {
        if ([controller isKindOfClass:[MainTabBarController class]]) {
            [self.navigationController popToViewController:controller animated:YES];
        }
    }
}


-(void)loadData{
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"pro_id"] = @(self.productID); //self.productID
   
    NSString *urlStr = [Utils getMemberServiceUri:@"details"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
      // NSLog(@"%@",[Utils transformUnicode:responseObject]);
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            self.headDict = [dataObject objectForKey:@"product"];
       
            id commentId = [[dataObject objectForKey:@"comment"] objectForKey:@"total"];
            //确定view类型 ， 企业制造还是日常零售
            id type = self.headDict[@"type"];
            int viewType = [type intValue];
            
            [self initWithTableView:viewType WithData:dataObject WithCommentType:[commentId intValue]];
 
            id cid = [self.headDict objectForKey:@"c_id"];
            self.c_id = [NSString stringWithFormat:@"%@",cid];
            id isCollect = [self.headDict objectForKey:@"is_collect"];
            self.is_collect = [isCollect boolValue];
            if (self.is_collect) {
                [self.footView.collectImageV setImage:[UIImage imageNamed:@"shopdt_btn_collection_26_26"]];
                self.footView.collectLabel.text = @"已收藏";
            }else{
                [self.footView.collectImageV setImage:[UIImage imageNamed:@"shopdt_btn_uncollection_26_26"]];
                self.footView.collectLabel.text = @"收藏";
            }
            //属性
            NSArray *productDict = [dataObject objectForKey:@"attribute"];
//            NSArray *productDict = @[@{@"attribute":@"红色",@"repertory":@(300)},
//                                     @{@"attribute":@"黑色",@"repertory":@(300)},
//                                     @{@"attribute":@"绿色",@"repertory":@(300)}];
            self.dataArr = [ProductAttrModel mj_objectArrayWithKeyValuesArray:productDict];
            self.dataArray = [self.headDict objectForKey:@"detail_img"];
            
            [self.tableView reloadData];
        }else{
            [MBManager showError:@"获取数据失败"];
        }

    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.tableView.mj_header endRefreshing];
       
    }];

    
}



//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}

#pragma mark - UITableView 代理，数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//
//    return ((kHeight(25))+(SCREEN_WIDTH-(kWidth(60))));
//}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    float h = [self upLabelHeight];
    float headH = h + 30;
    return kHeight(headH);
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    ProDetailsCell *cell = [tableView dequeueReusableCellWithIdentifier:DetailsCellID];
    if (!cell) {
        cell = [[ProDetailsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:DetailsCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    cell.imageUrl = self.dataArray[indexPath.row];
 
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *bgV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(50))];
    bgV.backgroundColor = [UIColor whiteColor];
    float textH = [self upLabelHeight];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, 15, SCREEN_WIDTH-20, textH)];
    label.text = self.headDict[@"pro_introduce"];
    label.textColor = [UIColor blackColor];
    label.numberOfLines = 0;
    label.font = [UIFont systemFontOfSize:14];
    [bgV addSubview:label];
    
    return bgV;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
   // NSLog(@"%ld",indexPath.row);
}

-(CGFloat)upLabelHeight{
    
    // 文字的最大尺寸
    CGSize maxSize = CGSizeMake([UIScreen mainScreen].bounds.size.width - 4 * 10, MAXFLOAT);
    // 计算文字的高度
    NSString *text = self.headDict[@"pro_introduce"];
    CGFloat textH = [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} context:nil].size.height;
   
    return textH;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 立即购买,跳转下一页面
-(void)buyButtonClick{
    
    if (self.whiteView.totalNumber < 1) {
        [MBManager showBriefAlert:@"未选择商品"];
        return;
    }
    if (self.whiteView.totalNumber < self.detailsView.minNumber) {
        [MBManager showBriefAlert:@"不能小于最小起批数"];
        return;
    }
    
    [self.coverV dismissContactView];
    
    NSMutableArray *attribArr = [NSMutableArray array];
    for (ProductAttrModel *model in self.dataArr) {
        if (model.buyNumber > 0) {
            
            NSMutableDictionary *dict = [NSMutableDictionary dictionary];
            dict[@"pro_id"] = @(self.productID);
            dict[@"attribute"] = model.attribute;
            dict[@"number"] = @(model.buyNumber);
            [attribArr addObject:dict];
        }
    }
    
    NSString *jsonStr = [Utils jsonStrTransform:attribArr];
    
    DWYAffirmViewCtl *vc = [[DWYAffirmViewCtl alloc] init];
    vc.pro_id = self.productID;
    vc.jsonStr = jsonStr;
    vc.totalMoney = self.whiteView.totalPrice;
    vc.type = CloseTypeTypeGoodsNone;
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - 加入购物车请求数据
-(void)addGoodsCartBtnClick{
    
    if (self.whiteView.totalNumber < 1) {
        [MBManager showBriefAlert:@"未选择商品"];
        return;
    }
    
    if (self.whiteView.totalNumber < self.detailsView.minNumber) {
        [MBManager showBriefAlert:@"不能小于最小起批数"];
        return;
    }
    
    [MBManager showLoading];
    NSMutableArray *attribArr = [NSMutableArray array];
    for (ProductAttrModel *model in self.dataArr) {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        if (model.buyNumber > 0) {
            dict[@"pro_id"] = @(self.productID);
            dict[@"attribute"] = model.attribute;
            dict[@"number"] = @(model.buyNumber);
            [attribArr addObject:dict];
        }
 
    }
    
    NSString *jsonStr = [Utils jsonStrTransform:attribArr];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"s_id"] = [self.headDict objectForKey:@"store_id"];
    params[@"goods"] = jsonStr;

    NSString *urlStr = [Utils getMemberServiceUri:@"addCart"];

    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
       // DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *hint = [responseObject objectForKey:@"hint"];
        NSString *status = [ret objectForKey:@"status"];

        if ([status isEqualToString:@"200"]) {

         
            [MBManager showSuccess:@"添加成功"];
            [self.coverV dismissContactView];
            //发送通知，刷新购物车
            [[NSNotificationCenter defaultCenter] postNotificationName:@"AddShoppingCarData" object:nil];
        }else{
            [MBManager showError:hint];
        }

    } failure:^(NSError * _Nonnull error) {
        //NSLog(@"%@",error);
        [MBManager showError];
    }];
    
    
}

#pragma mark -- tableview头部点击方法代理
-(void)headViewTapClick:(NSInteger)tag{
 
    if (tag == 100) { //点击属性选择
        //NSLog(@"点击了属性选择");
         [self popAttribsView:NO];
    }else if (tag == 101){ //点击评论
        DWYCommentCtl *comment = [DWYCommentCtl new];
        comment.pro_id = self.productID;
        [self.navigationController pushViewController:comment animated:YES];
    }else if (tag == 102){ //点击进店
        //NSLog(@"跳转商户");
        if (self.type == isStore) {
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            StoreViewCtl *vc = [[StoreViewCtl alloc] init];
            vc.store_id = [[self.headDict objectForKey:@"store_id"] intValue];
            [self.navigationController pushViewController:vc animated:YES];
            
        }

    }
}
//轮播图
-(void)cycleScrollViewClick:(NSInteger)tag{
    
    //[[self.data objectForKey:@"product"] objectForKey:@"img_url"];
    NSArray *arr = [self.headDict objectForKey:@"img_url"];
    if (arr.count > 0) {
        XLPhotoBrowser *browser = [XLPhotoBrowser showPhotoBrowserWithImages:arr currentImageIndex:tag];
        // 自定义pageControl的一些属性
        browser.pageDotColor = [UIColor grayColor];
        browser.currentPageDotColor = [UIColor redColor];
        browser.pageControlStyle = XLPhotoBrowserPageControlStyleClassic;
    }
 
}

@end
