//
//  DWYAffirmCartModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/11/23.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface DWYAffirmCartModel : BaseModel

/** id */
@property(nonatomic,assign)int s_id;
/** 店名 */
@property (nonatomic,copy) NSString *s_name;
/** 快递费 */
@property (nonatomic,copy) NSString *store_freight;
/** 总价 */
@property (nonatomic,copy) NSString *store_total;
/** 邮费状态 */
@property(nonatomic,assign)int freight_status;
/** 商品数组 */
@property(nonatomic,strong)NSArray *goods;

/** 买家留言 */
@property(nonatomic,copy)NSString *words;

@end


@interface DWYAffirmGoodsModel : BaseModel
/** 商品id */
@property (nonatomic,copy) NSString *pro_id;
/** 商品名 */
@property (nonatomic,copy) NSString *pro_name;
/** 价格 */
@property(nonatomic,copy)NSString *price;
/** 属性 */
@property(nonatomic,copy)NSString *pro_title;
/** 选中属性 */
@property(nonatomic,copy)NSString *attribute;
/** 数量 */
@property(nonatomic,copy)NSString *number;
/** logo url */
@property(nonatomic,copy)NSString *logo_url;
/** 快递 */
@property(nonatomic,copy)NSString *freight;

/** s_name  */
@property(nonatomic,copy)NSString *s_name;

/** 留言  */
@property(nonatomic,copy)NSString *words;

@end

