//
//  ProDetailsCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/22.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "ProDetailsCell.h"

@implementation ProDetailsCell
{
    UIImageView *_bgV;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //初始化cell
        UIImageView *bgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, kHeight(15), SCREEN_WIDTH, SCREEN_WIDTH)];
        [self.contentView addSubview:bgV];
        _bgV = bgV;
    }
    return self;
}

-(void)setImageUrl:(NSString *)imageUrl{
    _imageUrl = imageUrl;
    [_bgV sd_setImageWithURL:[NSURL URLWithString:imageUrl]];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
