//
//  AttributeViewSelected.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/19.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "AttributeViewSelected.h"
#import "AttribSelectedCell.h"
#import "ProductAttrModel.h"

static NSString * const AttributeViewSelectedId = @"AttributeViewSelected";
@implementation AttributeViewSelected
{
    UILabel *_priceLabel;
}

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSArray *)objects isPayType:(int)isPayType WithDict:(NSDictionary *)dict{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        self.objects = objects;
        self.dict = dict;
        self.isShoppingCar = isPayType;  //1为加入购物车 2直接购买
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{

    //self.backgroundColor = [UIColor whiteColor];
    self.backgroundColor = [UIColor clearColor];
    
    UIView *headV = [[UIView alloc] initWithFrame:CGRectMake(0, kHeight(30), SCREEN_WIDTH, kHeight(60))];
    headV.backgroundColor = [UIColor whiteColor];
    [self addSubview:headV];
    
    UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(kWidth(15), -(kHeight(30)), kWidth(90), kHeight(80))];
    //[imgV setImage:[UIImage imageNamed:placeImageName]];
    [imgV sd_setImageWithURL:[NSURL URLWithString:self.dict[@"logo_url"]] placeholderImage:[UIImage imageNamed:placeImageName]];
    [headV addSubview:imgV];
    
    //商品名
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:self.dict[@"pro_name"]];
    nameLabel.frame = CGRectMake(kWidth(125), 0, kWidth(200), kHeight(30));
    [headV addSubview:nameLabel];
    
    //价格
    UILabel *priceLabel1 = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:14 numberOfLines:1 text:@""];
    priceLabel1.frame = CGRectMake(kWidth(125), kHeight(25), kWidth(200), kHeight(30));
    [headV addSubview:priceLabel1];
    
 
    id type = self.dict[@"type"];
    if ([type intValue] == 1) { //日常零售
        NSString *str = [NSString stringWithFormat:@"¥ %@",self.dict[@"price"]];
        priceLabel1.text = str;
    }else if ([type intValue] == 2){ // 企务制造
        NSArray *array = self.dict[@"prices"];
        NSMutableArray *priceArr = [NSMutableArray array];
        for (int i = 0; i < array.count; i++) {
            NSDictionary *dic = array[i];
            CGFloat num = [dic[@"price"] floatValue];
            [priceArr addObject:[NSNumber numberWithFloat:num]];
        }
        CGFloat maxValue = [[priceArr valueForKeyPath:@"@max.floatValue"] floatValue];
        CGFloat minValue = [[priceArr valueForKeyPath:@"@min.floatValue"] floatValue];
        
        NSString *str = [NSString stringWithFormat:@"¥%.2f - %.2f",minValue,maxValue];
        priceLabel1.text = str;
      
    }
   
    UILabel *line2 = [Utils lineWithFrame:CGRectMake(0, kHeight(89), SCREEN_WIDTH, 1)];
    [self addSubview:line2];

    UIButton *closeBtn = [UIButton addBtnImage:@"shopspec_btn_close_30_30" WithTarget:self action:@selector(dismissContactView)];
    closeBtn.frame = CGRectMake(SCREEN_WIDTH-(kWidth(45)), (kHeight(15)), kWidth(30), kHeight(30));
    [self addSubview:closeBtn];
    
    
    //底部  80
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, self.height-(kHeight(80)), SCREEN_WIDTH, 1)];
    [self addSubview:line];
    
    UILabel *priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"  已选 0个  共计 0.00"];
    priceLabel.backgroundColor = [UIColor whiteColor];
    [self addSubview:priceLabel];
    priceLabel.sd_layout
    .topSpaceToView(line, 0)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(35));
    _priceLabel = priceLabel;
    
    //加入购物车按钮
    UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    float btnH = kHeight(45);
    if (kTabBarHeight > 49) {
        btnH = kHeight(65);
    }
//    addBtn.frame = CGRectMake(0, self.height-btnH, SCREEN_WIDTH/2, kHeight(45));
//    [addBtn setBackgroundColor:[UIColor colorWithHex:0xff9701]];
//    [addBtn setTitleColor:[UIColor whiteColor] forState:0];
//    addBtn.titleLabel.font = [UIFont systemFontOfSize:15];
//    [addBtn setTitle:@"加入购物车" forState:0];
//    [self addSubview:addBtn];
//    self.addBtn = addBtn;
    
    //立即购买按钮
    UIButton *buyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    buyBtn.frame = CGRectMake(0, self.height-btnH, SCREEN_WIDTH, kHeight(45));
    [buyBtn setBackgroundColor:[UIColor colorWithHex:0xf67200]];
    [buyBtn setTitleColor:[UIColor whiteColor] forState:0];
    buyBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [buyBtn setTitle:@"确定" forState:0];
    [self addSubview:buyBtn];
    self.buyBtn = buyBtn;
    
    //确定
    UIButton *stockBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    stockBtn.frame = CGRectMake(0, self.height-btnH, SCREEN_WIDTH, kHeight(45));
    [stockBtn setBackgroundColor:[UIColor colorWithHex:0xff9701]];
    [stockBtn setTitleColor:[UIColor whiteColor] forState:0];
    stockBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [stockBtn setTitle:@"确定" forState:0];
    [self addSubview:stockBtn];
    self.stockBtn = stockBtn;
    
    if (self.isShoppingCar == 1) {
        addBtn.hidden = YES;
        buyBtn.hidden = YES;
    }else if (self.isShoppingCar == 2){
        stockBtn.hidden = YES;
   
    }
    
    [self count]; //求和
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeight(90), SCREEN_WIDTH, self.height-(kHeight(170)))];
    self.tableView.bounces = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[AttribSelectedCell class] forCellReuseIdentifier:AttributeViewSelectedId];
    
}


#pragma mark - TableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.objects count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return kHeight(60);
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    AttribSelectedCell *cell = [tableView dequeueReusableCellWithIdentifier:AttributeViewSelectedId forIndexPath:indexPath];
    if (!cell) {
        cell = [[AttribSelectedCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:AttributeViewSelectedId];
    }
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    cell.selectionStyle = UITableViewCellSelectionStyleNone; //取消点中效果
    cell.model = self.objects[indexPath.row];
    __weak typeof (self)weakSelf = self;
    cell.numberClickBlock = ^{
        [weakSelf count];
    };
    
    return cell;
    
}

-(void)dealloc{
    NSLog(@"dealloc");
}
//求和
-(void)count{
   
    NSInteger number = 0;   //点击总数量
    for (ProductAttrModel *model in self.objects) {
        
        number +=model.buyNumber;
    }
    
    id type = self.dict[@"type"];

    float price = 0;
  
    if ([type intValue] == 1) { //日常零售
        price = [self.dict[@"price"] floatValue];
    }else if ([type intValue] == 2){
        
        NSArray *array = self.dict[@"prices"];
        
        if (array.count == 1) {
            NSDictionary *dic = array[0];
            price = [dic[@"price"] floatValue];
        }else{
            
            //得出最大价格
            NSMutableArray *priceArray = [NSMutableArray array];
            for (int j = 0; j < array.count; j++) {
                NSDictionary *dict = array[j];
                [priceArray addObject:dict[@"s_number"]];
            }
            NSInteger maxValue = [[priceArray valueForKeyPath:@"@max.integerValue"] integerValue];
            
            for (int i = 0; i <array.count ; i++) {
                NSDictionary *dic = array[i];
                //价格区间数量
                NSInteger num = [dic[@"s_number"] integerValue];
                if (i == 0) {
                    if (number >= num) {
                        price = [dic[@"price"] floatValue];
                        //tempNum = num;
                    }
                }else if (i == 1){
                    if (array.count > 2) {
                        if (number>=num && number < maxValue) {
                            price = [dic[@"price"] floatValue];
                            
                        }
                    }else{
                        if (number>=num) {
                            price = [dic[@"price"] floatValue];
                            
                        }
                    }
                 
                }else if (i == 2){
                    if ( number >= num) {
                        price = [dic[@"price"] floatValue];
                    }
                }
            }
        }


    }
    NSLog(@"%.3f",price);
    float totalPrice = number * price;
    self.totalPrice = totalPrice;
    self.totalNumber = number;
    _priceLabel.text = [NSString stringWithFormat:@"  已选 %ld个  共计 ¥%.2f",number,totalPrice];
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

}

-(void)dismissContactView{
    self.closeView();
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end

