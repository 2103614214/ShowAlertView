//
//  DWYAffirmModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DWYAffirmModel : NSObject
/** 商品id */
@property (nonatomic,copy) NSString *pro_id;
/** 商品名 */
@property (nonatomic,copy) NSString *pro_name;
/** 价格 */
@property(nonatomic,copy)NSString *price;
/** 属性 */
@property(nonatomic,copy)NSString *pro_attr;
/** 数量 */
@property(nonatomic,copy)NSString *sell_number;
/** 总价 */
@property(nonatomic,copy)NSString *total_money;
/** logo url */
@property(nonatomic,copy)NSString *logo_url;
/** 快递费 */
@property(nonatomic,copy)NSString *freight;
/** 店铺名 */
@property(nonatomic,copy)NSString *s_name;
/** 店铺id */
@property(nonatomic,copy)NSString *s_id;
/** 物流 */
@property(nonatomic,assign)int freight_status;

/** 留言 */
@property(nonatomic,copy)NSString *words;

@end


@interface AttribAffirmModel : NSObject
/** 价格 */
@property (nonatomic,copy) NSString *pro_price;
/** 属性 */
@property (nonatomic,copy) NSString *attribute;
/** 数量 */
@property (nonatomic,copy) NSString *pro_number;



@end


