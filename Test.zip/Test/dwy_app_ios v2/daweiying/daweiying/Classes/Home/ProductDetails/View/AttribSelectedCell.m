//
//  AttribSelectedCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/19.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "AttribSelectedCell.h"
#import "ProductAttrModel.h"

@implementation AttribSelectedCell
{
    UITextField *txtNum;
    UILabel *_remarkLabel;
    
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        //初始化cell
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"天蓝色"];
        nameLabel.frame = CGRectMake(kWidth(15), kHeight(10), kWidth(150), kHeight(20));
        [self.contentView addSubview:nameLabel];
        _nameLabel = nameLabel;
        
        UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:@"有货"];
        remarkLabel.frame = CGRectMake(kWidth(15), kHeight(30), kWidth(150), kHeight(20));
        [self.contentView addSubview:remarkLabel];
        
    
        UIView *pkgV = [[UIView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-(kWidth(160)), kHeight(10), kWidth(150), kHeight(40))];
        pkgV.layer.cornerRadius = 5;
        pkgV.layer.borderColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR].CGColor;
        pkgV.layer.borderWidth = 1;
        pkgV.layer.masksToBounds = YES;
        [self.contentView addSubview:pkgV];
        
        //库存
        UILabel *NumLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:@"3332"];
        NumLabel.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:NumLabel];
        NumLabel.sd_layout
        .yIs(kHeight(10))
        .rightSpaceToView(pkgV, kWidth(10))
        .widthIs(100)
        .heightIs(kHeight(40));
        _NumLabel = NumLabel;
        
        UIButton *cutBtn = [UIButton addBtnImage:@"shopspec_btn_reduce_22_22" WithTarget:self action:@selector(Btnclick:)]; //74 76
        cutBtn.tag = 10010;
        cutBtn.frame = CGRectMake(0, 0, kWidth(38), 38);
        [pkgV addSubview:cutBtn];
        
        __weak typeof (self)weakSelf = self;
        self.numberLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"1"];
        self.numberLabel.textAlignment = NSTextAlignmentCenter;
        self.numberLabel.layer.borderColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR].CGColor;
        self.numberLabel.layer.borderWidth = 1;
        self.numberLabel.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            [weakSelf showAlert];
        }];
        [self.numberLabel addGestureRecognizer:tap];
        self.numberLabel.frame = CGRectMake(kWidth(39), 0, kWidth(74), kHeight(40));
        [pkgV addSubview:self.numberLabel];
        
        
        UIButton *addBtn = [UIButton addBtnImage:@"shopspec_btn_add_22_22" WithTarget:self action:@selector(Btnclick:)];
        addBtn.tag = 10086;
        addBtn.frame = CGRectMake(kWidth(112), 0, kWidth(38), 38);
        [pkgV addSubview:addBtn];
        
        
    }
    return self;
}

-(void)setModel:(ProductAttrModel *)model{
    _model = model;
    _nameLabel.text = model.attribute;
    _NumLabel.text = [NSString stringWithFormat:@"%ld",model.repertory];
    if (model.repertory > 0) {
        _remarkLabel.text = @"有货";
    }else{
        _remarkLabel.text = @"无库存";
    }
    self.numberLabel.text = [NSString stringWithFormat:@"%ld",model.buyNumber];
}

-(void)showAlert{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"请输入数量" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    txtNum = [alert textFieldAtIndex:0];
    txtNum.keyboardType =  UIKeyboardTypeNumberPad;
    txtNum.delegate = self;
    txtNum.placeholder = @"请输入数量";
    [alert show];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    //不能一来就输入0
    if (textField.text.length == 0 && [string isEqualToString:@"0"]) {
        
        return NO;
    }
    
    if (textField.text.length > 7 ) {
        if ([string isEqualToString:@""]) {
            return YES;
        }
        return NO;
    }
    return YES;
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) { //确认
        
        
        if ([txtNum.text integerValue] > self.model.repertory) {
            self.numberLabel.text = [NSString stringWithFormat:@"%ld",self.model.repertory];
        }else{
            self.numberLabel.text = txtNum.text;
        }
        self.model.buyNumber = [self.numberLabel.text integerValue];
        self.numberClickBlock();
        
    }
}

-(void)Btnclick:(UIButton *)sender{
    
    self.number =[self.numberLabel.text integerValue];

    if (sender.tag == 10086) {
        self.number +=1;
    }else if (sender.tag == 10010){
        self.number -=1;
    }
    NSLog(@"%ld----%ld",self.number,self.model.repertory);
    if (self.number >=0 && self.number <= self.model.repertory && self.model.repertory > 0) {
        self.numberLabel.text = [NSString stringWithFormat:@"%ld",self.number];
         self.model.buyNumber = self.number;
        self.numberClickBlock();  //
    }
   
//    else{
//        [MBManager showError:@"数量不能小于1"];
//    }
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
