//
//  UIView+WLExtension.m
//  WLSelectAttributes
//
//  Created by 汪亮 on 2017/11/16.
//  Copyright © 2017年 汪亮. All rights reserved.
//

#import "UIView+WLExtension.h"

@implementation UIView (WLExtension)


-(void)setWL_x:(CGFloat)WL_x{
    CGRect frame = self.frame;
    frame.origin.x = WL_x;
    self.frame = frame;

}

-(void)setWL_y:(CGFloat)WL_y{
    
    CGRect frame = self.frame;
    frame.origin.y = WL_y;
    self.frame = frame;
}

-(CGFloat)WL_x{
    
    return self.frame.origin.x;
}

-(CGFloat)WL_y{
    
    return self.frame.origin.y;
}

-(void)setWL_centerX:(CGFloat)WL_centerX{

    CGPoint center = self.center;
    center.x = WL_centerX;
    self.center = center;
}


-(CGFloat)WL_centerX{
    
    return self.center.x;
}

-(void)setWL_centerY:(CGFloat)WL_centerY{

    CGPoint center = self.center;
    center.y = WL_centerY;
    self.center = center;
}


-(CGFloat)WL_centerY{
    
    return self.center.y;
}

-(void)setWL_width:(CGFloat)WL_width{
    CGRect frame = self.frame;
    frame.size.width = WL_width;
    self.frame = frame;

}
-(void)setWL_height:(CGFloat)WL_height{
    CGRect frame = self.frame;
    frame.size.height = WL_height;
    self.frame = frame;

}


-(CGFloat)WL_height{
    
    return self.frame.size.height;
}

-(CGFloat)WL_width{
    
    return self.frame.size.width;
}

-(void)setWL_size:(CGSize)WL_size{

    CGRect freme = self.frame;
    freme.size = WL_size;
    self.frame = freme;

}


-(CGSize)WL_size{
    
    return self.frame.size;
}

-(void)setWL_origin:(CGPoint)WL_origin{
   
    CGRect frame = self.frame;
    frame.origin = WL_origin;
    self.frame = frame;
}

-(CGPoint)WL_origin{
    
    return self.frame.origin;
}


@end
