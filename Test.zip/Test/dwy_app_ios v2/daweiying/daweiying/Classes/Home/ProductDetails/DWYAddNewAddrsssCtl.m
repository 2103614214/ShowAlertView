//
//  DWYAddNewAddrsssCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/26.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAddNewAddrsssCtl.h"

#import "ChooseLocationView.h"
#import "CitiesDataTool.h"
#import "AppDelegate.h"

#import "SelectAreaView.h"  //test
#import "Region.h"

@interface DWYAddNewAddrsssCtl () <UIGestureRecognizerDelegate>

@property (nonatomic,strong) ChooseLocationView *chooseLocationView;
@property (nonatomic,strong) UIView  *cover;
/** 区域 */
@property(nonatomic,strong)UILabel  *addresslabel;


@property(nonatomic,copy)NSString *province;
@property(nonatomic,copy)NSString *city;
@property(nonatomic,copy)NSString *area;
/** 是否编辑 */
@property(nonatomic,assign)BOOL isEdit;

/** 是否设为默认 */
@property(nonatomic,assign)BOOL isDefault;


//test
@property(nonatomic,strong)SelectAreaView *selectView;//选择地区视图
@property(nonatomic,strong)UIView *smallBgView;//选择地区下方白色区域
@property(nonatomic,strong)NSMutableArray *dataArray1;//地址列表数据
@property(nonatomic,strong)NSMutableArray *areaInfoArray;//返回地址相关信息

@end

@implementation DWYAddNewAddrsssCtl
{
    UITextField *_nameText;
    UITextField *_telText;
    UITextField *_detailText;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"新增地址";
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:(UIBarButtonItemStylePlain) target:self action:@selector(saveAddrsss)];
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor blackColor];
    
    [self initWithSubViews]; //初始化控件
    
    //[[CitiesDataTool sharedManager] requestGetData];
    
    [self.view addSubview:self.cover];
    
    if (self.jumpType == 1) { //修改
        self.title = @"修改地址";
        _nameText.text = self.model.name;
        _telText.text = self.model.phone;
        _detailText.text = self.model.address_name;
        self.province = self.model.province;
        if ([Utils isBlankString:self.model.city]) {
            self.city = self.model.province;
        }else{
            self.city = self.model.city;
        }
        
        self.area = self.model.area;
        self.addresslabel.text = NSStringFormat(@"%@%@%@",self.model.province,self.model.city,self.model.area);
    }
}

//保存收货地址
-(void)saveAddrsss{
    if (_nameText.text.length <1 && _telText.text.length <1 && _detailText.text.length<1 && self.addresslabel.text.length <1 ) {
        
        [MBManager showError:@"请确认信息是否填写完整"];
        return;
    }
    
    [MBManager showLoading];
    if (self.isEdit) {
        self.province = self.chooseLocationView.province;
        self.area = self.chooseLocationView.area;
         self.city = self.chooseLocationView.city;
        if ([Utils isBlankString:self.city]) {
            self.city = self.chooseLocationView.province;
        }
    }
    

    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"name"] = _nameText.text;
    params[@"phone"] = _telText.text;
    params[@"province"] = self.province;
    params[@"city"] = self.city;
    if ([Utils isBlankString:self.area]) {
        params[@"area"] = @" ";
    }else{
        params[@"area"] = self.area;
    }
    //params[@"area"] = self.area;
    params[@"address"] = _detailText.text;
    params[@"statu"] = @(self.isDefault);
    
    NSString *urlStr;
    if (self.jumpType == 1) {
        params[@"a_id"] = @(self.model.id);
        urlStr = [Utils getMemberServiceUri:@"update_address"];
    }else{
        urlStr = [Utils getMemberServiceUri:@"add_address"];
    }
    
     //NSLog(@"%@",[Utils transformUnicode:params]);
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
         [MBManager hideAlert];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
       NSLog(@"%@",[Utils transformUnicode:responseObject]);
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"提交成功"];
            
            //存储地址
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setObject:_telText.text forKey:@"add_Phone"];
            [ud setObject:_nameText.text forKey:@"add_Name"];
            [ud setObject:self.province forKey:@"province"];
            [ud setObject:self.city forKey:@"city"];
            [ud setObject:self.area forKey:@"area"];
            [ud setObject:_detailText.text forKey:@"address_name"];
            if (self.jumpType == 1) {
        
                [ud setObject:@(self.model.id) forKey:@"address_id"];
            }
            
            [ud synchronize];
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
  
                [self Refresh];  //返回上一页刷新数据
            });
      
        }else if ([status isEqualToString:@"402"]){
             [MBManager showError:@"手机号有误"];
        }
        else{
            [MBManager showError:@"提交失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        
        //DLog(@"%@",error);
        [MBManager showError];
        
    }];

}
//返回上一页，刷新数据
-(void)Refresh{
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"Refresh" object:nil];
    [self.navigationController popViewControllerAnimated:YES];
    
}


-(void)initWithSubViews{
    
    UILabel *linkman = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"联系人"];
    linkman.frame = CGRectMake(10, 74, 100, 21);
    [self.view addSubview:linkman];

    UIView *linkmanView = [UIView new];
    linkmanView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:linkmanView];
    linkmanView.sd_layout
    .topSpaceToView(linkman, 10)
    .leftSpaceToView(self.view, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(90);
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"收货人:"];
    nameLabel.frame = CGRectMake(10, 0, 80, linkmanView.height/2-1);
    [linkmanView addSubview:nameLabel];
    
    UITextField *nameText = [UITextField new];
    nameText.placeholder = @"请填写收货人姓名";
    nameText.font = [UIFont systemFontOfSize:15.0f];
    [linkmanView addSubview:nameText];
    nameText.sd_layout
    .yIs(0)
    .leftSpaceToView(nameLabel, 10)
    .widthIs(SCREEN_WIDTH-80)
    .heightIs(44);
    _nameText = nameText;
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [linkmanView addSubview:line];
    line.sd_layout
    .topSpaceToView(nameLabel, 0)
    .xIs(10)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    UILabel *telLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"联系电话:"];
    telLabel.frame = CGRectMake(10, 45, 80, linkmanView.height/2);
    [linkmanView addSubview:telLabel];
    
    UITextField *telText = [UITextField new];
    telText.placeholder = @"请填写收货人的电话";
    telText.keyboardType = UIKeyboardTypeDecimalPad;
    telText.font = [UIFont systemFontOfSize:15.0f];
    [linkmanView addSubview:telText];
    telText.sd_layout
    .yIs(45)
    .leftSpaceToView(telLabel, 10)
    .widthIs(SCREEN_WIDTH-80)
    .heightIs(44);
    _telText = telText;
    
    UILabel *addressLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"收货地址"];
    [self.view addSubview:addressLabel];
    addressLabel.sd_layout
    .topSpaceToView(linkmanView, 10)
    .leftSpaceToView(self.view, 10)
    .widthIs(100)
    .heightIs(21);
    
    UIView *addressView = [UIView new];
    addressView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:addressView];
    addressView.sd_layout
    .topSpaceToView(addressLabel, 10)
    .leftSpaceToView(self.view, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(90);
    
    UILabel *areaLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"所在区域:"];
    areaLabel.frame = CGRectMake(10, 0, 80, linkmanView.height/2-1);
    [addressView addSubview:areaLabel];
    
    
    UILabel *areaText = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@""];
    areaText.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        [self selectArea];
    }];
    [areaText addGestureRecognizer:tap];
    [addressView addSubview:areaText];
    areaText.sd_layout
    .yIs(0)
    .leftSpaceToView(areaLabel, 10)
    .widthIs(SCREEN_WIDTH-128)
    .heightIs(44);
    self.addresslabel = areaText;
    
    
    UIImage *imageName = [UIImage imageNamed:@"shopstore_btn_goto_13_13"];
    UIImageView *imgV = [[UIImageView alloc] initWithImage:imageName];
    imgV.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        [self selectArea];
    }];
    [imgV addGestureRecognizer:tap1];
    [addressView addSubview:imgV];
    imgV.sd_layout
    .yIs(13)
    .leftSpaceToView(areaText, 0)
    .widthIs(18)
    .heightIs(18);
    
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [addressView addSubview:line1];
    line1.sd_layout
    .topSpaceToView(areaLabel, 0)
    .xIs(10)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    UILabel *detailLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"详细地址:"];
    detailLabel.frame = CGRectMake(10, 45, 80, linkmanView.height/2);
    [addressView addSubview:detailLabel];
    
    UITextField *detailText = [UITextField new];
    detailText.placeholder = @"请填写收货人详细地址";
    detailText.font = [UIFont systemFontOfSize:15.0f];
    [addressView addSubview:detailText];
    detailText.sd_layout
    .yIs(45)
    .leftSpaceToView(detailLabel, 10)
    .widthIs(SCREEN_WIDTH-80)
    .heightIs(44);
    _detailText = detailText;
    

    UIButton *btn = [[UIButton alloc] init];
    [btn setTitle:@"  设为默认地址" forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"btn_choose_style2_15_15"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"btn_choose_style1_15_15"] forState:UIControlStateSelected];
    [btn setTitleColor:[UIColor blackColor] forState:0];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    [btn addTarget:self action:@selector(settingDefault:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    btn.sd_layout
    .topSpaceToView(addressView, 10)
    .xIs(10)
    .widthIs(130)
    .heightIs(40);
    
    if (self.model.statu == 1) {
        btn.hidden = YES;
    }
}

-(void)settingDefault:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        self.isDefault = YES;
    }else{
        self.isDefault = NO;
    }
    
}

#pragma mark ----   test
-(void)selectArea {
    [self.view endEditing:YES];
    if(_dataArray1.count < 1) {
        [MBManager showLoading];
        NSMutableDictionary *params = [NSMutableDictionary dictionary];
        NSString *urlStr = [Utils getMemberLoginUri:@"getAllProvince"];
        
        [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
            //NSLog(@"----%@",responseObject);
            NSMutableDictionary *ret = [Utils didResponse:responseObject];
            NSString *status = [ret objectForKey:@"status"];
            NSString *message = [ret objectForKey:@"message"];
            id dataObject = [responseObject objectForKey:@"data"];
            [MBManager hideAlert];
            if (![status isEqualToString:@"200"]) {
                [MBManager showError:message];
            } else {
                
                
                [self selectView:dataObject];
                
                [self doSelectArea];
            }
        } failure:^(NSError * _Nonnull error) {
            [MBManager showError];
        }];
        
    } else {
        [self doSelectArea];
    }
    
    
}

-(void)selectView:(id)dataObject{
    NSMutableArray *list = dataObject[@"list"];
    
    _dataArray1 = [NSMutableArray new];
    for(int i = 0; i < list.count; i++) {
        Region *region = [[Region alloc] initWithDict:[list objectAtIndex:i]];
        [_dataArray1 addObject:region];
    }
    __weak typeof (self)weakSelf = self;
    _smallBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    _smallBgView.backgroundColor = [UIColor darkGrayColor];
    _smallBgView.alpha = 0.5;
    _smallBgView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        weakSelf.smallBgView.hidden = YES;
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        weakSelf.selectView.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT/3*2);
        [UIView commitAnimations];
    }];
    [_smallBgView addGestureRecognizer:tap];
    [self.view addSubview:_smallBgView];
    
    _selectView = [[SelectAreaView alloc] initWithProvinceList:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT/3*2) dataArray:_dataArray1 vc:self];
    [self.view addSubview:_selectView];
    
    
    _selectView.SelectAreaFinishBlock = ^(int type, NSMutableArray *array) {
        weakSelf.smallBgView.hidden = YES;
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        weakSelf.selectView.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT/3*2);
        [UIView commitAnimations];
        
        if (type == 1) {
            if (array.count > 0) {
                for (int i = 0; i<array.count; i++) {
                    Region *model = array[i];
                    if (i == 0) {
                        weakSelf.province = model.name;
                    }else if (i == 1){
                        if ([model.name isEqualToString:@"县"] || [model.name isEqualToString:@"市辖区"]) {
                            weakSelf.city = @" ";
                        }else{
                            weakSelf.city = model.name;
                        }
                    }else if (i == 2){
                        weakSelf.area = model.name;
                    }
                }
                
                if(weakSelf.province.length > 0) {
                    weakSelf.addresslabel.text = NSStringFormat(@"%@ %@ %@",weakSelf.province,weakSelf.city,weakSelf.area);
                }
            }
        }
    
        
    };
    
}

-(void)doSelectArea {
    _smallBgView.hidden = NO;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    CGFloat a = [Utils baseNavScrollViewHeight];
    
    _selectView.frame = CGRectMake(0, a / 3 + [Utils baseNavScrollViewTop], SCREEN_WIDTH, a / 3 * 2);
    [UIView commitAnimations];
}



//弹出区域选择页面
-(void)areaChoose{

    [UIView animateWithDuration:0.25 animations:^{
        self.view.transform =CGAffineTransformMakeScale(1.0, 1.0);
    }];
    self.cover.hidden = !self.cover.hidden;
    self.chooseLocationView.hidden = self.cover.hidden;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    
    CGPoint point = [gestureRecognizer locationInView:gestureRecognizer.view];
    if (CGRectContainsPoint(_chooseLocationView.frame, point)){
        return NO;
    }
    return YES;
}


- (void)tapCover:(UITapGestureRecognizer *)tap{
    
    if (_chooseLocationView.chooseFinish) {
        _chooseLocationView.chooseFinish();
    }
}

- (ChooseLocationView *)chooseLocationView{
    
    if (!_chooseLocationView) {
        _chooseLocationView = [[ChooseLocationView alloc]initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 350, [UIScreen mainScreen].bounds.size.width, 350)];
        
    }
    return _chooseLocationView;
}

- (UIView *)cover{
    
    if (!_cover) {
        _cover = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
        _cover.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];
        [_cover addSubview:self.chooseLocationView];
        __weak typeof (self) weakSelf = self;
        _chooseLocationView.chooseFinish = ^{
            [UIView animateWithDuration:0.25 animations:^{
                NSString *province = weakSelf.chooseLocationView.province;
                NSString *city = weakSelf.chooseLocationView.city;
                NSString *area = weakSelf.chooseLocationView.area;
                if (![Utils isBlankString:province]) {
                    weakSelf.addresslabel.text = NSStringFormat(@"%@ %@ %@",province,city,area);
                }
                weakSelf.view.transform = CGAffineTransformIdentity;
                weakSelf.cover.hidden = YES;
                weakSelf.isEdit = YES;
            }];
        };
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapCover:)];
        [_cover addGestureRecognizer:tap];
        tap.delegate = self;
        _cover.hidden = YES;
    }
    return _cover;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
