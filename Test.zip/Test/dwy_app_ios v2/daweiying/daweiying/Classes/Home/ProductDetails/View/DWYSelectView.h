//
//  DWYSelectView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DWYSelectView : UIView <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) NSArray *objects;

@property (nonatomic,strong) UITableView *tableView;

/**  是否为支付类型 */
@property(nonatomic,assign)int isPayType;
@property (nonatomic,copy) NSString *selectedStr;

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSArray *)objects isPayType:(int)isPayType WithStr:(NSString *)str;

@property (nonatomic,copy) void (^closeView)();
@property (nonatomic,copy) void(^selectedCellClick)(NSString *string);


@end
