//
//  PayTypeCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/31.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "PayTypeCell.h"

@implementation PayTypeCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        //初始化控件
        UIImageView *selectedV = [[UIImageView alloc] initWithFrame:CGRectMake(15, (self.height-20)/2, 20, 20)];
        [selectedV setImage:[UIImage imageNamed:@"color_no_choose"]];
        [self.contentView addSubview:selectedV];
        self.selectedV = selectedV;
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@""];
        nameLabel.adjustsFontSizeToFitWidth = YES;
        nameLabel.frame = CGRectMake(30+selectedV.width, (self.height-20)/2, SCREEN_WIDTH-selectedV.width-40, 20);
        [self.contentView addSubview:nameLabel];
        self.nameLabel = nameLabel;
        
    }
    return self;
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
