//
//  DWYAddressCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/26.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAddressCell.h"
#import "DWYAddressModel.h"

@implementation DWYAddressCell
{
    UILabel *_nameLabel;
    UILabel *_telLabel;
    UIButton *_selectBtn;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //初始化控件
        self.backgroundColor = [UIColor whiteColor];
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@""];
        nameLabel.frame = CGRectMake(10, 10, 100, 21);
        [self addSubview:nameLabel];
        _nameLabel = nameLabel;
        
        UILabel *telLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@""];
        telLabel.frame = CGRectMake(130, 10, 150, 21);
        [self addSubview:telLabel];
        _telLabel = telLabel;
        
        UILabel *addressLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@""];
        [self addSubview:addressLabel];
        addressLabel.sd_layout
        .topSpaceToView(nameLabel, 8)
        .xIs(10)
        .widthIs(SCREEN_WIDTH-20)
        .heightIs(21);
        self.addressLabel = addressLabel;
        
        UILabel *line = [UILabel new];
        line.backgroundColor = [UIColor colorWithHex:0xd9d9d9];
        [self addSubview:line];
        line.sd_layout
        .topSpaceToView(addressLabel, 12)
        .xIs(0)
        .widthIs(SCREEN_WIDTH)
        .heightIs(1);
        
        //默认地址
        UIButton *selectBtn = [UIButton new];
        [selectBtn setImage:[UIImage imageNamed:@"color_no_choose"] forState:UIControlStateNormal];
        [selectBtn setImage:[UIImage imageNamed:@"color_choose"] forState:UIControlStateSelected];
        [selectBtn setTitle:@"  默认地址" forState:UIControlStateNormal];
        selectBtn.tag = 100;
        [selectBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        selectBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [selectBtn addTarget:self action:@selector(chooseClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:selectBtn];
        selectBtn.sd_layout
        .topSpaceToView(line, 5)
        .leftSpaceToView(self, 5)
        .widthIs(100)
        .heightIs(35);
        _selectBtn = selectBtn;
        
        //删除
        UIButton *delBtn = [UIButton new];
        [delBtn setImage:[UIImage imageNamed:@"shopaddress_btn_delet_18_18"] forState:UIControlStateNormal];
        [delBtn setTitle:@"  删除" forState:UIControlStateNormal];
        [delBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        delBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        delBtn.tag = 101;
        [delBtn addTarget:self action:@selector(chooseClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:delBtn];
        delBtn.sd_layout
        .topSpaceToView(line, 5)
        .rightSpaceToView(self, 5)
        .widthIs(80)
        .heightIs(35);
        
        //编辑
        UIButton *editBtn = [UIButton new];
        [editBtn setImage:[UIImage imageNamed:@"shopaddress_btn_write_18_18"] forState:UIControlStateNormal];
        [editBtn setTitle:@"  编辑" forState:UIControlStateNormal];
        [editBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        editBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        editBtn.tag = 102;
        [editBtn addTarget:self action:@selector(chooseClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:editBtn];
        editBtn.sd_layout
        .topSpaceToView(line, 5)
        .rightSpaceToView(delBtn, 5)
        .widthIs(80)
        .heightIs(35);
        
        
        
    }
    return self;
}

-(void)chooseClick:(UIButton *)sender{
    // sender.selected = !sender.selected;
    
    self.block(sender.tag);
   
}



-(void)setModel:(DWYAddressModel *)model{
    _model = model;
    _nameLabel.text = model.name;
    _telLabel.text = model.phone;
    _addressLabel.text = [NSString stringWithFormat:@"%@%@%@%@",model.province,model.city,model.area,model.address_name];
    if (model.statu == 1) {
        _selectBtn.selected = YES;
    }else{
        _selectBtn.selected = NO;
    }
}

//设置cell之间的间距
-(void)setFrame:(CGRect)frame{
    frame.origin.y +=10;
    frame.size.height-=10;
    [super setFrame:frame];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
