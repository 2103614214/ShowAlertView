//
//  RatingView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RatingView;

@protocol ratingViewDelegate <NSObject>

@optional
- (void)ratingView:(RatingView *)view score:(CGFloat)score;

@end

typedef NS_ENUM(NSUInteger, RatingType) {
    INTEGER_TYPE,
    FLOAT_TYPE
};

@interface  RatingView: UIView

@property (nonatomic,assign)RatingType ratingType;//评分类型，整颗星或半颗星
@property (nonatomic,assign)CGFloat score;//当前分数

- (instancetype)initWithFrame:(CGRect)frame isEdit:(BOOL)isEdit;

@property (nonatomic,assign)id<ratingViewDelegate> delegate;

@end
