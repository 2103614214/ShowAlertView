//
//  DWYCommentCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYCommentCell.h"
#import "DWYCommentModel.h"

#import "RatingView.h"


@interface DWYCommentCell() <ratingViewDelegate>

@end

@implementation DWYCommentCell
{
    UIImageView *_userLogoV;
    UILabel *_userLabel;
    UILabel *_commentLabel;
    UILabel *_dateLabel;
    UILabel *_attributeLabel;
    RatingView *_rView;
    UIImageView *_imageV1;
    UIImageView *_imageV2;
    UIImageView *_imageV3;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        //初始化控件
        self.backgroundColor = [UIColor whiteColor];
        
        UIImageView *userLogoV = [[UIImageView alloc] init];
        userLogoV.frame = CGRectMake(10, 10, 35, 35);
        userLogoV.backgroundColor = [UIColor greenColor];
        userLogoV.layer.cornerRadius = userLogoV.width/2;
        userLogoV.layer.masksToBounds = YES;
        userLogoV.layer.borderColor = [UIColor colorWithHex:0xd7d7d7].CGColor;
        userLogoV.layer.borderWidth = 1;
        [self addSubview:userLogoV];
        _userLogoV = userLogoV;
        
        UILabel *userLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
        [self addSubview:userLabel];
        userLabel.sd_layout
        .topSpaceToView(self, 15)
        .leftSpaceToView(userLogoV, 10)
        .widthIs(kWidth(180))
        .heightIs(21);
        _userLabel= userLabel;
        
        UILabel *commentLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
        [self addSubview:commentLabel];
        commentLabel.sd_layout
        .topSpaceToView(userLogoV, 5)
        .leftSpaceToView(self, 10)
        .widthIs(SCREEN_WIDTH-20)
        .heightIs(21);
        _commentLabel = commentLabel;
        
        UILabel *dateLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:13 numberOfLines:1 text:@""];
        [self addSubview:dateLabel];
        dateLabel.sd_layout
        .topSpaceToView(commentLabel, 2)
        .leftSpaceToView(self, 10)
        .widthIs(120)
        .heightIs(18);
        _dateLabel = dateLabel;
        
        UILabel *attributeLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:13 numberOfLines:1 text:@""];
        [self addSubview:attributeLabel];
        attributeLabel.sd_layout
        .topSpaceToView(commentLabel, 0)
        .leftSpaceToView(dateLabel, 10)
        .widthIs(150)
        .heightIs(18);
        _attributeLabel = attributeLabel;
        
        //评分
        RatingView * rView = [[RatingView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-110, 10, 100, 30) isEdit:NO];
         rView.delegate = self;
        rView.ratingType = INTEGER_TYPE;//整颗星
        [self addSubview:rView];
        _rView = rView;
        
        float imageVW = (SCREEN_WIDTH-40)/3;
        float imageVH = 80;
        float imageX = 10;
        for (int i = 0; i<3; i++) {
            
            __weak typeof (self)weakSelf = self;
            UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(imageX, 110, imageVW, imageVH)];
            imageV.userInteractionEnabled = YES;
            imageV.tag = 100+i;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
            [[tap rac_gestureSignal] subscribeNext:^(id x) {
                
                weakSelf.imageClickBlock(weakSelf.model,i);
                
            }];
            [imageV addGestureRecognizer:tap];
            [self.contentView addSubview:imageV];
            
            imageX +=(imageV.width+imageX);
            if (i == 0) {
                _imageV1 = imageV;
            }else if (i == 1){
                _imageV2 = imageV;
            }else{
                _imageV3 = imageV;
            }
        }
        
    }
    return self;
}


-(void)setModel:(DWYCommentModel *)model{
    _model = model;
    [_userLogoV sd_setImageWithURL:[NSURL URLWithString:model.user_logo] placeholderImage:[UIImage imageNamed:@"shopstore_img_logo_45_45"]];
    _userLabel.text = model.username;
    _commentLabel.text = model.c_content;
    _attributeLabel.text = [NSString stringWithFormat:@"所购规格: %@",model.pro_attr];
    
//    NSString *dateStr = [Utils getTimestamp:model.c_time];
//    dateStr = [Utils getTimeStr:[dateStr integerValue]];
    _dateLabel.text = model.c_time;
    
    if (model.img_json.count > 0) {
        
        int i = 0;
        for (NSString *name in model.img_json) {
            if (i == 0) {
                [_imageV1 sd_setImageWithURL:[NSURL URLWithString:name] placeholderImage:[UIImage imageNamed:placeImageName]];
            }else if (i == 1){
                [_imageV2 sd_setImageWithURL:[NSURL URLWithString:name] placeholderImage:[UIImage imageNamed:placeImageName]];
            }else if (i == 2){
                [_imageV3 sd_setImageWithURL:[NSURL URLWithString:name] placeholderImage:[UIImage imageNamed:placeImageName]];
            }
            
            i++;
        }
    }

    
    _rView.score = model.grade; //星级
    

    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
