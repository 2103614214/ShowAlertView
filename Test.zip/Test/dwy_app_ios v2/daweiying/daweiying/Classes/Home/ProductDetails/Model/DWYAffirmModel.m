//
//  DWYAffirmModel.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAffirmModel.h"

@implementation DWYAffirmModel

@end

//AttribAffirmModel
@implementation AttribAffirmModel

@end
