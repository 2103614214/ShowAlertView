//
//  WLSelectAttributes.h
//  WLSelectAttributes
//
//  Created by 汪亮 on 2017/11/16.
//  Copyright © 2017年 汪亮. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIView+WLExtension.h"

@protocol SelectAttributesDelegate <NSObject>
@required
-(void)selectBtnTitle:(NSString *)title andBtn:(UIButton *)btn;

@end

@interface WLSelectAttributes : UIView

@property(nonatomic,copy)NSString *title;
@property(nonatomic,strong)NSArray *attributesArray;

@property(nonatomic,strong)UIButton *selectBtn;

@property(nonatomic,strong)UIView *packView;
@property(nonatomic,strong)UIView *btnView;

@property(nonatomic,assign)id<SelectAttributesDelegate> delegate;



-(instancetype)initWithTitle:(NSString *)title titleArr:(NSArray *)titleArr andFrame:(CGRect)frame;


@end
