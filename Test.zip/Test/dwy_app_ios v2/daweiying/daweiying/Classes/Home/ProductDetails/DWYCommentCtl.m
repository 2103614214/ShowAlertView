//
//  DWYCommentCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYCommentCtl.h"
#import "DWYCommentCell.h"
#import "DWYCommentModel.h"
#import "XLPhotoBrowser.h"

@interface DWYCommentCtl () <UITableViewDelegate,UITableViewDataSource>

/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;

/** temp */
@property(nonatomic,strong)UIImage *tempImage;

@end

static NSString * const CommentCellID = @"CommentCellID";
@implementation DWYCommentCtl

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        if (@available(iOS 11.0, *)) {
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            _tableView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, kTabBarHeight, 0);
            _tableView.scrollIndicatorInsets = _tableView.contentInset;
        }
       // _tableView.rowHeight = 100;
        _tableView.tableHeaderView = [UIView new];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        _tableView.showsVerticalScrollIndicator = NO;
        [_tableView registerClass:[DWYCommentCell class] forCellReuseIdentifier:CommentCellID];
    }
    return _tableView;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"评论";
    
    [self.view addSubview:self.tableView];
    
    //网络请求数据
    [self loadData];
}

//网络请求数据
-(void)loadData{
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"pro_id"] = @(self.pro_id); //@(1);
    NSString *urlStr = [Utils getMemberLoginUri:@"comment"];
   
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
         //NSLog(@"%@",[Utils transformUnicode:responseObject]);


        [self.tableView.mj_header endRefreshing];

        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];

        if ([status isEqualToString:@"200"]) {

            id dataObject = [responseObject objectForKey:@"data"];

            //数据源
            NSDictionary *commentDict = [dataObject objectForKey:@"comments"];
            self.dataArray = [DWYCommentModel mj_objectArrayWithKeyValuesArray:commentDict];

            [self.tableView reloadData];
        }else if ([status isEqualToString:@"201"]){
            [self.tableView showBlankPageView:7];
        }
        else{
            [MBManager showError:@"获取数据失败"];
        }

    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.tableView.mj_header endRefreshing];

       // NSLog(@"%@",error);
    }];

}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = NO;
}

#pragma mark - UITableView 代理，数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DWYCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:CommentCellID];
    if (!cell) {
        cell = [[DWYCommentCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CommentCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    cell.model = self.dataArray[indexPath.row];
    
    cell.imageClickBlock = ^(DWYCommentModel *model, NSInteger tag) {
        XLPhotoBrowser *browser = [XLPhotoBrowser showPhotoBrowserWithImages:model.img_json currentImageIndex:tag];
        // 自定义pageControl的一些属性
        browser.pageDotColor = [UIColor grayColor];
        browser.currentPageDotColor = [UIColor redColor];
        browser.pageControlStyle = XLPhotoBrowserPageControlStyleClassic;
    };
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DWYCommentModel *model = self.dataArray[indexPath.row];
    
    return model.cellHeight;
    
}




-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
   // NSLog(@"%ld",indexPath.row);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
