//
//  DWYSelectView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYSelectView.h"
#import "PayTypeCell.h"


static NSString * const payTypeCellID = @"payTypeCellID";
@implementation DWYSelectView


-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSArray *)objects isPayType:(int)isPayType WithStr:(NSString *)str{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        self.objects = objects;
        self.isPayType = isPayType;
        self.selectedStr = str;
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    
    self.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.7];
    self.tableView = [[UITableView alloc] initWithFrame:self.bounds];
    self.tableView.bounces = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[PayTypeCell class] forCellReuseIdentifier:payTypeCellID];
    
}


#pragma mark - TableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.objects count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return kHeight(50);
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PayTypeCell *cell = [tableView dequeueReusableCellWithIdentifier:payTypeCellID forIndexPath:indexPath];
    if (!cell) {
        cell = [[PayTypeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:payTypeCellID];
    }
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    if ([self.objects[indexPath.row] isEqualToString:self.selectedStr]) {
        [cell.selectedV setImage:[UIImage imageNamed:@"color_choose"]];
    }
    cell.nameLabel.text = self.objects[indexPath.row];

    return cell;
    
}

#define SECTION_HEIGHT kHeight(50.0)
// 设置section的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    
    return SECTION_HEIGHT;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return SECTION_HEIGHT;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SECTION_HEIGHT)];
    NSString *Str = @"";
    if (self.isPayType == 1) {
        Str = @"请选择支付类型";
    }else if (self.isPayType == 2){
        Str = @"请选择配送方式";
    }else if (self.isPayType == 3){
        Str = @"请选择延迟收货时间";
    }else if (self.isPayType == 4){
        Str = @"请选经营大类";
    }else{
        Str = @"请选择店铺类型";
    }
    UILabel *chooseLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:Str];
    chooseLabel.textAlignment = NSTextAlignmentCenter;
    chooseLabel.frame = CGRectMake((SCREEN_WIDTH-(kWidth(200)))/2, (view.height-21)/2, kWidth(200), 21);
    [view addSubview:chooseLabel];
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, SECTION_HEIGHT-1, SCREEN_WIDTH, 1)];
    [view addSubview:line];
    
    view.backgroundColor = [UIColor whiteColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SECTION_HEIGHT)];
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [view addSubview:line];
    
    
    UILabel *choseLabel = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:15 numberOfLines:1 text:@"关闭"];
    choseLabel.textAlignment = NSTextAlignmentCenter;
    choseLabel.frame = CGRectMake(0, 1, SCREEN_WIDTH, kHeight(49));
    [view addSubview:choseLabel];
    
    /*添加手势事件,移除View*/
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissContactView)];
    [view addGestureRecognizer:tapGesture];
  
    view.backgroundColor = [UIColor whiteColor];
    return view;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

     [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.selectedCellClick(self.objects[indexPath.row]);
    [self dismissContactView];
}

-(void)dismissContactView{
    self.closeView();
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
