//
//  DWYAddressModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/26.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DWYAddressModel : NSObject
/** 电话 */
@property(nonatomic,copy)NSString *phone;
/** 姓名 */
@property(nonatomic,copy)NSString *name;
/** user_id */
@property(nonatomic,copy)NSString *user_id;
/** 省 */
@property(nonatomic,copy)NSString *province;
/** 市 */
@property(nonatomic,copy)NSString *city;
/** 区 */
@property(nonatomic,copy)NSString *area;
/** 地址 */
@property(nonatomic,copy)NSString *address_name;
/** id */
@property(nonatomic,assign)int id;
/** 是否默认 */
@property(nonatomic,assign)int statu;

@end
