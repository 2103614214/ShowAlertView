//
//  DWYAffirmCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AttribAffirmModel;
@class DWYAffirmGoodsModel;
@interface DWYAffirmCell : UITableViewCell <UIAlertViewDelegate,UITextFieldDelegate>

/** 数据模型 */
@property(nonatomic,strong)AttribAffirmModel *model;

/** 数据模型 */
@property(nonatomic,strong)DWYAffirmGoodsModel *goodsModel;


@property(nonatomic,strong)UIImageView *imageV;
@property(nonatomic,strong)UILabel *nameLabel;

@property(nonatomic,strong)UILabel *numberLabelStr;
@property (nonatomic,assign) NSInteger number;

/** 修改数量 */
@property(nonatomic,copy) void (^editNumberBlock)();

@property(nonatomic,strong)UIView *pkgV;

@end
