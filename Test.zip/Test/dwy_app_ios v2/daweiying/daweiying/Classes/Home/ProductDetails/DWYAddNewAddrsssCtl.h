//
//  DWYAddNewAddrsssCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/26.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"
#import "DWYAddressModel.h"

@interface DWYAddNewAddrsssCtl : BaseViewController

/** 跳转类别 */
@property(nonatomic,assign)int jumpType;
/** 修改类型数据 */
@property(nonatomic,strong)DWYAddressModel *model;

@end
