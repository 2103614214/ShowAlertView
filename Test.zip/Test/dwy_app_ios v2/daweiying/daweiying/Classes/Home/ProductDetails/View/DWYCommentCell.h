//
//  DWYCommentCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DWYCommentModel;

@interface DWYCommentCell : UITableViewCell

/** 数据模型 */
@property(nonatomic,strong)DWYCommentModel *model;

/** 评论图片被点击 */
@property(nonatomic,copy) void (^imageClickBlock)(DWYCommentModel *model,NSInteger tag);

@end
