//
//  DWYAffirmHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DWYAffirmCartModel.h"
#import "DWYAffirmModel.h"

@interface DWYAffirmHeadView : UIView

/** 地址view */
@property(nonatomic,strong)UIView *addressView;
/** 支付方式view */
//@property(nonatomic,strong)UIView *payTypeView;
/** 姓名 */
@property(nonatomic,strong)UILabel *nameLabel;
/** 电话 */
@property(nonatomic,strong)UILabel *telLabel;
/** 地址 */
@property(nonatomic,strong)UILabel *addressLabel;
/** <#注释#> */
@property(nonatomic,strong)UILabel *placeLabel;
/** 支付方式 */
@property(nonatomic,strong)UILabel *payLabel;



@end


@interface DWYAffirmFootView : UITableViewHeaderFooterView


/** 配送方式view */
@property(nonatomic,strong)UIView *distributionTypeView;

//-(instancetype)initWithFrame:(CGRect)frame Withtype:(int)type;

/** 是直接购买还是购物车跳转 */
//@property(nonatomic,assign)int type;
@property(nonatomic,strong)UILabel *sendLabel;
@property(nonatomic,strong)UILabel *p_priceLabel;
@property(nonatomic,strong)UILabel *t_priceLabel;



/** 买家留言 */
@property(nonatomic,strong)UITextField *messageText;

/** 邮递方式 */
@property(nonatomic,assign)int sendType;
/** 计算总价 */
@property(nonatomic,copy) void (^countTotalPriceBlock)(float price);

@property(nonatomic,assign)int sendTypeCart;

/** model */
@property(nonatomic,strong)DWYAffirmCartModel *model;

/** 直接购买 */
@property(nonatomic,strong)DWYAffirmModel *goodsModel;

/** 是否为购物车 */
@property(nonatomic,assign)int jumpType;  //1为购物车  2为直接购买

@end
