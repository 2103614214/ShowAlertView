//
//  EditProCountCell.m
//  daweiying
//
//  Created by 汪亮 on 2018/1/11.
//  Copyright © 2018年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "EditProCountCell.h"
#import "EditProductModel.h"

@implementation EditProCountCell
{
    UILabel *_standard;
    UITextField *_txtFiled;
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //初始化cell
        UILabel *standardLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"商品规格"];
        standardLabel.frame = CGRectMake(kWidth(10), 0, kWidth(80), kHeight(50));
        [self.contentView addSubview:standardLabel];
        
        
        UILabel *standard = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
        standard.frame = CGRectMake(kWidth(100), 0, SCREEN_WIDTH-(kWidth(110)), kHeight(50));
        [self.contentView addSubview:standard];
        _standard = standard;
        
        UILabel *line = [Utils lineWithFrame:CGRectMake(kWidth(10), kHeight(50), SCREEN_WIDTH-(kWidth(10)), 1)];
        [self.contentView addSubview:line];
        
        //库存
        UILabel *countLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"库存(件)"];
        countLabel.frame = CGRectMake(kWidth(10), kHeight(51), kWidth(80), kHeight(50));
        [self.contentView addSubview:countLabel];
        
        __weak typeof (self)weakSelf = self;
        UITextField *txtFiled = [Utils addTextFieldWithFrame:CGRectMake(kWidth(100), kHeight(51), SCREEN_WIDTH-(kWidth(110)), kHeight(49)) AndStr:@"" AndFont:14 AndTextColor:[UIColor blackColor]];
        txtFiled.textAlignment = NSTextAlignmentLeft;
        txtFiled.keyboardType = UIKeyboardTypeNumberPad;
        [[txtFiled rac_textSignal] subscribeNext:^(id x) {
            
            weakSelf.model.repertory = [NSString stringWithFormat:@"%@",x];
        }];
        [self.contentView addSubview:txtFiled];
        _txtFiled = txtFiled;
        
    }
    return self;
}


-(void)setModel:(EditProductModel *)model{
    _model = model;

    _standard.text = model.attribute;
    _txtFiled.text = model.repertory;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
