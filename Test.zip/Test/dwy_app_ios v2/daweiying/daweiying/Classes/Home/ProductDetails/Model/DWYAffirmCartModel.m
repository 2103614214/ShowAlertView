//
//  DWYAffirmCartModel.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/23.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAffirmCartModel.h"

@implementation DWYAffirmCartModel

@end


@implementation DWYAffirmGoodsModel

@end
