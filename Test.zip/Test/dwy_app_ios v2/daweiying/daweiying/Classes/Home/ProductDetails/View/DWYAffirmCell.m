//
//  DWYAffirmCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAffirmCell.h"
#import "DWYAffirmModel.h"
#import "DWYAffirmCartModel.h"

@implementation DWYAffirmCell
{

    UILabel     *_attrLabel;
    UILabel     *_numberLabel;
    UILabel     *_priceLabel;
    UITextField *txtNum;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //初始化控件
        UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 80, 80)];
        imageV.layer.borderWidth = 1;
        imageV.layer.borderColor = [UIColor colorWithHex:0xd7d7d7].CGColor;
        [self addSubview:imageV];
        self.imageV = imageV;
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:2 text:@""];
        nameLabel.frame = CGRectMake(100, 10, SCREEN_WIDTH-150, 40);
        nameLabel.adjustsFontSizeToFitWidth = YES;
        [self addSubview:nameLabel];
        self.nameLabel = nameLabel;
        
        UILabel *attrLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:13 numberOfLines:1 text:@""];
        attrLabel.frame = CGRectMake(100, 50, 120, 20);
        [self addSubview:attrLabel];
        _attrLabel = attrLabel;
        
        UILabel *numberLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:13 numberOfLines:1 text:@""];
        numberLabel.frame = CGRectMake(100, 70, 120, 20);
        [self addSubview:numberLabel];
        _numberLabel = numberLabel;
        
        UILabel *priceLabel = [Utils labelTextColor:[UIColor colorWithHex:0xf67100] fontSize:15 numberOfLines:1 text:@""];
        priceLabel.textAlignment = NSTextAlignmentRight;
        priceLabel.frame = CGRectMake(SCREEN_WIDTH-130, 40, 110, 21);
        [self addSubview:priceLabel];
        _priceLabel = priceLabel;
        
        
        //加减数量
        UIView *pkgV = [[UIView alloc] init];
        pkgV.layer.cornerRadius = 5;
        pkgV.layer.borderColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR].CGColor;
        pkgV.layer.borderWidth = 1;
        pkgV.layer.masksToBounds = YES;
        pkgV.hidden = YES;
        [self.contentView addSubview:pkgV];
        pkgV.sd_layout
        .topSpaceToView(priceLabel, 0)
        .xIs(SCREEN_WIDTH-(kWidth(160)))
        .widthIs(kWidth(150))
        .heightIs(35);
        self.pkgV = pkgV;
        
        UIButton *cutBtn = [UIButton addBtnImage:@"shopspec_btn_reduce_22_22" WithTarget:self action:@selector(Btnclick:)]; //74 76
        cutBtn.tag = 10010;
        cutBtn.frame = CGRectMake(0, 0, kWidth(38), 38);
        [pkgV addSubview:cutBtn];
        
        __weak typeof (self)weakSelf = self;
        self.numberLabelStr = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"1"];
        self.numberLabelStr.textAlignment = NSTextAlignmentCenter;
        self.numberLabelStr.layer.borderColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR].CGColor;
        self.numberLabelStr.layer.borderWidth = 1;
        self.numberLabelStr.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            [weakSelf showAlertNumber];
        }];
        [self.numberLabelStr addGestureRecognizer:tap];
        self.numberLabelStr.frame = CGRectMake(kWidth(39), 0, kWidth(74), kHeight(40));
        [pkgV addSubview:self.numberLabelStr];
        
        
        UIButton *addBtn = [UIButton addBtnImage:@"shopspec_btn_add_22_22" WithTarget:self action:@selector(Btnclick:)];
        addBtn.tag = 10086;
        addBtn.frame = CGRectMake(kWidth(112), 0, kWidth(38), 38);
        [pkgV addSubview:addBtn];
        

        
    }
    return self;
}

-(void)showAlertNumber{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"请输入数量" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    txtNum = [alert textFieldAtIndex:0];
    txtNum.keyboardType =  UIKeyboardTypeNumberPad;
    txtNum.delegate = self;
    txtNum.placeholder = @"请输入数量";
    [alert show];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    //不能一来就输入0
    if (textField.text.length == 0 && [string isEqualToString:@"0"]) {
        
        return NO;
    }
    
    if (textField.text.length > 7 ) {
        if ([string isEqualToString:@""]) {
            return YES;
        }
        return NO;
    }
    return YES;
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) { //确认

        if ([txtNum.text integerValue] > 0) {
            self.model.pro_number = txtNum.text;
            if (self.editNumberBlock) {
                self.editNumberBlock();
            }
        }

    }
}


-(void)Btnclick:(UIButton *)sender{
    

    self.number =[self.numberLabelStr.text integerValue];
    
    if (sender.tag == 10086) {
        self.number +=1;
    }else if (sender.tag == 10010){
        self.number -=1;
    }
    
    if (self.number >0 ) {
        
        self.model.pro_number = [NSString stringWithFormat:@"%ld",self.number];
        if (self.editNumberBlock) {
            self.editNumberBlock();
        }
    }
    
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setModel:(AttribAffirmModel *)model{
    _model = model;
//    NSLog(@"--------%@",model.sell_number);
//    [_imageV sd_setImageWithURL:[NSURL URLWithString:model.logo_url] placeholderImage:[UIImage imageNamed:@"placeholder"]];
//    _nameLabel.text = model.pro_name;
    _attrLabel.text = model.attribute;
    _numberLabel.text = [NSString stringWithFormat:@"%@",model.pro_number];
    self.numberLabelStr.text = [NSString stringWithFormat:@"%@",model.pro_number];
    _priceLabel.text = [NSString stringWithFormat:@"¥ %@",model.pro_price];
}

-(void)setGoodsModel:(DWYAffirmGoodsModel *)goodsModel{
    _goodsModel = goodsModel;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:goodsModel.logo_url] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    self.nameLabel.text = goodsModel.pro_name;
    _attrLabel.text = goodsModel.attribute;
    _numberLabel.text = [NSString stringWithFormat:@"x %@",goodsModel.number];
    _priceLabel.text = [NSString stringWithFormat:@"¥ %@",goodsModel.price];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
