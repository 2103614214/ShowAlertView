//
//  ProductAttrModel.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/8.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "ProductAttrModel.h"

@implementation ProductAttrModel

@end
