//
//  WLSelectView.m
//  WLSelectAttributes
//
//  Created by 汪亮 on 2017/11/16.
//  Copyright © 2017年 汪亮. All rights reserved.
//

#import "WLSelectView.h"
#import "UIView+WLExtension.h"


@interface WLSelectView () <UIAlertViewDelegate>

//规格分类
@property(nonatomic,strong)NSArray *rankArr;

@end
@implementation WLSelectView
{
    UITextField *txtNum;
}


@synthesize alphaView,whiteView,headImage,LB_detail,LB_line,LB_price,LB_stock,LB_showSales,mainscrollview,cancelBtn,addBtn,buyBtn,stockBtn,redView,numberLabel;

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        
        //self.showSales = @"135";
        [self creatUI];
        
    }
    return self;
}



-(void)creatUI{
    
    //半透明视图
    alphaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    alphaView.backgroundColor = [UIColor grayColor];
    alphaView.alpha = 0.5;
    [self addSubview:alphaView];
    
    //装载商品信息的视图
    whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, 200, SCREEN_WIDTH, SCREEN_HEIGHT-200)];
    whiteView.backgroundColor = [UIColor whiteColor];
    [self addSubview:whiteView];
    
    //商品图片
    headImage = [[UIImageView alloc] initWithFrame:CGRectMake(20, -20, 90, 90)];
    headImage.image = [UIImage imageNamed:@"placeholder"];
    headImage.layer.cornerRadius = 4;
    headImage.layer.borderColor = [UIColor lightGrayColor].CGColor;
    headImage.layer.borderWidth = 1;
    [headImage.layer setMasksToBounds:YES];
    [whiteView addSubview:headImage];
    
    cancelBtn= [UIButton buttonWithType:UIButtonTypeCustom];
    cancelBtn.frame = CGRectMake(SCREEN_WIDTH-40, 10, 25, 25);
    [cancelBtn setBackgroundImage:[UIImage imageNamed:@"shop_btn_close_16_16"] forState:0];
    [whiteView addSubview:cancelBtn];
    
    
    //商品价格
    LB_price = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(headImage.frame)+20, 10, 150, 20)];
    LB_price.text = @"";
    LB_price.textColor = [UIColor redColor];
    LB_price.font = [UIFont systemFontOfSize:16];
    [whiteView addSubview:LB_price];
    //商品库存
    LB_stock = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(headImage.frame)+20, CGRectGetMaxY(LB_price.frame), 80, 20)];
    LB_stock.text = @"";
    LB_stock.textColor = [UIColor blackColor];
    LB_stock.font = [UIFont systemFontOfSize:13];
    [whiteView addSubview:LB_stock];
    
    //已售件数
    LB_showSales = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(LB_stock.frame), CGRectGetMaxY(LB_price.frame), 80, 20)];
    LB_showSales.textColor = [UIColor blackColor];
    
//    NSString *sellStr = [NSString stringWithFormat:@"已售 %@ 件",self.showSales];
//    
//    NSDictionary*subStrAttribute = @{
//                                     NSForegroundColorAttributeName: [UIColor redColor],
//                                     };
//    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:sellStr];
//    [attributedText setAttributes:subStrAttribute range:NSMakeRange([sellStr rangeOfString:[self.showSales description]].location, [sellStr rangeOfString:[self.showSales description]].length)];
//       //[attributedText setAttributes:subStrAttribute range:NSMakeRange(3, 2)];
//    LB_showSales.attributedText = attributedText;
//    LB_showSales.text=sellStr;
    
    LB_showSales.font = [UIFont systemFontOfSize:13];
    [whiteView addSubview:LB_showSales];
    
    //用户所选择商品的尺码和颜色
    LB_detail = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(headImage.frame)+20, CGRectGetMaxY(LB_stock.frame), 150, 20)];
    LB_detail.text = @"请选择 尺码 颜色分类";
    LB_detail.numberOfLines = 0;
    LB_detail.textColor = [UIColor blackColor];
    LB_detail.font = [UIFont systemFontOfSize:13];
    [whiteView addSubview:LB_detail];
    //分界线
    LB_line = [Utils lineWithFrame:CGRectMake(0, CGRectGetMaxY(headImage.frame)+10, SCREEN_WIDTH, 1)];
    [whiteView addSubview:LB_line];
    
    //加入购物车按钮
    addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    float btnH = 40;
    if (kTabBarHeight > 49) {
        btnH = 60;
    }
    addBtn.frame = CGRectMake(0, whiteView.WL_height-btnH, whiteView.frame.size.width/2, 40);
    
    [addBtn setBackgroundColor:[UIColor colorWithHex:0xff9701]];
    [addBtn setTitleColor:[UIColor whiteColor] forState:0];
    addBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [addBtn setTitle:@"加入购物车" forState:0];
    [whiteView addSubview:addBtn];
    
    //立即购买按钮
    buyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    buyBtn.frame = CGRectMake(whiteView.frame.size.width/2,  whiteView.WL_height-btnH, whiteView.frame.size.width/2, 40);
    [buyBtn setBackgroundColor:[UIColor colorWithHex:0xf67200]];
    [buyBtn setTitleColor:[UIColor whiteColor] forState:0];
    buyBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [buyBtn setTitle:@"立即购买" forState:0];
    [whiteView addSubview:buyBtn];
    
    //确定
    stockBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    stockBtn.frame = CGRectMake(0,  whiteView.WL_height-btnH, SCREEN_WIDTH, 40);
    [stockBtn setBackgroundColor:[UIColor colorWithHex:0xff9701]];
    [stockBtn setTitleColor:[UIColor whiteColor] forState:0];
    stockBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [stockBtn setTitle:@"确定" forState:0];
    [whiteView addSubview:stockBtn];
    //默认隐藏
    //stockBtn.hidden = YES;
    
    //有的商品尺码和颜色分类特别多 所以用UIScrollView 分类过多显示不全的时候可滑动查看
    mainscrollview = [[UIScrollView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(headImage.frame)+10, SCREEN_WIDTH, whiteView.WL_height-CGRectGetMaxY(headImage.frame)+10-60)];
    mainscrollview.backgroundColor = [UIColor clearColor];
    mainscrollview.contentSize = CGSizeMake(0, 200);
    mainscrollview.showsHorizontalScrollIndicator = NO;
    mainscrollview.showsVerticalScrollIndicator = NO;
    [whiteView addSubview:mainscrollview];
    
    redView = [[UIView alloc] init];
    [mainscrollview addSubview:redView];
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [redView addSubview:line];
    
    UILabel *buyNumLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"购买数量"];
    buyNumLabel.frame = CGRectMake(20, 5, kWidth(100), 48);
    [redView addSubview:buyNumLabel];
    
    UIView *pkgV = [[UIView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-(kWidth(160)), 10, kWidth(150), 38)];
    pkgV.layer.cornerRadius = 5;
    pkgV.layer.borderColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR].CGColor;
    pkgV.layer.borderWidth = 1;
    pkgV.layer.masksToBounds = YES;
    [redView addSubview:pkgV];
    
    UIButton *cutBtn = [UIButton addBtnImage:@"shopspec_btn_reduce_22_22" WithTarget:self action:@selector(Btnclick:)]; //74 76
    cutBtn.tag = 10010;
    cutBtn.frame = CGRectMake(0, 0, kWidth(38), 38);
    [pkgV addSubview:cutBtn];
    
    __weak typeof (self)weakSelf = self;
    numberLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"1"];
    numberLabel.textAlignment = NSTextAlignmentCenter;
    numberLabel.layer.borderColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR].CGColor;
    numberLabel.layer.borderWidth = 1;
    numberLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        [weakSelf showAlert];
    }];
    [numberLabel addGestureRecognizer:tap];
    numberLabel.frame = CGRectMake(kWidth(39), 0, kWidth(74), 38);
    [pkgV addSubview:numberLabel];
    
    
    UIButton *addBtn = [UIButton addBtnImage:@"shopspec_btn_add_22_22" WithTarget:self action:@selector(Btnclick:)];
    addBtn.tag = 10086;
    addBtn.frame = CGRectMake(kWidth(112), 0, kWidth(38), 38);
    [pkgV addSubview:addBtn];
    
    UILabel *line1 = [Utils lineWithFrame:CGRectMake(0, 59, SCREEN_WIDTH, 1)];
    [redView addSubview:line1];
}

-(void)showAlert{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"请输入数量" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    txtNum = [alert textFieldAtIndex:0];
    txtNum.keyboardType =  UIKeyboardTypeDecimalPad;
    txtNum.placeholder = @"请输入数量";
    [alert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) { //确认
       
        numberLabel.text = txtNum.text;
    }
}

-(void)Btnclick:(UIButton *)sender{
    
    self.number =[numberLabel.text intValue];

        if (sender.tag == 10086) {
            self.number +=1;
        }else if (sender.tag == 10010){
            self.number -=1;
        }
    if (self.number >0) {
        numberLabel.text = [NSString stringWithFormat:@"%ld",self.number];
    }else{
        [MBManager showError:@"数量不能小于1"];
    }
}


@end
