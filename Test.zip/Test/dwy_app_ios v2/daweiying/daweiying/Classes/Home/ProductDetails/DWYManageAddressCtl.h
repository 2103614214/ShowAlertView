//
//  DWYManageAddressCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"

@protocol sendAddressDelegate <NSObject>

-(void)sendMessage:(NSString *)Name withTel:(NSString *)tel WithAddress:(NSString *)adddress WithID:(int)addressID;

@end

@interface DWYManageAddressCtl : BaseViewController

@property (nonatomic,weak) id<sendAddressDelegate> delegate;

@end
