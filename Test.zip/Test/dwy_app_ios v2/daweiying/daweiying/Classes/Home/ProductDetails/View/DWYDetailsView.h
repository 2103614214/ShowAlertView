//
//  DWYDetailsView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/22.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SDCycleScrollView.h>
@protocol viewClickDelegate <NSObject>

// 头部view点击事件
- (void)headViewTapClick:(NSInteger)tag;

//点击轮播图
-(void)cycleScrollViewClick:(NSInteger)tag;

@end

@interface DWYDetailsView : UIView <SDCycleScrollViewDelegate>

/** 轮播图 */
@property(nonatomic,strong)SDCycleScrollView *cycleScrollView;


@property (nonatomic,weak) id<viewClickDelegate> delegate;

-(instancetype)initWithFrame:(CGRect)frame WithViewType:(int)type WithData:(id)data;
/** view类型 */
@property(nonatomic,assign)int viewType;
/** 数据源 */
@property(nonatomic,strong)id data;
/** 最小起批数 */
@property(nonatomic,assign)NSInteger minNumber;

@end
