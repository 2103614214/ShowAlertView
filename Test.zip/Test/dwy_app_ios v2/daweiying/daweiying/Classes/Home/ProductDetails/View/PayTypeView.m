//
//  PayTypeView.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/12.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "PayTypeView.h"

#import "IQKeyboardManager.h"

@implementation PayTypeView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        //初始化控件
        UILabel *title = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"请输入支付密码"];
        title.frame = CGRectMake(0, 0, SCREEN_WIDTH, kHeight(39));
        title.textAlignment = NSTextAlignmentCenter;
        [self addSubview:title];
        
        UIButton *closeBtn = [[UIButton alloc] init];
        [closeBtn setImage:[UIImage imageNamed:@"shop_btn_close_16_16"] forState:0];
         [closeBtn addTarget:self action:@selector(closeBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
        closeBtn.frame = CGRectMake(kWidth(15), kHeight(5), kWidth(35), kHeight(30));
        [self addSubview:closeBtn];
        
        UILabel *line = [Utils lineWithFrame:CGRectMake(0, kHeight(40), SCREEN_WIDTH, 1)];
        [self addSubview:line];
        
        self.inputView = [[WLPasswordView alloc] initWithFrame:CGRectMake(kWidth(30), kHeight(70), SCREEN_WIDTH-(kWidth(60)), kHeight(50))];
        [self addSubview:self.inputView];
        
        UIButton *forgetBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-(kWidth(120)), kHeight(130), kWidth(100), kHeight(30))];
        [forgetBtn setTitle:@"忘记密码?" forState:0];
        [forgetBtn addTarget:self action:@selector(forgetBtnClick) forControlEvents:(UIControlEventTouchUpInside)];
        forgetBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
        [forgetBtn setTitleColor:[UIColor orangeColor] forState:0];
        [self addSubview:forgetBtn];
    }
    return self;
}

-(void)forgetBtnClick{
    if (self.forgetBtnBlock) {
        self.forgetBtnBlock();
    }
}

-(void)closeBtnClick{
    if (self.closeBtnBlock) {
        self.closeBtnBlock();
    }
}

//移除view
- (void)willMoveToWindow:(UIWindow *)newWindow {
    if (newWindow == nil) {
        [IQKeyboardManager sharedManager].enableAutoToolbar = YES;
    }
}

//显示view
- (void)didMoveToWindow {
    if (self.window) {
        [IQKeyboardManager sharedManager].enableAutoToolbar = NO;
        [self.inputView.textField becomeFirstResponder];
        
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
