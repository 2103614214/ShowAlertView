//
//  DWYAffirmHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYAffirmHeadView.h"

@implementation DWYAffirmHeadView


-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        [self initWithSubViews]; //初始化
    }
    return self;
}



-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];
    
    UIImageView *lineV = [[UIImageView alloc] initWithFrame:CGRectMake(0, kHeight(10), SCREEN_WIDTH, kHeight(2))];
    [lineV setImage:[UIImage imageNamed:@"shoplist_img_address"]];
    [self addSubview:lineV];
    
    UIView *addressView = [UIView new];
    addressView.userInteractionEnabled = YES;
    addressView.backgroundColor = [UIColor whiteColor];
    [self addSubview:addressView];
    addressView.sd_layout
    .topSpaceToView(lineV, 0)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(69));
    self.addressView = addressView;
    //12 69 5 86
    UILabel *placeLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"请选择收货地址"];
    placeLabel.frame = CGRectMake(10, 0, 150, addressView.height);
    [addressView addSubview:placeLabel];
    self.placeLabel = placeLabel;
    
    UIImage *chooseAddressImg = [UIImage imageNamed:@"shopstore_btn_goto_13_13"];
    UIImageView *chooseAddrsssImageV = [[UIImageView alloc] initWithImage:chooseAddressImg];
    chooseAddrsssImageV.frame = CGRectMake(SCREEN_WIDTH-35, (addressView.height-18)/2, 18, 18);
    [addressView addSubview:chooseAddrsssImageV];
    
    float margeY = (addressView.height-42)/3;
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    nameLabel.frame = CGRectMake(10, margeY, 60, kHeight(21));
    [addressView addSubview:nameLabel];
    self.nameLabel = nameLabel;
    
    UILabel *telLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    telLabel.frame = CGRectMake(70, margeY, 150, kHeight(21));
    [addressView addSubview:telLabel];
    self.telLabel = telLabel;
    
    UILabel *addressLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    [addressView addSubview:addressLabel];
    addressLabel.sd_layout
    .topSpaceToView(nameLabel, margeY)
    .xIs(10)
    .widthIs(SCREEN_WIDTH-20)
    .heightIs(kHeight(25));
    self.addressLabel = addressLabel;
    
//    UIView *payTypeView = [UIView new];
//    payTypeView.backgroundColor = [UIColor whiteColor];
//    payTypeView.userInteractionEnabled = YES;
//    [self addSubview:payTypeView];
//    payTypeView.sd_layout
//    .topSpaceToView(addressView, 5)
//    .xIs(0)
//    .widthIs(SCREEN_WIDTH)
//    .heightIs(viweW);
//    self.payTypeView = payTypeView;
    
//    UILabel *pay = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"支付方式"];
//    pay.frame = CGRectMake(10, (payTypeView.height-20)/2, 80, 20);
//    [payTypeView addSubview:pay];
//
//    UIImage *moreImg = [UIImage imageNamed:@"shopstore_btn_goto_13_13"];
//    UIImageView *moreImageV = [[UIImageView alloc] initWithImage:moreImg];
//    moreImageV.frame = CGRectMake(SCREEN_WIDTH-35, (payTypeView.height-18)/2, 18, 18);
//    [payTypeView addSubview:moreImageV];
//
//    UILabel *payLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"微信支付"];
//    payLabel.adjustsFontSizeToFitWidth = YES;
//    payLabel.textAlignment = NSTextAlignmentRight;
//    payLabel.frame = CGRectMake(CGRectGetMaxX(pay.frame), (payTypeView.height-20)/2, SCREEN_WIDTH-pay.width-moreImageV.width-50, 20);
//    [payTypeView addSubview:payLabel];
//    self.payLabel = payLabel;

    
//    UIView *storeView = [UIView new];
//    storeView.backgroundColor = [UIColor whiteColor];
//    [self addSubview:storeView];
//    storeView.sd_layout
//    .topSpaceToView(addressView, kHeight(5))
//    .xIs(0)
//    .widthIs(SCREEN_WIDTH)
//    .heightIs(kHeight(30));
//
//    UIImageView *storeLogoV = [[UIImageView alloc] initWithFrame:CGRectMake(10, (storeView.height-25)/2, 25, 25)];
//    [storeLogoV setImage:[UIImage imageNamed:@"shoplist_icon_store_22_22"]];
//    [storeView addSubview:storeLogoV];
//    _storeLogoV = storeLogoV;
//
//    UILabel *storeName = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"明兴乳业"];
//    storeName.frame = CGRectMake(45, (storeView.height-20)/2, 150, kHeight(20));
//    [storeView addSubview:storeName];
//    _storeName = storeName;
    

//    [ud setObject:phoneStr forKey:@"add_Phone"];
//    [ud setObject:nameStr forKey:@"add_Name"];
    NSString *provinceStr= [appDelegate.appDefault objectForKey:@"province"];
    NSString *addressStr = [appDelegate.appDefault objectForKey:@"address_name"];
    NSString *cityStr = [appDelegate.appDefault objectForKey:@"city"];
    NSString *areaStr = [appDelegate.appDefault objectForKey:@"area"];
    NSString *nameStr= [appDelegate.appDefault objectForKey:@"add_Name"];
    NSString *telStr= [appDelegate.appDefault objectForKey:@"add_Phone"];
    
    if (![Utils isBlankString:nameStr] && ![Utils isBlankString:telStr]) {
        self.addressLabel.text = [NSString stringWithFormat:@" %@%@%@%@",provinceStr,cityStr,areaStr,addressStr];
        self.nameLabel.text = nameStr;
        self.telLabel.text = telStr;
        self.placeLabel.hidden = YES;
    }

    
    
}

//-(void)setStoreNameStr:(NSString *)storeNameStr{
//    _storeNameStr = storeNameStr;
//    _storeName.text = storeNameStr;
//}
//
//-(void)setLogo_urlStr:(NSString *)logo_urlStr{
//    _logo_urlStr = logo_urlStr;
//    [_storeLogoV sd_setImageWithURL:[NSURL URLWithString:logo_urlStr] placeholderImage:[UIImage imageNamed:placeImageName]];
//}


@end

#pragma mark  ------- footView底部
@implementation DWYAffirmFootView
{
    UIButton *_inputBtn;
    UITextField *txtNum;;
}


//-(instancetype)initWithFrame:(CGRect)frame{
//    if (self = [super initWithFrame:frame]) {
//       // self.type = type;
//        [self initWithSubViews];
//    }
//    return self;
//}

-(instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        [self initWithSubViews];
    }
    return self;
}

// 50 80 5 60 = 195   245
-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];
    
    // float viweW = (self.height-5)/3;
    

//    float messageH = 0;
//    if (self.type == 1) { //直接购买
//        messageH = kHeight(180);
//    }else{ //购物车
//        messageH = kHeight(130);
//    }
    UIView *messageView = [UIView new];
    messageView.backgroundColor = [UIColor whiteColor];
    messageView.frame = CGRectMake(0, 0, SCREEN_WIDTH, kHeight(130));
    [self addSubview:messageView];
    
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [messageView addSubview:line];
    
    float y = 1;

    UIView *distributionTypeView = [[UIView alloc] initWithFrame:CGRectMake(0, y, SCREEN_WIDTH, kHeight(50))];
    [messageView addSubview:distributionTypeView];
    self.distributionTypeView = distributionTypeView;
    y += distributionTypeView.height;
    
    UILabel *distributionTypeLb = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"配送方式"];
    distributionTypeLb.frame = CGRectMake(10, 1, 100, kHeight(50));
    [distributionTypeView addSubview:distributionTypeLb];
    
    UIButton *inputBtn = [[UIButton alloc] init];
    [inputBtn setTitle:@"输入邮费" forState:0];
    [inputBtn setTitleColor:[UIColor colorWithHex:UI_COLOR_ORANGE] forState:0];
    inputBtn.titleLabel.font = [UIFont systemFontOfSize:13];
    [inputBtn addTarget:self action:@selector(showAlert) forControlEvents:UIControlEventTouchUpInside];
    [distributionTypeView addSubview:inputBtn];
    inputBtn.sd_layout
    .yIs(1)
    .xIs(SCREEN_WIDTH-(kWidth(90)))
    .widthIs(kWidth(80))
    .heightIs(distributionTypeLb.height);
    _inputBtn = inputBtn;

    
    UILabel *sendLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"快递"];
    sendLabel.textAlignment = NSTextAlignmentRight;
    //sendLabel.frame = CGRectMake(SCREEN_WIDTH-140, (distributionTypeView.height-20)/2, 100, 20);
    [distributionTypeView addSubview:sendLabel];
    self.sendLabel = sendLabel;
    sendLabel.sd_layout
    .rightSpaceToView(inputBtn, 5)
    .centerYEqualToView(inputBtn)
    .widthIs(kWidth(80))
    .heightIs(inputBtn.height);

    
    UILabel *line1 = [Utils lineWithFrame:CGRectMake(0, y, SCREEN_WIDTH, 1)];
    [messageView addSubview:line1];
    
    UILabel *messageLb = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"买家留言:"];
//    messageLb.frame = CGRectMake(10, kHeight(53), kWidth(120), kHeight(30));
    [messageView addSubview:messageLb];
    messageLb.sd_layout
    .topSpaceToView(line1, 0)
    .xIs(10)
    .widthIs(kWidth(120))
    .heightIs(kHeight(30));
    
    __weak typeof (self)weakSelf = self;
    UITextField *messageText = [[UITextField alloc] init];
    messageText.placeholder = @"给卖家留言，告诉您的需求";
    messageText.font = [UIFont systemFontOfSize:14.0f];
    //messageText.delegate = self;
    [[messageText rac_textSignal] subscribeNext:^(id x) {
        if (weakSelf.jumpType == 1) {
              weakSelf.model.words = [NSString stringWithFormat:@"%@",x];
        }else if (weakSelf.jumpType == 2){
              weakSelf.goodsModel.words = [NSString stringWithFormat:@"%@",x];
        }
      
    }];
    [messageView addSubview:messageText];
    messageText.sd_layout
    .topSpaceToView(messageLb, 0)
    .xIs(10)
    .widthIs(SCREEN_WIDTH-20)
    .heightIs(kHeight(50));
    self.messageText = messageText;
    
    UIView *priceTypeView = [UIView new];
    priceTypeView.backgroundColor = [UIColor whiteColor];
    [self addSubview:priceTypeView];
    priceTypeView.sd_layout
    .topSpaceToView(messageView, kHeight(5))
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(kHeight(60)));
    
    
    UILabel *pro_priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"商品总价(含运费)"];
    pro_priceLabel.frame = CGRectMake(10, 0, 200, priceTypeView.height/2);
    [priceTypeView addSubview:pro_priceLabel];
    
    UILabel *p_priceLabel = [Utils labelTextColor:[UIColor orangeColor] fontSize:14 numberOfLines:1 text:@""];
    p_priceLabel.textAlignment = NSTextAlignmentRight;
    p_priceLabel.frame = CGRectMake(SCREEN_WIDTH-110, 0, 100, priceTypeView.height/2);
    [priceTypeView addSubview:p_priceLabel];
    self.p_priceLabel = p_priceLabel;
    
    UILabel *tr_priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"运费"];
    tr_priceLabel.textAlignment = NSTextAlignmentLeft;
    tr_priceLabel.frame = CGRectMake(10, pro_priceLabel.height, 100, 25);
    [priceTypeView addSubview:tr_priceLabel];
    
    UILabel *t_priceLabel = [Utils labelTextColor:[UIColor orangeColor] fontSize:14 numberOfLines:1 text:@""];
    t_priceLabel.textAlignment = NSTextAlignmentRight;
    t_priceLabel.frame = CGRectMake(SCREEN_WIDTH-110, pro_priceLabel.height, 100, 25);
    [priceTypeView addSubview:t_priceLabel];
    self.t_priceLabel = t_priceLabel;
    
}


-(void)showAlert{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"请输入邮费" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    txtNum = [alert textFieldAtIndex:0];
    txtNum.keyboardType =  UIKeyboardTypeDecimalPad;
    txtNum.placeholder = @"请输入邮费";
    [alert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) { //确认
        [_inputBtn setTitle:txtNum.text forState:0];
        if (self.countTotalPriceBlock) {
            
//            if (self.jumpType == 1) { //购物车
//                float price = [txtNum.text floatValue];
//                float oldePrice = [self.model.store_total floatValue];
//                float newPrice = oldePrice + price - [self.model.store_freight floatValue];
//                self.model.store_total = [NSString stringWithFormat:@"%.2f",newPrice];
//            }else if (self.jumpType == 2){
//                float price = [txtNum.text floatValue];
//                float oldePrice = [self.goodsModel.total_money floatValue];
//                //float newPrice = oldePrice + price - [self.goodsModel.freight floatValue];
//                //self.goodsModel.total_money = [NSString stringWithFormat:@"%.2f",newPrice];
//            }
   
     
            self.countTotalPriceBlock([txtNum.text floatValue]);
        }
    }
}

-(void)setModel:(DWYAffirmCartModel *)model{
    _model = model;
    if (model.freight_status == 1) {
        _inputBtn.hidden = NO;
        self.sendLabel.text = @"快递";
    }else{
        _inputBtn.hidden = YES;
        self.sendLabel.text = @"快递";
    }

    if ([model.store_freight floatValue] > 0) {
        NSString *str = [NSString stringWithFormat:@"%@",model.store_freight];
        [_inputBtn setTitle:str forState:0];
    }
    self.p_priceLabel.text = [NSString stringWithFormat:@"¥%@",model.store_total];
    self.t_priceLabel.text = [NSString stringWithFormat:@"¥%@",model.store_freight];
}

-(void)setGoodsModel:(DWYAffirmModel *)goodsModel{
    _goodsModel = goodsModel;
    
    if (goodsModel.freight_status == 1) {
        _inputBtn.hidden = NO;
        self.sendLabel.text = @"快递";
    }else{
        _inputBtn.hidden = YES;
        self.sendLabel.text = @"快递";
        self.sendLabel.mj_x = SCREEN_WIDTH-140;
    }
    
    //NSLog(@"----%@",self.model.words);
    if ([goodsModel.freight floatValue] > 0) {
        [_inputBtn setTitle:goodsModel.freight forState:0];
    }
    self.p_priceLabel.text = [NSString stringWithFormat:@"¥%@",goodsModel.total_money];
    self.t_priceLabel.text = [NSString stringWithFormat:@"¥%@",goodsModel.freight];
    
}
//-(void)setSendType:(int)sendType{
//    _sendType = sendType;
//    if (sendType != 3) {
//        _inputBtn.hidden = YES;
//        self.sendLabel.mj_x = SCREEN_WIDTH-140;
//    }
//}
//
//-(void)setSendTypeCart:(int)sendTypeCart{
//    _sendTypeCart = sendTypeCart;
//    if (sendTypeCart == 0) {
//        _inputBtn.hidden = YES;
//        self.sendLabel.mj_x = SCREEN_WIDTH-140;
//    }
//}


//#pragma mark - UITextFieldDelegate
//- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
//
//    NSLog(@"----%@",textField.text);
//    //不能一来就输入0
//    if (textField.text.length == 0 && [string isEqualToString:@"0"]) {
//
//        return NO;
//    }
//
//    if (textField.text.length > 7 ) {
//        if ([string isEqualToString:@""]) {
//            return YES;
//        }
//        return NO;
//    }
//    return YES;
//}

@end
