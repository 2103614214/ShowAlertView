//
//  DWYDetailsViewCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/22.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"
#import "BaseScrollViewController.h"
#import "WLSelectAttributes.h"
#import "WLSelectView.h"

typedef NS_ENUM(int, loginStoreType) {
    isStore,
    isHome,
};

@interface DWYDetailsViewCtl : BaseScrollViewController

/** 商品id */
@property(nonatomic,assign)int productID;
/** 进店类型 */
@property(nonatomic,assign)loginStoreType type;


@end
