//
//  AttributeViewSelected.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/19.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttributeViewSelected : UIView <UITableViewDelegate,UITableViewDataSource>


@property (nonatomic,strong) NSArray *objects;

@property(nonatomic,strong)NSDictionary *dict;

@property (nonatomic,strong) UITableView *tableView;

/**  判断 加入购物车还是直接购买 */
@property(nonatomic,assign)int isShoppingCar;


-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSArray *)objects isPayType:(int)isPayType WithDict:(NSDictionary *)dict;

@property (nonatomic,copy) void (^closeView)();

@property(nonatomic,strong)UIButton *buyBtn; 
@property(nonatomic,strong)UIButton *stockBtn;
@property(nonatomic,strong)UIButton *addBtn;

@property(nonatomic,assign)float totalPrice;
@property(nonatomic,assign)NSInteger totalNumber;
@end
