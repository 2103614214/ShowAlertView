//
//  ConfirmPayView.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "ConfirmPayView.h"
#import "ConfirmPayCell.h"

static NSString * const ConfirmPayViewId = @"ConfirmPayViewId";
@implementation ConfirmPayView

-(instancetype)initWithFrame:(CGRect)frame WithStr:(NSString *)str WithPrice:(NSString *)price{
    self = [super initWithFrame:frame];
    
    if (self) {
//        id fjStatus = [appDelegate.appDefault objectForKey:@"fjyf_status"];
//        if ([fjStatus intValue] == 1) {
//            self.objects = [NSArray arrayWithObjects:@"付甲一方",@"钱包余额",@"微信支付", nil];
//           self.imageArr = [NSArray arrayWithObjects:@"pay_btn_pay",@"pay_btn_wallet",@"pay_btn_wechat", nil];
//        }else{
//            self.objects = [NSArray arrayWithObjects:@"钱包余额",@"微信支付", nil];
//            self.imageArr = [NSArray arrayWithObjects:@"pay_btn_wallet",@"pay_btn_wechat", nil];
//        }
        self.objects = [NSArray arrayWithObjects:@"钱包余额",@"微信支付", nil];
        self.imageArr = [NSArray arrayWithObjects:@"pay_btn_wallet",@"pay_btn_wechat", nil];
   
        self.selectedStr = str;
   
        self.totalPrice = price;
        [self initWithSubViews];
    }
    return self;
}


-(void)initWithSubViews{
    
    self.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.7];
    self.tableView = [[UITableView alloc] initWithFrame:self.bounds];
    self.tableView.bounces = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[ConfirmPayCell class] forCellReuseIdentifier:ConfirmPayViewId];
}

#pragma mark - TableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.objects count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return kHeight(50);
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ConfirmPayCell *cell = [tableView dequeueReusableCellWithIdentifier:ConfirmPayViewId forIndexPath:indexPath];
    if (!cell) {
        cell = [[ConfirmPayCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ConfirmPayViewId];
    }
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    if ([self.objects[indexPath.row] isEqualToString:self.selectedStr]) {
        [cell.selectedV setImage:[UIImage imageNamed:@"color_choose"]];
    }else{
        [cell.selectedV setImage:[UIImage imageNamed:@"color_no_choose"]];
    }
    cell.nameLabel.text = self.objects[indexPath.row];
    cell.logoV.image = [UIImage imageNamed:self.imageArr[indexPath.row]];

  
    return cell;
    
}

#define SECTION_HEIGHT kHeight(130.0)
// 设置section的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    
    return SECTION_HEIGHT;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return kHeight(100);
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SECTION_HEIGHT)];
    UILabel *chooseLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"确认付款"];
    chooseLabel.textAlignment = NSTextAlignmentCenter;
    chooseLabel.frame = CGRectMake((SCREEN_WIDTH-(kWidth(200)))/2, kHeight(15), kWidth(200), 21);
    [view addSubview:chooseLabel];
    
    UIButton *closeBtn = [UIButton addBtnImage:@"shop_btn_close_16_16" WithTarget:self action:@selector(closeBtnClick)];
    closeBtn.frame = CGRectMake(kWidth(15), kHeight(10), kHeight(30), kHeight(30));
    [view addSubview:closeBtn];
    
    NSString *price = [NSString stringWithFormat:@"¥ %@",self.totalPrice];
    UILabel *priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:25 numberOfLines:1 text:price];
    [priceLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:25]];
    priceLabel.textAlignment = NSTextAlignmentCenter;
    priceLabel.frame = CGRectMake(0, kHeight(50), SCREEN_WIDTH, kHeight(80));
    [view addSubview:priceLabel];
    
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, kHeight(50), SCREEN_WIDTH, 1)];
    [view addSubview:line];
    
    UILabel *line1 = [Utils lineWithFrame:CGRectMake(0, SECTION_HEIGHT-1, SCREEN_WIDTH, 1)];
    [view addSubview:line1];
    
    view.backgroundColor = [UIColor whiteColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(100))];
    view.backgroundColor = [UIColor whiteColor];
    UILabel *line = [Utils lineWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1)];
    [view addSubview:line];
    
    
    UIButton *payBtn = [[UIButton alloc] initWithFrame:CGRectMake(kWidth(15), kHeight(25), SCREEN_WIDTH-(kWidth(30)), kHeight(50))];
    payBtn.backgroundColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
    [payBtn setTitle:@"立即支付" forState:0];
    [payBtn addTarget:self action:@selector(payBlockClick) forControlEvents:(UIControlEventTouchUpInside)];
    payBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    [view addSubview:payBtn];
    
    
    return view;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
 
    ConfirmPayCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    self.selectedStr = cell.nameLabel.text;
    [self dismissContactView];
}

-(void)closeBtnClick{
    self.closeView();
}

-(void)payBlockClick{
    
    if (self.payBlock) {
       self.payBlock(self.selectedStr);
    }
    
}

-(void)dismissContactView{
    
    [self.tableView reloadData];
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
