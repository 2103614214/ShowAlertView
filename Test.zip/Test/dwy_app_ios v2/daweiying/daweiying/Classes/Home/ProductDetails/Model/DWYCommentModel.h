//
//  DWYCommentModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DWYCommentModel : NSObject

/** 评价 */
@property(nonatomic,copy)NSString *c_content;
/** 用户名 */
@property(nonatomic,copy)NSString *username;
/** 用户logo  */
@property(nonatomic,copy)NSString *user_logo;
/** 商品属性 */
@property(nonatomic,copy)NSString *pro_attr;
/** 评星级 */
@property(nonatomic,assign)int grade;
/** 用户id */
@property(nonatomic,assign)int u_id;
/** 时间 */
@property(nonatomic,copy)NSString *c_time;

/** 评论图片数组 */
@property(nonatomic,strong)NSArray *img_json;

/** cell的高度 */
@property (nonatomic, assign, readonly) CGFloat cellHeight;

@end
