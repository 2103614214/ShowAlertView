//
//  ConfirmPayCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/12/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "ConfirmPayCell.h"

@implementation ConfirmPayCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        //初始化控件
        UIImageView *logoV = [[UIImageView alloc] initWithFrame:CGRectMake(kWidth(15), (self.height-30)/2, kHeight(30), kHeight(30))];
        [self.contentView addSubview:logoV];
        self.logoV = logoV;
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@""];
        nameLabel.adjustsFontSizeToFitWidth = YES;
        nameLabel.frame = CGRectMake(kWidth(30)+logoV.width, (self.height-(kHeight(20)))/2, kWidth(200), kHeight(20));
        [self.contentView addSubview:nameLabel];
        self.nameLabel = nameLabel;
        
        UIImageView *selectedV = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-35, (self.height-(kHeight(20)))/2, kHeight(20), kHeight(20))];
        [selectedV setImage:[UIImage imageNamed:@"color_no_choose"]];
        [self.contentView addSubview:selectedV];
        self.selectedV = selectedV;
        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
