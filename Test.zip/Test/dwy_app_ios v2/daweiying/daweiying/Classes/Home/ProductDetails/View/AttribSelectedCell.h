//
//  AttribSelectedCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/19.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ProductAttrModel;

@interface AttribSelectedCell : UITableViewCell <UITextFieldDelegate>

@property(nonatomic,strong)UILabel *numberLabel;

@property (nonatomic,assign) NSInteger number;
/** 库存 */
@property(nonatomic,assign)UILabel *NumLabel;
//属性
@property(nonatomic,assign)UILabel *nameLabel;
/** 模型 */
@property(nonatomic,strong)ProductAttrModel *model;

/** 数量block */
@property(nonatomic,copy) void (^numberClickBlock)();

@end
