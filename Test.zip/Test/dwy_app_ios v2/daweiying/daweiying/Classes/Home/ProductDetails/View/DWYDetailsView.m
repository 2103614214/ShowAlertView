//
//  DWYDetailsView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/22.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYDetailsView.h"
#import "RatingView.h"


@implementation DWYDetailsView
{
    UILabel *_productName;
    UILabel *_price;
    UILabel *_freightLabel;
    UILabel *_serveLabel;
    UILabel *_colorLabel;   //属性
    UILabel *_commentLabel; //好评数量
    UILabel *_reviewLabel; //好评率
    UILabel *_nameLabel; //用户名
    UILabel *_contentLabel; //评论内容
    UILabel *_contentTime; //评论时间
    UILabel *_attrLabel;  //属性
    UIImageView *_storeLogoV; //商铺logo
    UILabel *_storeLabel;  //商户名
    UILabel *_remarkLabel;  //主营
    
}

-(instancetype)initWithFrame:(CGRect)frame WithViewType:(int)type WithData:(id)data{
    if (self == [super initWithFrame:frame]) {
        self.viewType = type;   //1为日常零售   2为企业制造
        self.data = data;
        [self initWithSubViews]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews{
    self.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    
//    UIImageView *headImg = [[UIImageView alloc] init];
//    headImg.frame = CGRectMake(0, 0, SCREEN_WIDTH, self.height*0.38);
//    [self addSubview:headImg];
//    _headImg = headImg;
    
    //设置轮播图
    self.cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kHeight(370)) delegate:self placeholderImage:[UIImage imageNamed:@""]];
    self.cycleScrollView.imageURLStringsGroup = [[self.data objectForKey:@"product"] objectForKey:@"img_url"];
    self.cycleScrollView.autoScrollTimeInterval = 3.0;
    _cycleScrollView.currentPageDotColor = [UIColor redColor];
    _cycleScrollView.pageDotColor = [UIColor grayColor];
    _cycleScrollView.pageControlDotSize = CGSizeMake(8, 8);
    // 不设置标题
    self.cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleClassic;
    self.cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    self.cycleScrollView.bannerImageViewContentMode = UIViewContentModeScaleToFill;
    [self addSubview:self.cycleScrollView];
    
    float marge = kHeight(5);
    float detailsViewH = 0;
    float lineY = 0;
    if (self.viewType == 1) {
        detailsViewH = kHeight(190);
        lineY = kHeight(110);
    }else if (self.viewType == 2){
        detailsViewH = kHeight(210);
        lineY = kHeight(130);
    }
    //商品简介
    UIView *detailsView = [UIView new];
    detailsView.backgroundColor = [UIColor whiteColor];
    [self addSubview:detailsView];
    detailsView.sd_layout
    .topSpaceToView(_cycleScrollView, 0)
    .leftEqualToView(_cycleScrollView)
    .widthIs(SCREEN_WIDTH)
    .heightIs(detailsViewH);
    
    UILabel *productName = [UILabel new];
    productName.frame = CGRectMake(10, 0, self.width-20, kHeight(40));
    productName.font = [UIFont systemFontOfSize:15];
    productName.numberOfLines = 2;
    productName.adjustsFontSizeToFitWidth = YES;
    [detailsView addSubview:productName];
    _productName = productName;
    
    if (self.viewType == 1) { //日常零售
        UILabel *price = [Utils labelTextColor:[UIColor colorWithHex:0xf67100] fontSize:15 numberOfLines:1 text:@""];
        [detailsView addSubview:price];
        price.sd_layout
        .topSpaceToView(productName, 0)
        .leftEqualToView(productName)
        .widthIs(100)
        .heightIs(kHeight(20));
        _price = price;
        
        NSArray *serverArr = [self getSendType];
        float serverX = 0;
        for (int i = 0; i<serverArr.count; i++) {
            UILabel *labe12 = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:@""];
            labe12.frame = CGRectMake(serverX, kHeight(65), SCREEN_WIDTH/3, kHeight(25));
            labe12.textAlignment = NSTextAlignmentCenter;
            labe12.text = serverArr[i];
            [detailsView addSubview:labe12];
            serverX += labe12.width;
        }
        
    }else if (self.viewType == 2){ //企业制造
        float labelW = SCREEN_WIDTH/3;
        float x = 0;
        NSArray *array = [[self.data objectForKey:@"product"] objectForKey:@"prices"];
   
        NSMutableArray *priceArray = [NSMutableArray array];
        for (int j = 0; j < array.count; j++) {
            NSDictionary *dict = array[j];
            [priceArray addObject:dict[@"s_number"]];
        }
        NSInteger maxValue = [[priceArray valueForKeyPath:@"@max.integerValue"] integerValue];
           
        for (int i = 0; i<array.count; i++) {
            NSDictionary *dict = array[i];
            NSString *str1;
            NSMutableAttributedString *aString; 
           
            if (i == 0) {
                NSString *str = [NSString stringWithFormat:@"¥ %@",dict[@"price"]];
                aString = [[NSMutableAttributedString alloc]initWithString:str];
                [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(12.0)]range:NSMakeRange(0, 1)];
                str1 = [NSString stringWithFormat:@"%@件起批",dict[@"s_number"]];
                self.minNumber = [dict[@"s_number"] integerValue]; //最小起批数

      
            }else if (i == 1){
                NSString *str = [NSString stringWithFormat:@"¥ %@",dict[@"price"]];
                aString = [[NSMutableAttributedString alloc]initWithString:str];
                [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(12.0)]range:NSMakeRange(0, 1)];
                if (array.count > 2) {
                    NSInteger number = maxValue - 1;
                    str1 = [NSString stringWithFormat:@"%@-%ld件",dict[@"s_number"],(long)number];
                }else{
                    str1 = [NSString stringWithFormat:@"≥%@件",dict[@"s_number"]];
                }
                
            }else if (i == 2){
                NSString *str = [NSString stringWithFormat:@"¥ %@",dict[@"price"]];
                aString = [[NSMutableAttributedString alloc]initWithString:str];
                [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(12.0)]range:NSMakeRange(0, 1)];
                
                str1 = [NSString stringWithFormat:@"≥%@件",dict[@"s_number"]];
            }
            
         
          
            UILabel *labe1 = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:20 numberOfLines:1 text:@""];
            labe1.frame = CGRectMake(x, kHeight(50), labelW, kHeight(25));
            labe1.textAlignment = NSTextAlignmentCenter;
            labe1.attributedText= aString;
            [detailsView addSubview:labe1];
            
            
            UILabel *labe11 = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:str1];
            labe11.frame = CGRectMake(x, kHeight(75), labelW, kHeight(15));
            labe11.textAlignment = NSTextAlignmentCenter;
            [detailsView addSubview:labe11];
                        
            x += labelW;
            
        }
        

        
        NSArray *serverArr = [self getSendType];
        float serverX = 0;
        for (int i = 0; i<serverArr.count; i++) {
            UILabel *labe12 = [Utils labelTextColor:[UIColor grayColor] fontSize:12 numberOfLines:1 text:@""];
            labe12.frame = CGRectMake(serverX, kHeight(105), labelW, kHeight(15));
            labe12.textAlignment = NSTextAlignmentCenter;
            labe12.text = serverArr[i];
            [detailsView addSubview:labe12];
            serverX += labelW;
        }
    }

    
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [detailsView addSubview:line];
    line.sd_layout
    .yIs(lineY)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    UILabel *freight = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@"运费:"];
    [detailsView addSubview:freight];
    freight.sd_layout
    .topSpaceToView(line, 0)
    .xIs(10)
    .widthIs(50)
    .heightIs(kHeight(40));
    
    UILabel *freightLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
    [detailsView addSubview:freightLabel];
    freightLabel.sd_layout
    .topSpaceToView(line, 0)
    .leftSpaceToView(freight, 5)
    .widthIs(150)
    .heightIs(freight.height);
    _freightLabel = freightLabel;
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    [detailsView addSubview:line1];
    line1.sd_layout
    .topSpaceToView(freight, 0)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(1);
    
    UILabel *serve = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@"服务"];
    [detailsView addSubview:serve];
    serve.sd_layout
    .topSpaceToView(line1, 0)
    .xIs(10)
    .widthIs(50)
    .heightIs(productName.height-1);
    
    UILabel *serveLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:13 numberOfLines:1 text:@""];
    [detailsView addSubview:serveLabel];
    serveLabel.sd_layout
    .topSpaceToView(line1, 0)
    .leftSpaceToView(serve, 5)
    .widthIs(150)
    .heightIs(serve.height);
    _serveLabel = serveLabel;
    
    __weak typeof (self)weakSelf = self;
    //商品属性
//    UIView *attributeView = [UIView new];
//    attributeView.backgroundColor = [UIColor whiteColor];
//    attributeView.userInteractionEnabled = YES;
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
//    [[tap rac_gestureSignal] subscribeNext:^(id x) {
//
//    if (self.delegate && [self.delegate respondsToSelector:@selector(headViewTapClick:)]) {
//            [weakSelf.delegate headViewTapClick:100];
//        }
//    }];
//    [attributeView addGestureRecognizer:tap];
//    [self addSubview:attributeView];
//    attributeView.sd_layout
//    .topSpaceToView(detailsView, marge)
//    .leftEqualToView(_cycleScrollView)
//    .widthIs(SCREEN_WIDTH)
//    .heightIs(kHeight(60));
//
//    UIImage *img = [UIImage imageNamed:@"shopdt_icon_spec_35_35"];
//    UIImageView *imageLogo = [[UIImageView alloc] initWithImage:img];
//    [attributeView addSubview:imageLogo];
//    imageLogo.sd_layout
//    .xIs(20)
//    .yIs(5)
//    .heightIs(attributeView.height/2)
//    .widthIs(attributeView.height/2);
//
//    UILabel *chooseLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@"规格选择"];
//    chooseLabel.adjustsFontSizeToFitWidth = YES;
//    [attributeView addSubview:chooseLabel];
//    chooseLabel.sd_layout
//    .topSpaceToView(imageLogo, 2)
//    .xIs(10)
//    .widthIs(imageLogo.width*2)
//    .heightIs(21);

    
//    UILabel *line2 = [UILabel new];
//    line2.backgroundColor = [UIColor colorWithHex:0xd9d9d9];
//    [attributeView addSubview:line2];
//    line2.sd_layout
//    .yIs(5)
//    .leftSpaceToView(chooseLabel, 10)
//    .widthIs(1)
//    .heightIs(attributeView.height-10);
//
//    UILabel *colorLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
//    [attributeView addSubview:colorLabel];
//    colorLabel.sd_layout
//    .yIs((attributeView.height-21)/2)
//    .leftSpaceToView(line2, 20)
//    .widthIs(150)
//    .heightIs(21);
//    _colorLabel = colorLabel;
    
//    UIImage *pullImg = [UIImage imageNamed:@"homepage_btn_bottom2_13_9"];
//    UIImageView *pullImageV = [[UIImageView alloc] initWithImage:pullImg];
//    [attributeView addSubview:pullImageV];
//    pullImageV.sd_layout
//    .centerYEqualToView(colorLabel)
//    .xIs(SCREEN_WIDTH-35)
//    .heightIs(18)
//    .widthIs(18);
    
    float y = CGRectGetMaxY(detailsView.frame)+self.cycleScrollView.height;
    id commentId = [[self.data objectForKey:@"comment"] objectForKey:@"total"];
    if ([commentId intValue] > 0) { //有评论
        //评论
        UIView *commentView = [UIView new];
        commentView.backgroundColor = [UIColor whiteColor];
        commentView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
        [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
            if (self.delegate && [self.delegate respondsToSelector:@selector(headViewTapClick:)]) {
                [weakSelf.delegate headViewTapClick:101];
            }
        }];
        [commentView addGestureRecognizer:tap1];
        [self addSubview:commentView];
        commentView.sd_layout
        .topSpaceToView(detailsView, marge)
        .leftEqualToView(_cycleScrollView)
        .widthIs(SCREEN_WIDTH)
        .heightIs(kHeight(100));
        
        UILabel *commentLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"买家评论 (2)"];
        [commentView addSubview:commentLabel];
        commentLabel.sd_layout
        .xIs(10)
        .yIs(0)
        .widthIs(150)
        .heightIs(commentView.height/3-1);
        _commentLabel = commentLabel;
        
        UILabel *line3 = [UILabel new];
        line3.backgroundColor = [UIColor colorWithHex:0xd9d9d9];
        [commentView addSubview:line3];
        line3.sd_layout
        .topSpaceToView(commentLabel, 0)
        .xIs(0)
        .widthIs(SCREEN_WIDTH)
        .heightIs(1);
        
        UIImage *moreImg = [UIImage imageNamed:@"shopstore_btn_goto_13_13"];
        UIImageView *moreImageV = [[UIImageView alloc] initWithImage:moreImg];
        [commentView addSubview:moreImageV];
        moreImageV.sd_layout
        .centerYEqualToView(commentLabel)
        .xIs(SCREEN_WIDTH-35)
        .heightIs(18)
        .widthIs(18);
        
        //review
        UILabel *reviewLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:14 numberOfLines:1 text:@"好评率 100%"];
        reviewLabel.textAlignment = NSTextAlignmentRight;
        [commentView addSubview:reviewLabel];
        reviewLabel.sd_layout
        .xIs(commentView.width-150-35)
        .yIs(0)
        .widthIs(150)
        .heightIs(commentView.height/3-1);
        _reviewLabel = reviewLabel;
        
        RatingView * rView = [[RatingView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(commentLabel.frame), 90, (commentView.height-reviewLabel.height)*0.4)  isEdit:NO];
        rView.score = 5;
        rView.ratingType = INTEGER_TYPE;//整颗星
        [commentView addSubview:rView];
        
        UILabel *nameLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@"用户名"];
        nameLabel.frame = CGRectMake(SCREEN_WIDTH-(kWidth(180)), CGRectGetMaxY(commentLabel.frame), kWidth(170), rView.height);
        nameLabel.textAlignment = NSTextAlignmentRight;
        [commentView addSubview:nameLabel];
        _nameLabel = nameLabel;
        
        
        UILabel *contentLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@"默认好评"];
        [commentView addSubview:contentLabel];
        contentLabel.sd_layout
        .topSpaceToView(rView, 0)
        .xIs(10)
        .widthIs(SCREEN_WIDTH-20)
        .heightIs((commentView.height-reviewLabel.height)*0.3);
        _contentLabel = contentLabel;
        
        UILabel *contentTime = [Utils labelTextColor:[UIColor grayColor] fontSize:11 numberOfLines:1 text:@"2017年9月5日"];
        [commentView addSubview:contentTime];
        contentTime.sd_layout
        .topSpaceToView(contentLabel, 0)
        .xIs(10)
        .widthIs(kWidth(110))
        .heightIs((commentView.height-reviewLabel.height)*0.3);
        _contentTime = contentTime;
        
        UILabel *attrLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:11 numberOfLines:1 text:@""];
        [commentView addSubview:attrLabel];
        attrLabel.sd_layout
        .topEqualToView(contentTime)
        .leftSpaceToView(contentTime, 10)
        .widthIs(kWidth(130))
        .heightIs(contentTime.height);
        _attrLabel = attrLabel;
        
        y += commentView.height;
    }
   
    
    //商家信息
    UIView *storeView = [UIView new];
    storeView.backgroundColor = [UIColor whiteColor];
    storeView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] init];
    [[tap3 rac_gestureSignal] subscribeNext:^(id x) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(headViewTapClick:)]) {
            [weakSelf.delegate headViewTapClick:102];
        }
    }];
    

    y += kHeight(10);
    [storeView addGestureRecognizer:tap3];
    [self addSubview:storeView];
    storeView.sd_layout
    .yIs(y)
    .leftEqualToView(_cycleScrollView)
    .widthIs(SCREEN_WIDTH)
    .heightIs(kHeight(70));
    
    UIImage *storeImg = [UIImage imageNamed:@"shopstore_img_logo_45_45"];
    UIImageView *storeLogoV = [[UIImageView alloc] initWithImage:storeImg];
    [storeView addSubview:storeLogoV];
    storeLogoV.sd_layout
    .yIs(5)
    .xIs(10)
    .heightIs(storeView.height-10)
    .widthIs(storeView.height-10);
    _storeLogoV = storeLogoV;
    storeLogoV.layer.cornerRadius = storeLogoV.width/2;
    storeLogoV.layer.borderWidth = 0.5;
    storeLogoV.layer.borderColor = [UIColor grayColor].CGColor;
    storeLogoV.layer.masksToBounds = YES;
    
    UILabel *storeLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"明兴乳业"];
    [storeView addSubview:storeLabel];
    storeLabel.sd_layout
    .leftSpaceToView(storeLogoV, 10)
    .yIs(10)
    .widthIs(150)
    .heightIs(21);
    _storeLabel = storeLabel;
    
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:14 numberOfLines:1 text:@"主营业务："];
    [storeView addSubview:remarkLabel];
    remarkLabel.sd_layout
    .leftSpaceToView(storeLogoV, 10)
    .topSpaceToView(storeLabel, 5)
    .widthIs(SCREEN_WIDTH-(storeLogoV.width)-15)
    .heightIs(21);
    _remarkLabel = remarkLabel;
    
    UIImage *inputImg = [UIImage imageNamed:@"shopstore_btn_goto_13_13"];
    UIImageView *inputImageV = [[UIImageView alloc] initWithImage:inputImg];
    [storeView addSubview:inputImageV];
    inputImageV.sd_layout
    .centerYEqualToView(storeLabel)
    .xIs(SCREEN_WIDTH-35)
    .heightIs(18)
    .widthIs(18);
    
    UILabel *inputLabel = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:14 numberOfLines:1 text:@"进店逛逛"];
    inputLabel.textAlignment = NSTextAlignmentRight;
    [storeView addSubview:inputLabel];
    inputLabel.sd_layout
    .xIs(SCREEN_WIDTH-150-35)
    .yIs(8)
    .widthIs(150)
    .heightIs(kHeight(25));
    
    
    [self setDataVaule];
}

// 不想改来改去，
-(void)setDataVaule{
    id dataArray = self.data;
    NSDictionary *commentDict = [dataArray objectForKey:@"comment"];
    NSDictionary *model = [dataArray objectForKey:@"product"];

    id total = [commentDict objectForKey:@"total"];
    _commentLabel.text = [NSString stringWithFormat:@"买家评论(%@)",total];
    _reviewLabel.text = [NSString stringWithFormat:@"好评率 %@",[commentDict objectForKey:@"good_comment"]];
    _nameLabel.text = [commentDict objectForKey:@"user_name"];
    _contentLabel.text = [commentDict objectForKey:@"c_content"];
    _contentTime.text = [commentDict objectForKey:@"c_time"];
    id attr = [commentDict objectForKey:@"good_attr"];
    NSString *attrStr = [NSString stringWithFormat:@"%@",attr];
    if (![Utils isBlankString:attrStr]) {
        _attrLabel.text = attrStr;
    }
    [_storeLogoV sd_setImageWithURL:[NSURL URLWithString:[model objectForKey:@"s_logo"]] placeholderImage:[UIImage imageNamed:@"shopstore_img_logo_45_45"]];
    _storeLabel.text = [model objectForKey:@"s_name"];
    _remarkLabel.text = [model objectForKey:@"s_introduce"];
    
    _productName.text = [model objectForKey:@"pro_title"];
    _freightLabel.text = [NSString stringWithFormat:@"¥ %@起",[model objectForKey:@"freight"]];
    NSArray *serveArr = [model objectForKey:@"serve"];
    NSString *serverStr = @"";
    for (NSString *Str in serveArr) {
        serverStr = [NSString stringWithFormat:@"%@ %@",serverStr,Str];
    }

    _serveLabel.text = serverStr;
    
    NSString *balance =[NSString stringWithFormat:@"¥ %@",[model objectForKey:@"price"]];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:balance];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(12.0)]range:NSMakeRange(0, 1)];
    _price.attributedText= aString;
}

-(NSArray *)getSendType{
    id type = [[self.data objectForKey:@"product"] objectForKey:@"postage_type"];
    NSString *sendPrice;
    if ([type intValue] == 1) {
        sendPrice = @"全国包邮";
    }else if ([type intValue] == 3){
        sendPrice = @"邮费待议";
    }else{
        sendPrice = @"输入邮费";
    }
   
    NSString *cityStr = [[self.data objectForKey:@"product"] objectForKey:@"city"];
    NSString *areaStr = [[self.data objectForKey:@"product"] objectForKey:@"area"];
    id sellNumberStr = [[self.data objectForKey:@"product"] objectForKey:@"sell_number"];
    NSString *numberStr = [NSString stringWithFormat:@"销量%ld",(long)[sellNumberStr integerValue]];
    NSString *addressStr = [NSString stringWithFormat:@"%@%@",cityStr,areaStr];
    
    NSArray *array = [NSArray arrayWithObjects:numberStr,sendPrice,addressStr, nil];
    
    return array;
}

/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(cycleScrollViewClick:)]) {
        [self.delegate cycleScrollViewClick:index];
    }
}


@end
