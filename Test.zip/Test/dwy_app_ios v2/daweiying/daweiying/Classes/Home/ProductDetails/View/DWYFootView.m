//
//  DWYFootView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYFootView.h"

@implementation DWYFootView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        [self initWithSubViews]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews{
    
    //底部工具栏
    UIView *bottomView = [UIView new];
    bottomView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    [self addSubview:bottomView];
    bottomView.sd_layout
    .bottomSpaceToView(self, 0)
    .leftSpaceToView(self, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(49);
    
    float btnW = SCREEN_WIDTH * 0.55;
    
    UIButton *buyBtn = [UIButton new];
    buyBtn.frame = CGRectMake(self.width-btnW/2, 0, btnW/2, bottomView.height);
    [buyBtn setTitle:@"立即购买" forState:0];
    buyBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    buyBtn.backgroundColor = [UIColor colorWithHex:0xf67100];
    [bottomView addSubview:buyBtn];
    self.buyButton = buyBtn;
    
    UIButton *addShoppingCarBtn = [UIButton new];
    addShoppingCarBtn.frame = CGRectMake(self.width-btnW/2*2, 0, btnW/2, bottomView.height);
    [addShoppingCarBtn setTitle:@"加入购物车" forState:0];
    addShoppingCarBtn.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    addShoppingCarBtn.backgroundColor = [UIColor colorWithHex:0xff9602];
    [bottomView addSubview:addShoppingCarBtn];
    self.addShoppingCarButton = addShoppingCarBtn;
    
    
    float w = SCREEN_WIDTH * 0.45;
    
    //收藏
    float imageW = 25;
    float viewW = w/3;
    UIView *collectView = [UIView new];
    collectView.backgroundColor = [UIColor whiteColor];
    collectView.userInteractionEnabled = YES;
    collectView.frame = CGRectMake(viewW*2, 0, viewW, bottomView.height);
    collectView.backgroundColor = [UIColor whiteColor];
    [bottomView addSubview:collectView];
    _collectView = collectView;
    
    UIImage *imageName = [UIImage imageNamed:@"shopdt_btn_uncollection_26_26"];
    UIImageView *collectImageV = [[UIImageView alloc] initWithImage:imageName];
    collectImageV.frame = CGRectMake((viewW-imageW)/2, 5, imageW, imageW);
    [collectView addSubview:collectImageV];
    self.collectImageV = collectImageV;
    
    UILabel *collectLabel = [UILabel new];
    collectLabel.textColor = [UIColor colorWithHex:0x999999];
    collectLabel.text = @"收藏";
    collectLabel.adjustsFontSizeToFitWidth = YES;
    collectLabel.textAlignment = NSTextAlignmentCenter;
    collectLabel.font = [UIFont systemFontOfSize:12];
    [collectView addSubview:collectLabel];
    collectLabel.sd_layout
    .topSpaceToView(collectImageV, 0)
    .leftEqualToView(collectView)
    .widthIs(collectView.width)
    .heightIs(18);
    self.collectLabel = collectLabel;
    
    //聊天
    UIView *IMView = [UIView new];
    IMView.frame = CGRectMake(viewW, 0, viewW-1, bottomView.height);
    IMView.userInteractionEnabled = YES;
    IMView.backgroundColor = [UIColor whiteColor];
    [bottomView addSubview:IMView];
    _IMView = IMView;
    
    UIImage *imageNameIM = [UIImage imageNamed:@"shopdt_btn_chat_26_26"];
    UIImageView *IMImageV = [[UIImageView alloc] initWithImage:imageNameIM];
    IMImageV.frame = CGRectMake((viewW-imageW)/2, 5, imageW, imageW);
    [IMView addSubview:IMImageV];
    
    UILabel *IMLabel = [UILabel new];
    IMLabel.textColor = [UIColor colorWithHex:0x999999];
    IMLabel.text = @"客服";
    IMLabel.textAlignment = NSTextAlignmentCenter;
    IMLabel.font = [UIFont systemFontOfSize:12];
    [IMView addSubview:IMLabel];
    IMLabel.sd_layout
    .topSpaceToView(IMImageV, 0)
    .leftEqualToView(IMView)
    .widthIs(collectView.width)
    .heightIs(18);
    
    
    //店铺
    UIView *storeView = [UIView new];
    storeView.frame = CGRectMake(0, 0, viewW-1, bottomView.height);
    storeView.userInteractionEnabled = YES;
    storeView.backgroundColor = [UIColor whiteColor];
    [bottomView addSubview:storeView];
    _storeView = storeView;
    
    UIImage *imageNameStore = [UIImage imageNamed:@"shoplist_icon_store_22_22"];
    UIImageView *StoreImageV = [[UIImageView alloc] initWithImage:imageNameStore];
    StoreImageV.frame = CGRectMake((viewW-imageW)/2, 5, imageW, imageW);
    [storeView addSubview:StoreImageV];
    
    UILabel *StoreLabel = [UILabel new];
    StoreLabel.textColor = [UIColor colorWithHex:0x999999];
    StoreLabel.text = @"店铺";
    StoreLabel.textAlignment = NSTextAlignmentCenter;
    StoreLabel.font = [UIFont systemFontOfSize:12];
    [storeView addSubview:StoreLabel];
    StoreLabel.sd_layout
    .topSpaceToView(IMImageV, 0)
    .leftEqualToView(storeView)
    .widthIs(collectView.width)
    .heightIs(18);

}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end


#pragma mark --- 如果是自己
@implementation DWYIsMeFootView

-(instancetype)initWithFrame:(CGRect)frame Withtype:(int)type{ //0下架 1上架
    if (self == [super initWithFrame:frame]) {
        [self initWithSubViews:type]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews:(int)type{
    
    self.backgroundColor = [UIColor whiteColor];
    
    float btnW = SCREEN_WIDTH/3;
    float btnH = 49;
    
    CGRect rect = CGRectMake(0, 0, btnW-1, btnH);
    UIButton *btn1 = [self setupButton:rect imageStr:@"shopdetail_btn_delet_15_15" title:@" 删除"];
    [self addSubview:btn1];
    self.delBtn = btn1;
    
    UILabel *line = [Utils lineWithFrame:CGRectMake(btnW, 10, 1, 29)];
    [self addSubview:line];
    
    rect = CGRectMake(btnW+1, 0, btnW-1, btnH);
    NSString *str;
    if (type == 0) {
        str = @" 下架";
    }else if (type == 1){
        str = @" 上架";
    }
    UIButton *btn2 = [self setupButton:rect imageStr:@"shopdetail_btn_lower_15_15" title:str];
    [self addSubview:btn2];
    self.putawayBtn = btn2;
    
    UILabel *line2 = [Utils lineWithFrame:CGRectMake(btnW*2-2, 10, 1, 29)];
    [self addSubview:line2];
    
    rect = CGRectMake(btnW*2, 0, btnW, btnH);
    UIButton *btn3 = [self setupButton:rect imageStr:@"shopdetail_btn_stock_15_15" title:@" 库存"];
    [self addSubview:btn3];
    self.countBtn = btn3;
}

-(UIButton *)setupButton:(CGRect)frame imageStr:(NSString *)imageStr title:(NSString *)title{
    
    UIButton *btn = [[UIButton alloc] initWithFrame:frame];
    [btn setImage:[UIImage imageNamed:imageStr] forState:0];
    [btn setTitle:title forState:0];
    btn.titleLabel.font = [UIFont systemFontOfSize:15];
    [btn setTitleColor:[UIColor grayColor] forState:0];
    
    return btn;
    
}

@end
