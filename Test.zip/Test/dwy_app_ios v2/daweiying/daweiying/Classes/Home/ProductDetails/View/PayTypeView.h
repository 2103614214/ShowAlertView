//
//  PayTypeView.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/12.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WLPasswordView.h"

@interface PayTypeView : UIView


/** 关闭 */
@property(nonatomic,copy) void (^closeBtnBlock)();
/** 忘记密码 */
@property(nonatomic,copy) void (^forgetBtnBlock)();

/** 密码输入*/
@property(nonatomic,strong)WLPasswordView *inputView;;

@end
