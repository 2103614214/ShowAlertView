//
//  ConfirmPayCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/12/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfirmPayCell : UITableViewCell

@property(nonatomic,strong)UILabel *nameLabel;

@property(nonatomic,strong)UIImageView *selectedV;

@property(nonatomic,strong)UIImageView *logoV;

@end
