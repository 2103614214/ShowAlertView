//
//  DWYManageAddressCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/25.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYManageAddressCtl.h"
#import "AppDelegate.h"
#import "DWYAddressCell.h"
#import "DWYAddressModel.h"

#import "DWYAddNewAddrsssCtl.h"

@interface DWYManageAddressCtl () <UITableViewDataSource,UITableViewDelegate>
/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;

/** 是否删除地址 */
@property(nonatomic,assign)BOOL isDefault;
@end

@implementation DWYManageAddressCtl

static NSString * const addressCellID = @"addressCellID";

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-49)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = 125;
        if (@available(iOS 11.0, *)) {
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            _tableView.contentInset = UIEdgeInsetsMake(kNavBarStatusHeight, 0, kTabBarHeight, 0);
            _tableView.scrollIndicatorInsets = _tableView.contentInset;
        }
        _tableView.tableHeaderView = [UIView new];
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone; //去除所有分割线
        [_tableView registerClass:[DWYAddressCell class] forCellReuseIdentifier:addressCellID];
    }
    return _tableView;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"管理收货地址";
    
    [self.view addSubview:self.tableView];
    
    //底部
    UIButton *bottomButton = [UIButton new];
    [bottomButton setTitle:@"添加新地址" forState:0];
    bottomButton.backgroundColor = [UIColor colorWithHex:0xf67100];
    [bottomButton addTarget:self action:@selector(addNewAddress) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:bottomButton];
    float margeH = 0;
    if (kStatusBarHeight > 20) {
        margeH = 20;
    }
    bottomButton.sd_layout
    .bottomSpaceToView(self.view, margeH)
    .leftSpaceToView(self.view, 0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(49);

    //请求网络数据
    [self loadData];
    
    /*****通知刷新数据*********/
    __weak typeof (self)weakSelf = self;
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"Refresh" object:nil] subscribeNext:^(id x) {
        [weakSelf loadData];
    }];

}

-(void)back{
    if (self.isDefault) {
//        if ([self.delegate respondsToSelector:@selector(sendMessage:withTel:WithAddress:WithID:)]) {
//            [self.delegate sendMessage:@"" withTel:@"" WithAddress:@"" WithID:0];
//        }
    }
     [self.navigationController popViewControllerAnimated:YES];
   
}

//新增地址
-(void)addNewAddress{
    DWYAddNewAddrsssCtl *newAddrsss = [DWYAddNewAddrsssCtl new];
    [self.navigationController pushViewController:newAddrsss animated:YES];
}

-(void)loadData{
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    NSString *urlStr = [Utils getMemberServiceUri:@"address"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        
        [self.tableView.mj_header endRefreshing];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            //数据源
            NSDictionary *commentDict = [dataObject objectForKey:@"address"];
            self.dataArray = [DWYAddressModel mj_objectArrayWithKeyValuesArray:commentDict];
            
            [self.tableView reloadData];
            if (self.dataArray.count > 0) {
                [self.tableView hideBlankPageView];
            }else{
                //[self.tableView showBlankPageView:1];
            }
        }else if ([status isEqualToString:@"201"]){
            //[self.tableView showBlankPageView:1];
           // [MBManager showError:@"暂无收货地址"];
        }
        else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.tableView.mj_header endRefreshing];
        
        
    }];

}

#pragma mark - UITableView 代理，数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DWYAddressCell *cell = [tableView dequeueReusableCellWithIdentifier:addressCellID];
    if (!cell) {
        cell = [[DWYAddressCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:addressCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影

    
    cell.model = self.dataArray[indexPath.row];
    
    DWYAddressModel *model = self.dataArray[indexPath.row];
    
    __weak typeof (self)WeakSelf = self;
    cell.block = ^(NSInteger tag) {
        //DLog(@"%d",model.id);
        if (tag == 100) { //修改默认
            [WeakSelf setDefaultAddress:model index:indexPath.row];
        }else if (tag == 101){ //删除
            [WeakSelf delAddress:model.id WithRow:indexPath.row isDefault:model.statu];
        }else if (tag == 102){ //编辑
            [WeakSelf editAddress:model];
        }
    };
    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    DWYAddressModel *model = self.dataArray[indexPath.row];
    
    DWYAddressCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    
    NSString *addrsssStr = cell.addressLabel.text;
    
    if ([self.delegate respondsToSelector:@selector(sendMessage:withTel:WithAddress:WithID:)]) {
        [self.delegate sendMessage:model.name withTel:model.phone WithAddress:addrsssStr WithID:model.id];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

//修改默认地址
-(void)setDefaultAddress:(DWYAddressModel *)model index:(NSInteger)index{

    
    [MBManager showLoading];

    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"name"] = model.name;
    params[@"phone"] = model.phone;
    params[@"province"] = model.province;
    params[@"area"] = model.area;
    if ([Utils isBlankString:model.city]) {
        params[@"city"] = @" ";
    }else{
        params[@"city"] = model.city;
    }
    
    params[@"address"] = model.address_name;
    params[@"statu"] = @(1);
    
    params[@"a_id"] = @(model.id);
    NSString *urlStr = [Utils getMemberServiceUri:@"update_address"];
    

    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        // NSLog(@"%@",[Utils transformUnicode:responseObject]);
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"修改成功"];
            
            //存储地址
            NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
            [ud setObject:model.phone forKey:@"add_Phone"];
            [ud setObject:model.name forKey:@"add_Name"];
            [ud setObject:model.province forKey:@"province"];
            [ud setObject:model.city forKey:@"city"];
            [ud setObject:model.area forKey:@"area"];
            [ud setObject:model.address_name forKey:@"address_name"];
            [ud setObject:@(model.id) forKey:@"address_id"];
            [ud synchronize];

            for (int i = 0; i<self.dataArray.count; i++) {
                DWYAddressModel *model =self.dataArray[i];
                model.statu = 0;
            }
            DWYAddressModel *model =self.dataArray[index];
            model.statu = 1;
            [self.tableView reloadData];
            
        }else if ([status isEqualToString:@"402"]){
            [MBManager showError:@"手机号有误"];
        }
        else{
            [MBManager showError:@"提交失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        
        //DLog(@"%@",error);
        [MBManager showError];
        
    }];
    
}

#pragma mark -- 编辑
-(void)editAddress:(DWYAddressModel *)model{
    DWYAddNewAddrsssCtl *newAddrsss = [DWYAddNewAddrsssCtl new];
    newAddrsss.model = model;
    newAddrsss.jumpType = 1;
    [self.navigationController pushViewController:newAddrsss animated:YES];
}

#pragma mark -- 删除地址
-(void)delAddress:(int)addressID WithRow:(NSInteger)row isDefault:(BOOL)isDefault{
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a_id"] = @(addressID);
    
    NSString *urlStr = [Utils getMemberServiceUri:@"del_address"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //NSLog(@"%@",[Utils transformUnicode:responseObject]);
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            [MBManager showSuccess:@"删除成功"];
            [self.dataArray removeObjectAtIndex:row];
            
            if (isDefault) {
                self.isDefault = YES;
                NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
                [ud setObject:@"" forKey:@"add_Phone"];
                [ud setObject:@"" forKey:@"add_Name"];
                [ud setObject:@"" forKey:@"province"];
                [ud setObject:@"" forKey:@"city"];
                [ud setObject:@"" forKey:@"area"];
                [ud setObject:@"" forKey:@"address_name"];
                [ud setObject:@"" forKey:@"address_id"];
                [ud synchronize];
            }

            
            [self.tableView reloadData];
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        
    }];

}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
