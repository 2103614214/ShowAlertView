//
//  CompanyMakeLayout.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CompanyMakeLayout.h"

@implementation CompanyMakeLayout

/// 准备布局
- (void)prepareLayout {
    [super prepareLayout];
    //设置item尺寸
    CGFloat itemW = (self.collectionView.frame.size.width-15)/ 2;
    self.itemSize = CGSizeMake(itemW, itemW+(kHeight(80))); //150 90
    
    //设置最小间距
    self.minimumLineSpacing = 5;
    self.minimumInteritemSpacing = 5;
    self.sectionInset = UIEdgeInsetsMake(5, 5, 0, 5);
   // self.headerReferenceSize=CGSizeMake(SCREEN_WIDTH, (SCREEN_HEIGHT*0.48)+10); //设置collectionView头视图的大
}

@end
