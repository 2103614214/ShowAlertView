//
//  CompanyMakeCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/13.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CompanyMakeCtl.h"
#import "makeMenuCateModel.h"
#import "CompanyMakeViewCtl.h"
#import "UIView+Uitls.h"

#import "PYSearch.h"
#import "SearchResultViewController.h"

#define CURRENT_SIZE(_size) _size / 375.0 * SCREEN_WIDTH

@interface CompanyMakeCtl () <UIScrollViewDelegate,PYSearchViewControllerDelegate>

{
    //用中间变量 来 接受点击后的控件
    UIView * _temp_view;
    UIButton * _temp_bt;
}

@property(nonatomic,strong)UIScrollView * categaryScroll;

/** 数据 */
@property(nonatomic,strong)NSMutableArray *categoryArr;

@property(nonatomic,strong)NSMutableArray *text_arr;
//文本 下划线
@property(nonatomic,strong)UILabel * label;

@property(nonatomic,strong)UIScrollView * controllerScroll;

//存放所有文本button的数组
@property(nonatomic,copy)NSMutableArray * button_arr;

@property(nonatomic,strong)NSArray *hotSeaches;

@end

@implementation CompanyMakeCtl

-(NSMutableArray *)categoryArr{
    if (!_categoryArr) {
        _categoryArr = [NSMutableArray array];
    }
    return _categoryArr;
}
-(NSMutableArray *)text_arr{
    if (!_text_arr) {
        _text_arr = [NSMutableArray array];
    }
    return _text_arr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
 
    
    [self loadDataCategory];
    
    self.navigationItem.titleView = [[UIView alloc] initWithFrame:CGRectMake(kWidth(40), 4, SCREEN_WIDTH-(kHeight(60)), 30)];
    self.navigationItem.titleView.backgroundColor = [UIColor whiteColor];
    self.navigationItem.titleView.layer.cornerRadius = 5;
    self.navigationItem.titleView.layer.masksToBounds = YES;
    self.navigationItem.titleView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    __weak typeof (self)weakSelf = self;
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf jumpSearchView]; //跳转搜索页
       
    }];
    [self.navigationItem.titleView addGestureRecognizer:tap];
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"food_btn_search_22_22"]];
    imageV.frame = CGRectMake(10, 6, 18, 18);
    [self.navigationItem.titleView addSubview:imageV];
    
    UILabel *label = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"商品名称"];
    label.frame = CGRectMake(42, 0, 150, 30);
    [self.navigationItem.titleView addSubview:label];
    
    [self loadHotValue]; //获取热搜关键字
    

    if (self.jumpType == 1) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            for (int i = 0; i<self.categoryArr.count; i++) {
                
                makeMenuCateModel *model = self.categoryArr[i];
                if (self.cateType == model.cate_id) {
                    
                    UIButton *btn = self.button_arr[i];
                    [self changeControllerAction:btn type:1];
                }
            }
        });
    }

}

-(void)jumpSearchView{
    
    // 1.创建热门搜索
    //NSArray *hotSeaches = @[@"Java", @"Python", @"Objective-C", @"Swift", @"C", @"C++", @"PHP", @"C#", @"Perl", @"Go", @"JavaScript", @"R", @"Ruby", @"MATLAB"];
    if (self.hotSeaches.count < 1) {
        return;
    }

    // 2. 创建控制器
    PYSearchViewController *searchViewController = [PYSearchViewController searchViewControllerWithHotSearches:self.hotSeaches searchBarPlaceholder:@"商品名称" didSearchBlock:^(PYSearchViewController *searchViewController, UISearchBar *searchBar, NSString *searchText) {
        // 开始搜索执行以下代码
       
        // 如：跳转到指定控制器
        SearchResultViewController *vc = [[SearchResultViewController alloc] init];
        vc.keywords = searchText;
        [searchViewController.navigationController pushViewController:vc animated:YES];
    }];
    // 3. 设置风格
    searchViewController.hotSearchStyle = PYHotSearchStyleColorfulTag; // 热门搜索风格为默认
    searchViewController.searchHistoryStyle = 2; // 搜索历史风格根据选择
    
    // 4. 设置代理
    searchViewController.delegate = self;
    // 5. 跳转到搜索控制器
    [self.navigationController pushViewController:searchViewController animated:YES];
}


-(void)loadHotValue{

    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    NSString *urlStr = [Utils getMemberServiceUri:@"topSearch"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            self.hotSeaches = [dataObject objectForKey:@"top_search"];
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
    
}


#pragma mark ------- 点击事件 ---------
- (void)changeControllerAction:(UIButton *)bt type:(int)type{
    //设置连续的两次无法点击同一个
    if (_temp_bt == bt) {
        return;
    }
    
    [bt setTitleColor:[UIColor colorWithHex:UI_COLOR_ORANGE] forState:UIControlStateNormal];
    [_temp_bt setTitleColor:[UIColor colorWithHex:0x666666] forState:UIControlStateNormal];
    _temp_bt = bt;
    float time = 0;
    if (type == 1) {
        time = 0;
    }else{
        time = 0.5;
    }
    [UIView animateWithDuration:time animations:^{
        self.label.frame = CGRectMake(bt.superview.frame.origin.x, 48, bt.frame.size.width, 2);
        self.controllerScroll.contentOffset = CGPointMake(SCREEN_WIDTH * (bt.tag - 100), 0);
        NSInteger tag = bt.tag;
        float marge = 0.00;
        if (bt.width > 50) {
            marge = kWidth(65);
        }else{
            marge = kWidth(50);
        }
        if (tag > 102) {
            self.categaryScroll.contentOffset = CGPointMake(marge*(tag - 100), 0);
        }else{
            self.categaryScroll.contentOffset = CGPointMake(0, 0);
        }

    } completion:^(BOOL finished) {
        
    }];

    // 滚动
     [self scrollViewDidEndScrollingAnimation:self.controllerScroll];
}

#pragma mark ------- 支持方法 ---------
- (CGRect)rectWithText:(NSString *)text fontSize:(CGFloat)fontSize{
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]};
    CGSize size = CGSizeMake([UIScreen mainScreen].bounds.size.width, 3000);
    CGRect rect = [text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil];
    return rect;
}

#pragma mark ------- 懒加载 ----------
- (UIScrollView *)categaryScroll{
    if (!_categaryScroll) {
        _categaryScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, kNavBarStatusHeight, SCREEN_WIDTH, 50)];
        _categaryScroll.backgroundColor = [UIColor whiteColor];
        
        float sum_x = 10;
        
        CGRect rect01 = [self rectWithText:self.text_arr.firstObject fontSize:15];
        
        //label的起始位置
        self.label = [[UILabel alloc] initWithFrame:CGRectMake(10, 48, rect01.size.width, 2)];
        self.label.backgroundColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
        
        for (int i = 0; i < self.text_arr.count; i++) {
            
            CGRect rect = [self rectWithText:self.text_arr[i] fontSize:15];
            
            UIView * vi = [[UIView alloc] initWithFrame:CGRectMake(sum_x, 0, rect.size.width, 48)];
            vi.backgroundColor = [UIColor whiteColor];
            vi.userInteractionEnabled = YES;
            
            UIButton * bt = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, vi.frame.size.width, 48)];
            bt.titleLabel.font = [UIFont systemFontOfSize:15];
            [bt setTitleColor:[UIColor colorWithHex:0x666666] forState:UIControlStateNormal];
            [bt setTitle:self.text_arr[i] forState:UIControlStateNormal];
            
            [bt addTarget:self action:@selector(changeControllerAction:type:) forControlEvents:UIControlEventTouchDown];
            bt.tag = 100 + i;
            
            [self.button_arr addObject:bt];
            
            //默认选中第一个
            if (i == 0) {
                
                [bt setTitleColor:[UIColor colorWithHex:UI_COLOR_ORANGE] forState:UIControlStateNormal];
                _temp_view = vi;
                _temp_bt = bt;
                
            }
            
            [vi addSubview:bt];
            sum_x = sum_x + rect.size.width + 20;
            
            [_categaryScroll addSubview:vi];
        }
        
        _categaryScroll.contentSize = CGSizeMake(sum_x, 30);
        
        _categaryScroll.contentOffset = CGPointMake(0, 0);
        
        _categaryScroll.showsHorizontalScrollIndicator = NO;
        self.automaticallyAdjustsScrollViewInsets = NO;
        
        [_categaryScroll addSubview:self.label];
    }
    return _categaryScroll;
}

- (UIScrollView *)controllerScroll{
    if (!_controllerScroll) {
        _controllerScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, kNavBarStatusHeight+50, SCREEN_WIDTH, SCREEN_HEIGHT-kNavBarStatusHeight-50)];
        
        
        for (int i = 0; i<self.categoryArr.count; i++) {
            makeMenuCateModel *model = self.categoryArr[i];
            CompanyMakeViewCtl *Vc = [[CompanyMakeViewCtl alloc] init];
            Vc.type = model.cate_id;
            Vc.title = model.cate_name;
            [self.text_arr addObject:model.cate_name];
            [self addChildViewController:Vc];
        }
 
        // 添加第一个控制器的view
        [self scrollViewDidEndScrollingAnimation:_controllerScroll];
        _controllerScroll.delegate = self;
        
        _controllerScroll.contentSize = CGSizeMake(SCREEN_WIDTH * self.childViewControllers.count, SCREEN_HEIGHT-kNavBarStatusHeight-50);
        _controllerScroll.contentOffset = CGPointMake(0, 0);
        _controllerScroll.pagingEnabled = YES;
        
        _controllerScroll.showsHorizontalScrollIndicator = NO;
    }
    return _controllerScroll;
}

#pragma mark - <UIScrollViewDelegate>
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    if (scrollView == self.controllerScroll) {
        // 当前的索引
        NSInteger index = scrollView.contentOffset.x / scrollView.width;
        // 取出子控制器
        UIViewController *vc = self.childViewControllers[index];
        vc.view.x = scrollView.contentOffset.x;
        vc.view.y = 0; // 设置控制器view的y值为0(默认是20)
        vc.view.height = scrollView.height; // 设置控制器view的height值为整个屏幕的高度(默认是比屏幕高度少个20)
        [scrollView addSubview:vc.view];
    }

}

- (NSMutableArray *)button_arr{
    if (!_button_arr) {
        _button_arr = [[NSMutableArray alloc] init];
    }
    return _button_arr;
    

}


#pragma mark ----- scrollView的协议方法 -----
//当scrollView减速完成时调用该方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    int page = scrollView.contentOffset.x / SCREEN_WIDTH;
  
    UIButton * bt = (UIButton *)self.button_arr[page];
    
    if (_temp_bt == bt) {
        return;
    }
    
    [bt setTitleColor:[UIColor colorWithHex:UI_COLOR_ORANGE] forState:UIControlStateNormal];
    [_temp_bt setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _temp_bt = bt;
    
    [UIView animateWithDuration:0.5 animations:^{
        self.label.frame = CGRectMake(bt.superview.frame.origin.x, 48, bt.frame.size.width, 2);
        float marge = 0.00;
        if (bt.width > 50) {
            marge = kWidth(65);
        }else{
            marge = kWidth(50);
        }
        if (page > 2) {
            self.categaryScroll.contentOffset = CGPointMake(marge * page, 0);
        }else{
            self.categaryScroll.contentOffset = CGPointMake(0, 0);
        }
    } completion:^(BOOL finished) {
        
    }];
    
      [self scrollViewDidEndScrollingAnimation:scrollView];
}


-(void)loadDataCategory{
    [MBManager showLoading];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    NSString *urlStr = [Utils getMemberLoginUri:@"makeMenu"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            NSDictionary *dict = [dataObject objectForKey:@"menu"];
            
            self.categoryArr = [makeMenuCateModel mj_objectArrayWithKeyValuesArray:dict];

            for (int i =0;i<self.categoryArr.count;i++) {
                makeMenuCateModel *model = self.categoryArr[i];
                [self.text_arr addObject:model.cate_name];
            }
            [self.view addSubview:self.categaryScroll];
            [self.view addSubview:self.controllerScroll];
        
//            for (int i = 0; i<self.categoryArr.count; i++) {
//
//              //  NSLog(@"xxxx-------------%@",self.categoryArr[i]);
//                makeMenuCateModel *model = self.categoryArr[i];
//                if (self.cateType == model.cate_id) {
//                    NSLog(@"-------%d",i);
//                    _temp_bt = self.button_arr[i];
//                    [self changeControllerAction:_temp_bt];
//
//                }
//            }
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
         
    }];
    
    

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
