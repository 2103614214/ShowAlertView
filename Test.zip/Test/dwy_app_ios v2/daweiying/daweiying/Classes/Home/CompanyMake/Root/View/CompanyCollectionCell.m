//
//  CompanyCollectionCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CompanyCollectionCell.h"
#import "makeMenuCateModel.h"

@implementation CompanyCollectionCell
{
    UIImageView *_imageV;
    UILabel *_nameLabel;
    UILabel *_priceLabel;
    UILabel *_sellNumber;
    UIImageView *_imageType;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        //图片
        UIImageView *imageV = [[UIImageView alloc] init];
        [self.contentView addSubview:imageV];
        imageV.sd_layout
        .topSpaceToView(self.contentView, 0)
        .leftSpaceToView(self.contentView, 0)
        .widthIs(self.contentView.width)
        .heightIs(self.contentView.width);
        _imageV = imageV;
        
        //商品名
        UILabel *label = [[UILabel alloc] init];
        label.textColor = [UIColor grayColor];
        label.numberOfLines = 0;
        label.textAlignment = NSTextAlignmentLeft;
        label.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:label];
        label.sd_layout
        .topSpaceToView(imageV, 0)
        .leftSpaceToView(self.contentView, 10)
        .widthIs(self.contentView.width-20)
        .heightIs(kHeight(50));
        _nameLabel = label;
        
        UIImageView *imageType = [[UIImageView alloc] init];
        [self.contentView addSubview:imageType];
        imageType.sd_layout
        .topSpaceToView(imageV, 5)
        .leftSpaceToView(self.contentView, 5)
        .widthIs(kWidth(25))
        .heightIs(kHeight(18));
        _imageType = imageType;
        
        //商品价格
        UILabel *pricelabel = [[UILabel alloc] init];
        pricelabel.textColor = [UIColor colorWithHex:0xf67100];
        pricelabel.textAlignment = NSTextAlignmentLeft;
        pricelabel.adjustsFontSizeToFitWidth = YES;
        pricelabel.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:pricelabel];
        pricelabel.sd_layout
        .topSpaceToView(label, 0)
        .leftSpaceToView(self.contentView, 10)
        .widthIs(self.contentView.width*0.4)
        .heightIs(kHeight(30));
        _priceLabel = pricelabel;
        
        
        UILabel *sellNumber = [Utils labelTextColor:[UIColor colorWithHex:0x999999] fontSize:13 numberOfLines:1 text:@"销量:35"];
        sellNumber.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:sellNumber];
        sellNumber.sd_layout
        .topSpaceToView(label, 0)
        .rightSpaceToView(self.contentView, 10)
        .widthIs(self.contentView.width*0.45)
        .heightIs(kHeight(30));
        _sellNumber = sellNumber;
        
        
    }
    return self;
}

-(void)setType:(int)type{
    _type = type;
}

-(void)setModel:(companyMakeModel *)model{
    _model = model;
    [_imageV sd_setImageWithURL:[NSURL URLWithString:model.logo_url] placeholderImage:[UIImage imageNamed:placeImageName]];
    if (self.type == 2) {
        _nameLabel.text = [NSString stringWithFormat:@"%@",model.pro_name];
    }else{
        _nameLabel.text = [NSString stringWithFormat:@"      %@",model.pro_name];
    }

    
    _sellNumber.text = [NSString stringWithFormat:@"销量:%ld",model.sell_number];
    
    NSString *balance =[NSString stringWithFormat:@"¥ %@",model.price];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:balance];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(14.0)]range:NSMakeRange(0, 1)];
    _priceLabel.attributedText= aString;
    
//    if (model.pro_name.length<12) {
//
//        _imageType.sd_layout
//        .topSpaceToView(_imageV, 15);
//    }
    if (model.type == 1) { //日常零售
        [_imageType setImage:[UIImage imageNamed:@"img_store_23_15"]];
    }else if (model.type == 2){ //企业制造
        [_imageType setImage:[UIImage imageNamed:@"img_make_23_15"]];
    }
    
}

@end
