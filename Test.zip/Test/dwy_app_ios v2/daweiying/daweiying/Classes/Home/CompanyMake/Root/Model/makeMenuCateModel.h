//
//  makeMenuCateModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/11/13.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseModel.h"

@interface makeMenuCateModel : BaseModel

/** id */
@property(nonatomic,assign)int id;
/** name */
@property(nonatomic,copy)NSString *cate_name;
/** type */
@property(nonatomic,copy)NSString *type;
/** cate_id */
@property(nonatomic,assign)int cate_id;

@end


@interface companyMakeModel : BaseModel

/** id */
@property(nonatomic,assign)int pro_id;
/** name */
@property(nonatomic,copy)NSString *pro_name;
/** 属性 */
@property(nonatomic,copy)NSString *pro_attr;
/** logo url */
@property(nonatomic,copy)NSString *logo_url;
/** 价格 */
@property(nonatomic,copy)NSString *price;
/** 销量 */
@property(nonatomic,assign)NSInteger sell_number;
/** type */
@property(nonatomic,assign)int type;

@end
