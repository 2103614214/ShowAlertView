//
//  CompanyCollectionCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/11/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class companyMakeModel;
@interface CompanyCollectionCell : UICollectionViewCell

@property(nonatomic,strong)companyMakeModel *model;

/** 复用类型 */
@property(nonatomic,assign)int type;
@end
