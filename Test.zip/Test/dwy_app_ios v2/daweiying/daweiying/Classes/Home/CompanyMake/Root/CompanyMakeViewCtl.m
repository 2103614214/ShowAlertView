//
//  CompanyMakeViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/13.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CompanyMakeViewCtl.h"

#import "CompanyCollectionCell.h"
#import "CompanyMakeLayout.h"
#import "makeMenuCateModel.h"
#import "DWYDetailsViewCtl.h"

@interface CompanyMakeViewCtl () <UICollectionViewDelegate, UICollectionViewDataSource>

/** collectionView */
@property (nonatomic, strong) UICollectionView *collectionView;
/** 商品数据源 */
@property(nonatomic,strong)NSMutableArray *productMutableArr;


/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;

@end

static NSString *companyMakeID = @"companyMakeID";
@implementation CompanyMakeViewCtl

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-kNavBarStatusHeight-50) collectionViewLayout:[[CompanyMakeLayout alloc] init]];
        [_collectionView registerClass:[CompanyCollectionCell class] forCellWithReuseIdentifier:companyMakeID];

        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        
    }
    return _collectionView;
}

-(NSMutableArray *)productMutableArr{
    if (!_productMutableArr) {
        _productMutableArr = [NSMutableArray array];
    }
    return _productMutableArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
     [self.view addSubview:self.collectionView];
    
    // 添加刷新控件
    [self setupRefresh];
}


-(void)setupRefresh{
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.collectionView.mj_header.automaticallyChangeAlpha = YES;
    [self.collectionView.mj_header beginRefreshing];
    
    self.collectionView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
}

-(void)loadData{
    [MBManager showLoading];
    
    [self.collectionView.mj_footer endRefreshing];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"cate_id"] = @(self.type);
    NSString *urlStr = [Utils getMemberLoginUri:@"companyMake"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        
        [self.collectionView.mj_header endRefreshing];
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            //品牌推广数据源
            NSDictionary *hotDict = [dataObject objectForKey:@"goods"];
            self.productMutableArr = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            if (self.productMutableArr.count > 0) {
                [self.collectionView hideBlankPageView];
            }else{
                [self.collectionView showBlankPageView:8];
            }
            [self.collectionView reloadData];
            
        }else if ([status isEqualToString:@"201"]){
             [self.collectionView showBlankPageView:8];
        }
        else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_header endRefreshing];
        if (self.params != params) return;
    }];
    
}

//上拉刷新请求
-(void)loadMoreDatas{
    // 结束下拉
    [self.collectionView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"到底了"];
        [self.collectionView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"cate_id"] = @(self.type);
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"companyMake"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *hotDict = [dataObject objectForKey:@"goods"];
            NSArray *newProducts = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            [self.productMutableArr addObjectsFromArray:newProducts];
            
            [self.collectionView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.collectionView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_footer endRefreshing];
        if (self.params != params) return;
    }];
    
}

#pragma mark UICollectionViewDataSource 数据源方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.productMutableArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CompanyCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:companyMakeID forIndexPath:indexPath];
    cell.type = 2;
    cell.model = self.productMutableArr[indexPath.row];
    return cell;
}

#pragma mark UICollectionView 代理方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {

    companyMakeModel *model = self.productMutableArr[indexPath.row];
    DWYDetailsViewCtl *productCtl = [[DWYDetailsViewCtl alloc] init];
    productCtl.productID = model.pro_id;
    productCtl.type = isHome;
    [self.navigationController pushViewController:productCtl animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
