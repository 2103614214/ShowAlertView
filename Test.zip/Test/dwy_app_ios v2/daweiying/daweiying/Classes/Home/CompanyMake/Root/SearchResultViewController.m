//
//  SearchResultViewController.m
//  daweiying
//
//  Created by 汪亮 on 2017/11/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "SearchResultViewController.h"
#import "WZBSegmentedControl.h"

#import "CompanyCollectionCell.h"
#import "CompanyMakeLayout.h"
#import "makeMenuCateModel.h"
#import "DWYDetailsViewCtl.h"
#import "PYSearchViewController.h"

@interface SearchResultViewController ()  <UICollectionViewDelegate, UICollectionViewDataSource,PYSearchViewControllerDelegate>

/** collectionView */
@property (nonatomic, strong) UICollectionView *collectionView;
/** 商品数据源 */
@property(nonatomic,strong)NSMutableArray *productMutableArr;
// 可滑动的segmentedControl
@property (nonatomic, strong) WZBSegmentedControl *sectionView;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;

@property(nonatomic,strong)NSArray *hotSeaches;

/** 请求类型 */
@property(nonatomic,assign)NSInteger type;

@end

static NSString *SearchResultMakeID = @"SearchResultMakeID";
@implementation SearchResultViewController

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 64+45, SCREEN_WIDTH, SCREEN_HEIGHT-64-45) collectionViewLayout:[[CompanyMakeLayout alloc] init]];
        [_collectionView registerClass:[CompanyCollectionCell class] forCellWithReuseIdentifier:SearchResultMakeID];
        
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        
    }
    return _collectionView;
}

-(NSMutableArray *)productMutableArr{
    if (!_productMutableArr) {
        _productMutableArr = [NSMutableArray array];
    }
    return _productMutableArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     //self.title = @"搜索结果";
    [self setupHeadView];
    
    self.type = 1;
    
    
    [self.view addSubview:self.collectionView];
    //[self loadDataWithServer];
    // 添加刷新控件
    [self setupRefresh];
    
    
    
}

-(void)setupRefresh{
    self.collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadDataWithServer)];
    // 自动改变透明度
    self.collectionView.mj_header.automaticallyChangeAlpha = YES;
    [self.collectionView.mj_header beginRefreshing];
    
    self.collectionView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
}

-(void)setupHeadView{
    // 创建segmentedControl
    __weak typeof(self)weakSelf = self;
    self.navigationItem.titleView = [[UIView alloc] initWithFrame:CGRectMake(kWidth(40), 4, SCREEN_WIDTH-(kHeight(60)), 30)];
    self.navigationItem.titleView.backgroundColor = [UIColor whiteColor];
    self.navigationItem.titleView.layer.cornerRadius = 5;
    self.navigationItem.titleView.layer.masksToBounds = YES;
    self.navigationItem.titleView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
   
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        
        [weakSelf jumpSearchView]; //跳转搜索页
        
    }];
    [self.navigationItem.titleView addGestureRecognizer:tap];
    UIImageView *imageV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"food_btn_search_22_22"]];
    imageV.frame = CGRectMake(10, 6, 18, 18);
    [self.navigationItem.titleView addSubview:imageV];
    
    UILabel *label = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"商品名称"];
    label.frame = CGRectMake(42, 0, 150, 30);
    [self.navigationItem.titleView addSubview:label];
    
 

  
    WZBSegmentedControl *sectionView = [WZBSegmentedControl segmentWithFrame:(CGRect){0, 64, SCREEN_WIDTH, 44} titles:@[@"综合", @"销量", @"新品",@"价格"] tClick:^(NSInteger index) {
        
        //NSLog(@"----%ld",index+1);
        weakSelf.type = index+1;
        [weakSelf loadDataWithServer];
        
    }];
    sectionView.backgroundView.hidden = YES;
    // 赋值给全局变量
    self.sectionView = sectionView;
    
    // 设置其他颜色
    [sectionView setNormalColor:[UIColor grayColor] selectColor:[UIColor colorWithHex:0xf67100] sliderColor:[UIColor colorWithHex:0xf67100] edgingColor:[UIColor clearColor] edgingWidth:0];
    sectionView.backgroundColor = [UIColor whiteColor];
    // 去除圆角
    sectionView.layer.cornerRadius = sectionView.backgroundView.layer.cornerRadius = .0f;
    
    // 调下frame
    CGRect frame = sectionView.backgroundView.frame;
    frame.origin.y = frame.size.height - 1.5;
    frame.size.height = 1;
    sectionView.backgroundView.frame = frame;

    [self.view addSubview:sectionView];
}

-(void)jumpSearchView{
    
    // 1.创建热门搜索
    //NSArray *hotSeaches = @[@"Java", @"Python", @"Objective-C", @"Swift", @"C", @"C++", @"PHP", @"C#", @"Perl", @"Go", @"JavaScript", @"R", @"Ruby", @"MATLAB"];
//    if (self.hotSeaches.count < 1) {
//        return;
//    }
    
    // 2. 创建控制器
    PYSearchViewController *searchViewController = [PYSearchViewController searchViewControllerWithHotSearches:self.hotSeaches searchBarPlaceholder:@"商品名称" didSearchBlock:^(PYSearchViewController *searchViewController, UISearchBar *searchBar, NSString *searchText) {
        // 开始搜索执行以下代码
        
        // 如：跳转到指定控制器
        SearchResultViewController *vc = [[SearchResultViewController alloc] init];
        vc.keywords = searchText;
        [searchViewController.navigationController pushViewController:vc animated:YES];
    }];
    // 3. 设置风格
    searchViewController.hotSearchStyle = PYHotSearchStyleColorfulTag; // 热门搜索风格为默认
    searchViewController.searchHistoryStyle = 2; // 搜索历史风格根据选择
    
    // 4. 设置代理
    searchViewController.delegate = self;
    // 5. 跳转到搜索控制器
    [self.navigationController pushViewController:searchViewController animated:YES];
}


-(void)loadDataWithServer{
    [MBManager showLoading];
    [self.collectionView.mj_footer endRefreshing];
    
    [self.productMutableArr removeAllObjects];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"keywords"] = self.keywords;
    params[@"order"] = @(self.type);
    NSString *urlStr = [Utils getMemberServiceUri:@"searchGoods"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
       // NSLog(@"%@",[Utils transformUnicode:responseObject]);
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
         [self.collectionView.mj_header endRefreshing];
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            //品牌推广数据源
            NSDictionary *hotDict = [dataObject objectForKey:@"goods"];
            self.productMutableArr = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            if (self.productMutableArr.count > 0) {
                [self.view hideBlankPageView];
            }else{
                [self.view showBlankPageView:5];
            }
            [self.collectionView reloadData];
            
        }else if ([status isEqualToString:@"401"]){ //没有商品
            [self.view showBlankPageView:5];
        }
        else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_header endRefreshing];
        if (self.params != params) return;
    }];
    
}

//上拉刷新请求
-(void)loadMoreDatas{
    // 结束下拉
    [self.collectionView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"到底了"];
        [self.collectionView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"keywords"] = self.keywords;
    params[@"order"] = @(self.type);
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"searchGoods"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *hotDict = [dataObject objectForKey:@"goods"];
            NSArray *newProducts = [companyMakeModel mj_objectArrayWithKeyValuesArray:hotDict];
            [self.productMutableArr addObjectsFromArray:newProducts];
            
            [self.collectionView reloadData];
            
        }else if ([status isEqualToString:@"401"]){ //没有商品
            [self.view showBlankPageView:5];
        }
        else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.collectionView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
        [self.collectionView.mj_footer endRefreshing];
        if (self.params != params) return;
    }];
    
}

#pragma mark UICollectionViewDataSource 数据源方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.productMutableArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CompanyCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:SearchResultMakeID forIndexPath:indexPath];
    cell.model = self.productMutableArr[indexPath.row];
    return cell;
}

#pragma mark UICollectionView 代理方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    companyMakeModel *model = self.productMutableArr[indexPath.row];
    DWYDetailsViewCtl *productCtl = [[DWYDetailsViewCtl alloc] init];
    productCtl.productID = model.pro_id;
    productCtl.type = isHome;
    [self.navigationController pushViewController:productCtl animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
