//
//  TakeoutStoreModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/10.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseModel.h"

#pragma mark - ** 菜单左边分类列表 *
@interface TakeoutStoreModel : NSObject

/** 分类id */
@property(nonatomic,assign)int cate_id;
/** 分类名 */
@property (nonatomic,copy) NSString *cate_name;
/** 商品数组 */
@property(nonatomic,strong)NSArray *foods;

/** 气泡数量 */
@property(nonatomic,assign)NSInteger bageNumber;

@end


#pragma mark - ** 菜单右边列表 *
@interface TakeoutLeftModel : BaseModel

/** 商品id */
@property(nonatomic,assign)int pro_id;
/** 分类id */
@property(nonatomic,assign)int cate_id;
/** 销量 */
@property(nonatomic,assign)int number;
/** 价格 */
@property(nonatomic,copy)NSString *price;
/** 商品名 */
@property (nonatomic,copy) NSString *pro_name;
/** logo_url */
@property (nonatomic,copy) NSString *logo_url;

/** 点商品数量 */
@property(nonatomic,assign)NSInteger countNumber;

#pragma  mark - 计算数量
+(NSInteger) CountOthersWithorderData:(NSMutableArray *)ordersArray;
#pragma  mark - 计算价格
+(double)GetTotalPrice:(NSMutableArray *)dataArray;

@end

#pragma mark - 商铺信息
@interface  TakeoutStoreInfoModel: BaseModel

/** logo_url */
@property (nonatomic,copy) NSString *s_logo;
/** xx起送 */
@property (nonatomic,copy) NSString *send_price;
/** 配送费 */
@property (nonatomic,copy) NSString *delivery;
/** 活动 */
@property (nonatomic,strong) NSArray *discounts;
/** 配送时间 */
@property (nonatomic,assign) int send_time;
/** 饭盒价格 */
@property(nonatomic,assign)float box_price;
/** 时间 */
@property(nonatomic,strong)NSArray *times;

@end
