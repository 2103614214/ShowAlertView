//
//  KtvActivityCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KtvActivityCell : UITableViewCell

@end
