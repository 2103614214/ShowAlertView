//
//  OverlayView.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "OverlayView.h"
#import "TakeoutStoreHeadView.h"
#import "TakeoutStoreModel.h"
@implementation OverlayView
{
    UIImageView *_logoV;
    UILabel *_nameLabel;
    UILabel *_remarkLabel;
    UILabel *_priceLabel;
    UILabel *_numberLabel;
    UIButton *_subBtn;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
    }
    return self;
}

-(void)setupUI{
    
    UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(25, SCREEN_HEIGHT*0.2, SCREEN_WIDTH-50, SCREEN_HEIGHT*0.6)];
    bgView.backgroundColor = [UIColor whiteColor];
    bgView.layer.cornerRadius = 10;
    bgView.layer.masksToBounds = YES;
    [self addSubview:bgView];
    
    UIImageView *logoV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, bgView.width, bgView.height*0.7)];
    [bgView addSubview:logoV];
    _logoV = logoV;
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:19 numberOfLines:1 text:@""];
    [bgView addSubview:nameLabel];
    nameLabel.sd_layout
    .topSpaceToView(logoV, bgView.height*0.01)
    .xIs(20)
    .widthIs(bgView.width-40)
    .heightIs(bgView.height*0.1);
    _nameLabel = nameLabel;
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
    [bgView addSubview:remarkLabel];
    remarkLabel.sd_layout
    .topSpaceToView(nameLabel, 0)
    .xIs(20)
    .widthIs(120)
    .heightIs(bgView.height*0.05);
    _remarkLabel = remarkLabel;
    
    UILabel *priceLabel = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:20 numberOfLines:1 text:@"22"];
    [bgView addSubview:priceLabel];
    priceLabel.sd_layout
    .topSpaceToView(remarkLabel, bgView.height*0.02)
    .xIs(20)
    .widthIs(bgView.width-40)
    .heightIs(bgView.height*0.1);
    _priceLabel = priceLabel;
    
    
    //加号
    float y = bgView.height*0.7+nameLabel.height+remarkLabel.height+bgView.height*0.02;
    UIButton *addBtn = [UIButton addBtnImage:@"menu_btn_add_23_23" WithTarget:self action:@selector(plusclick:)];
    addBtn.frame = CGRectMake(bgView.width-50, y, 30, 30);
    [bgView addSubview:addBtn];
    
    
    UILabel *numberLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@""];
    numberLabel.hidden = YES;
    numberLabel.textAlignment = NSTextAlignmentCenter;
    [bgView addSubview:numberLabel];
    numberLabel.sd_layout
    .rightSpaceToView(addBtn, 2)
    .yIs(y)
    .widthIs(30)
    .heightIs(30);
    _numberLabel = numberLabel;
    
    //减号
    UIButton *subBtn = [UIButton addBtnImage:@"menu_btn_reduce_23_23" WithTarget:self action:@selector(minusclick:)];
    subBtn.hidden = YES;
    [bgView addSubview:subBtn];
    subBtn.sd_layout
    .rightSpaceToView(numberLabel, 2)
    .yIs(y)
    .widthIs(30)
    .heightIs(30);
    _subBtn = subBtn;
    
}

-(void)setModel:(TakeoutLeftModel *)model{
    
    [_logoV sd_setImageWithURL:[NSURL URLWithString:model.logo_url] placeholderImage:[UIImage imageNamed:placeImageName]];
    _nameLabel.text = [NSString stringWithFormat:@"%@",model.pro_name];
    _priceLabel.text = [NSString stringWithFormat:@"¥ %@",model.price];
    _remarkLabel.text = [NSString stringWithFormat:@"月销售%d",model.number];
    if (model.countNumber > 0) {
        _subBtn.hidden = NO;
        _numberLabel.hidden = NO;
         _numberLabel.text = [NSString stringWithFormat:@"%ld",model.countNumber];
    }
}

- (void)minusclick:(id)sender {
    self.number =[_numberLabel.text integerValue];
    self.number -=1;
    if (self.number == 0) {
        _numberLabel.hidden = YES;
        _subBtn.hidden = YES;
    }
    [self showNumber:self.number];
    self.operationBlock(self.number,NO);
}

- (void)plusclick:(id)sender {
    
    _numberLabel.hidden = NO;
    _subBtn.hidden = NO;
    
    self.number =[_numberLabel.text integerValue];
    self.number += 1;
    [self showNumber:self.number];
    self.operationBlock(self.number,YES);
    
}

-(void)showNumber:(NSUInteger)count
{
    _numberLabel.text = [NSString stringWithFormat:@"%lu",(unsigned long)self.number];
}


-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    UITouch *touch = [touches anyObject];
    UIView *view = touch.view;
    if (self.type == isFoodsDetailsPage && view.tag == 7777) {
        self.removeOverlayView();
    }else{
        [self.ShoppingCartView dismissAnimated:YES];
    }

}

@end
