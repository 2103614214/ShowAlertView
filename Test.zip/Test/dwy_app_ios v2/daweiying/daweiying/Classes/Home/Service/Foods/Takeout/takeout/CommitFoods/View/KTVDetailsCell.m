//
//  KTVDetailsCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/18.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "KTVDetailsCell.h"

@implementation KTVDetailsCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self initWithSubViews]; //初始化
    }
    return self;
}

-(void)initWithSubViews{
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
