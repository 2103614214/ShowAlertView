//
//  YXShoppingCartAnimaition.h
//  ks
//
//  Created by 汪亮 on 2017/4/5.
//  Copyright © 2017年 eddie. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^AnimationFinisnedBlock)(BOOL isFinished);
@interface YXShoppingCartAnimaition : NSObject


+(instancetype)shareTool;

- (void)startAnimationandView:(UIView *)animationView endView:(UIView *)endView finishBlock:(AnimationFinisnedBlock)completion;

@end
