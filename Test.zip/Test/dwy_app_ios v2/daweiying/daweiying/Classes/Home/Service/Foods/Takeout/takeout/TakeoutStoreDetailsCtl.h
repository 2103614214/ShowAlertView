//
//  TakeoutStoreDetailsCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"
#import "OverlayView.h"
@interface TakeoutStoreDetailsCtl : BaseViewController
{
        
        NSInteger _selectIndex;
        BOOL _isScrollDown;
}


/** 店铺名 */
@property(nonatomic,copy)NSString *storeName;
/** 店铺id */
@property(nonatomic,assign)int s_id;
@property (nonatomic,strong) OverlayView *OverlayView;//遮罩图层

@end
