//
//  CommitFoodsCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/17.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CommitFoodsCell.h"
#import "TakeoutStoreModel.h"

@implementation CommitFoodsCell
{
    UILabel *_nameLabel;
    UILabel *_priceLabel;
    UILabel *_numberLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    nameLabel.frame = CGRectMake(15, 0, SCREEN_WIDTH/2, 21);
    [self addSubview:nameLabel];
    _nameLabel = nameLabel;
    
    UILabel *priceLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    priceLabel.textAlignment = NSTextAlignmentRight;
    priceLabel.frame = CGRectMake(SCREEN_WIDTH-120, 0, 105, 21);
    [self addSubview:priceLabel];
    _priceLabel = priceLabel;
    
    UILabel *numberLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    numberLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:numberLabel];
    numberLabel.sd_layout
    .yIs(0)
    .rightSpaceToView(priceLabel, 5)
    .widthIs(100)
    .heightIs(21);
    _numberLabel = numberLabel;

    
}

-(void)setModel:(TakeoutLeftModel *)model{
    _model = model;
    
    _nameLabel.text = model.pro_name;
    _numberLabel.text = [NSString stringWithFormat:@"x%ld",model.countNumber];
    _priceLabel.text = [NSString stringWithFormat:@"¥%@",model.price];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
