//
//  CommitFoodsHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/16.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CommitFoodsHeadView.h"

@implementation CommitFoodsHeadView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initWithSubViews]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews{
    
    //选择收货地址
    float y = 5;
    float ViewH = 49;
    float marge = 15;
    UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0, y, SCREEN_WIDTH, ViewH*1.5)];
    view1.backgroundColor = [UIColor whiteColor];
    [self addSubview:view1];
    
    UILabel *areaLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"请选择收货地址"];
    areaLabel.numberOfLines = 2;
    areaLabel.adjustsFontSizeToFitWidth = YES;
    areaLabel.frame = CGRectMake(marge, 0, SCREEN_WIDTH-marge-30, ViewH*1.5-1);
    [view1 addSubview:areaLabel];
    
    CGRect rect = CGRectMake(SCREEN_WIDTH-30, (ViewH*1.5-20)/2, 20, 20);
    UIImageView *pullImageV1 = [self pullImageView:rect];
    [view1 addSubview:pullImageV1];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(marge, areaLabel.height, SCREEN_WIDTH-marge, 1);
    [view1 addSubview:line];
    
    //送达时间
    y+= view1.height;
    UIView *view2 = [[UIView alloc] initWithFrame:CGRectMake(0, y, SCREEN_WIDTH, ViewH)];
    view2.backgroundColor = [UIColor whiteColor];
    [self addSubview:view2];
    
    UILabel *sendLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"送达时间"];
    sendLabel.frame = CGRectMake(marge, 0, 80, ViewH);
    [view2 addSubview:sendLabel];
    
    rect = CGRectMake(SCREEN_WIDTH-30, (ViewH-20)/2, 20, 20);
    UIImageView *pullImageV2 = [self pullImageView:rect];
    [view2 addSubview:pullImageV2];
    
    //支付方式
    y+= 54;
    UIView *view3 = [[UIView alloc] initWithFrame:CGRectMake(0, y, SCREEN_WIDTH, ViewH)];
    view3.backgroundColor = [UIColor whiteColor];
     [self addSubview:view3];
    
    UILabel *payTypeLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"支付方式"];
    payTypeLabel.frame = CGRectMake(marge, 0, 80, ViewH);
    [view3 addSubview:payTypeLabel];
    
    UIImageView *pullImageV3 = [self pullImageView:rect];
    [view3 addSubview:pullImageV3];
    
    
    //备注
    y+= 54;
    UIView *view4 = [[UIView alloc] initWithFrame:CGRectMake(0, y, SCREEN_WIDTH, ViewH)];
    view4.backgroundColor = [UIColor whiteColor];
     [self addSubview:view4];
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"备注"];
    remarkLabel.frame = CGRectMake(marge, 0, 80, ViewH);
    [view4 addSubview:remarkLabel];
    
    UIImageView *pullImageV4 = [self pullImageView:rect];
    [view4 addSubview:pullImageV4];

    
}

-(UIImageView *)pullImageView:(CGRect)rect{
    UIImage *img = [UIImage imageNamed:@"shopstore_btn_goto_13_13"];
    UIImageView *imageV = [[UIImageView alloc] initWithFrame:rect];
    [imageV setImage:img];
    
    return imageV;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

#pragma mark - 底部view
@implementation CommitFoodsFootView
{
    UILabel *_totalPrice;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xd9d9d9];
    line.frame = CGRectMake(0, 0, SCREEN_WIDTH, 1);
    [self addSubview:line];
    
    UILabel *total = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"合计:"];
    total.frame = CGRectMake(15, 0, 40, self.height);
    [self addSubview:total];
    
    UILabel *totalPrice = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:15 numberOfLines:1 text:@"¥ 0.00"];
    [self addSubview:totalPrice];
    totalPrice.sd_layout
    .leftSpaceToView(total, 10)
    .yIs(0)
    .widthIs(130)
    .heightIs(self.height);
    _totalPrice = totalPrice;

    
    float countBtnW = 130;
    UIButton *countBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-countBtnW-10, 10, countBtnW, self.height-20)];
    [countBtn setTitle:@"立即下单" forState:0];
    countBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    countBtn.layer.cornerRadius = 3;
    countBtn.layer.masksToBounds = YES;
    countBtn.backgroundColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
    [self addSubview:countBtn];
    self.countBtn = countBtn;
    

}

-(void)setTotalPriceStr:(NSString *)totalPriceStr{
    _totalPriceStr = totalPriceStr;
    
    NSString *Str = [NSString stringWithFormat:@"¥ %@",_totalPriceStr];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:Str];
    
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial Rounded MT Bold"  size:(15.0)]range:NSMakeRange(0, 1)];
    
    _totalPrice.attributedText= aString;
    
}

@end


#pragma mark - tabelview 底部view
@implementation TabelFoodsFootView
{
    UILabel *_boxPriceLabel;
    UILabel *_sendPriceLabel;
    UILabel *_totalLabel;
}


-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(15, 10, SCREEN_WIDTH-15, 1);
    [self addSubview:line];
    
    UILabel *infoLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"餐盒费"];
    [self addSubview:infoLabel];
    infoLabel.sd_layout
    .topSpaceToView(line, 15)
    .xIs(15)
    .widthIs(100)
    .heightIs(21);
    
    UILabel *boxPriceLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@""];
    boxPriceLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:boxPriceLabel];
    boxPriceLabel.sd_layout
    .topSpaceToView(line, 15)
    .xIs(SCREEN_WIDTH-100)
    .widthIs(85)
    .heightIs(21);
    _boxPriceLabel = boxPriceLabel;
    
    UILabel *sendLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"配送费"];
    [self addSubview:sendLabel];
    sendLabel.sd_layout
    .topSpaceToView(infoLabel, 0)
    .xIs(15)
    .widthIs(100)
    .heightIs(21);
    
    UILabel *sendPriceLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@""];
    sendPriceLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:sendPriceLabel];
    sendPriceLabel.sd_layout
    .topSpaceToView(infoLabel, 0)
    .xIs(SCREEN_WIDTH-100)
    .widthIs(85)
    .heightIs(21);
    _sendPriceLabel = sendPriceLabel;
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line1.frame = CGRectMake(15, 49*1.5+10, SCREEN_WIDTH-15, 1);
    [self addSubview:line1];
    
    UILabel *totalLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"小计 ¥69"];
    totalLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:totalLabel];
    totalLabel.sd_layout
    .topSpaceToView(line1, 0)
    .xIs(SCREEN_WIDTH-160)
    .widthIs(145)
    .heightIs(49);
    _totalLabel = totalLabel;
}

-(void)setDict:(NSDictionary *)dict{
    _dict = dict;
    
    _boxPriceLabel.text = [NSString stringWithFormat:@"¥%@",[dict objectForKey:@"boxPrice"]];
    _sendPriceLabel.text = [NSString stringWithFormat:@"¥%@",[dict objectForKey:@"freight"]];
    
    NSString *str = [NSString stringWithFormat:@"小计 ¥%@",[dict objectForKey:@"totalPrice"]];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:str];
    [aString addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor]range:NSMakeRange(0, 2)];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial Rounded MT Bold"  size:(15.0)]range:NSMakeRange(0, 2)];
    
    _totalLabel.attributedText= aString;
  
}

@end
