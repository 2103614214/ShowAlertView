//
//  DWYServeHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYServeHeadView.h"


@interface DWYServeHeadView() <SDCycleScrollViewDelegate>


@end


#define CURRENT_SIZE(_size) _size / 375.0 * SCREEN_WIDTH

@implementation DWYServeHeadView
{
    //分类
    UIImageView *_leftImageView;
    UIImageView *_middleImageView;
    UIImageView *_rightImageView;
    
    UILabel *_leftLabel;
    UILabel *_middleLabel;
    UILabel *_rightLabel;
    
    //活动
    UIImageView  *_leftAvImageV;
    UIImageView  *_rightAvImageV;
    
    //优选
    UIImageView *_imageView1;
    UIImageView *_imageView2;
    UIImageView *_imageView3;
    UIImageView *_imageView4;
    UIImageView *_imageView5;
    UIImageView *_imageView6;
    
    UILabel *_nameLabel1;
    UILabel *_nameLabel2;
    UILabel *_nameLabel3;
    UILabel *_nameLabel4;
    UILabel *_nameLabel5;
    UILabel *_nameLabel6;
    
    UILabel *_introduceLabel1;
    UILabel *_introduceLabel2;
    UILabel *_introduceLabel3;
    UILabel *_introduceLabel4;
    UILabel *_introduceLabel5;
    UILabel *_introduceLabel6;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}
// 0.25 0.15 0.15 0.45 0.07
//166.75--100.05--100.05--200.10--46.69   iphone6
-(void)initWithSubViews{
    self.backgroundColor = [UIColor clearColor];

//    UIImageView *headImageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.25)];
//    [self addSubview:headImageV];
    
    //设置轮播图
    self.cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.25) delegate:self placeholderImage:[UIImage imageNamed:@""]];
    
    self.cycleScrollView.autoScrollTimeInterval = 3.0;
    _cycleScrollView.currentPageDotColor = [UIColor whiteColor];
    _cycleScrollView.pageDotColor = [UIColor colorWithHex:0xffffff alpha:0.5];
    _cycleScrollView.pageControlDotSize = CGSizeMake(8, 8);
    
    // 不设置标题
    self.cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleClassic;
    self.cycleScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
    
    self.cycleScrollView.bannerImageViewContentMode = UIViewContentModeScaleToFill;
    [self addSubview:self.cycleScrollView];
    //[SDCycleScrollView clearImagesCache]; 自动清楚缓存
    
    //分类
    UIView *categoryView = [UIView new];
    categoryView.backgroundColor = [UIColor whiteColor];
    [self addSubview:categoryView];
    categoryView.sd_layout
    .topSpaceToView(self.cycleScrollView, 0)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(SCREEN_HEIGHT*0.15);
    
    for (int i=0; i<3; i++) {
        
        
        UIView * vi = [[UIView alloc] initWithFrame:CGRectMake((SCREEN_WIDTH / 3.0 ) * i, 0, SCREEN_WIDTH / 3.0, categoryView.height)];
        
        UIImageView * imageV = [[UIImageView alloc] initWithFrame:CGRectMake(vi.width/3, CURRENT_SIZE(15), vi.width/3, vi.width/3)];
        
        vi.userInteractionEnabled = YES;
        vi.tag = 100 +i;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            //触发点击事件
            if (self.delegate && [self.delegate respondsToSelector:@selector(viewDidClick:selectIndex:)]) {
                [self.delegate viewDidClick:@"category" selectIndex:vi.tag];
            }
        }];
        [vi addGestureRecognizer:tap];
        [vi addSubview:imageV];
        
        UILabel * label = [[UILabel alloc] init];
        label.font = [UIFont systemFontOfSize:14];
        label.textColor = [UIColor grayColor];
        label.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:label];
        label.sd_layout
        .topSpaceToView(imageV, 10)
        .centerXEqualToView(imageV)
        .widthIs(SCREEN_HEIGHT / 3)
        .heightIs(15);
        
        [categoryView addSubview:vi];
        
        if (i == 0) {
            _leftImageView = imageV;
            _leftLabel = label;
        }else if (i == 1){
            _middleImageView = imageV;
            _middleLabel = label;
        }else if (i == 2){
            _rightImageView = imageV;
            _rightLabel = label;
        }else{
            return;
        }
        
    }

    
    
    //活动页
    UIView *activityView = [UIView new];
    activityView.backgroundColor = [UIColor whiteColor];
    [self addSubview:activityView];
    activityView.sd_layout
    .topSpaceToView(categoryView, 5)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(SCREEN_HEIGHT*0.15);
    
    
    float avImageW = (activityView.width-15)/2;
    float avImageH = (activityView.height-10);
    UIImageView *leftAvImageV = [[UIImageView alloc] initWithFrame:CGRectMake(5, 5, avImageW, avImageH)];
    leftAvImageV.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
    [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
        //触发点击事件
        if (self.delegate && [self.delegate respondsToSelector:@selector(viewDidClick:selectIndex:)]) {
            [self.delegate viewDidClick:@"activityView" selectIndex:100];
        }
    }];
    [leftAvImageV addGestureRecognizer:tap1];
    [activityView addSubview:leftAvImageV];
    _leftAvImageV = leftAvImageV;
    
    UIImageView *rightAvImageV = [[UIImageView alloc] initWithFrame:CGRectMake(avImageW+10, 5, avImageW, avImageH)];
    rightAvImageV.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] init];
    [[tap2 rac_gestureSignal] subscribeNext:^(id x) {
        //触发点击事件
        if (self.delegate && [self.delegate respondsToSelector:@selector(viewDidClick:selectIndex:)]) {
            [self.delegate viewDidClick:@"activityView" selectIndex:101];
        }
    }];
    [rightAvImageV addGestureRecognizer:tap2];
    [activityView addSubview:rightAvImageV];
    _rightAvImageV = rightAvImageV;
    
    
    //品牌优选
    UIView *chooseView = [UIView new];
    chooseView.backgroundColor = [UIColor whiteColor];
    [self addSubview:chooseView];
    chooseView.sd_layout
    .topSpaceToView(activityView, 5)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(SCREEN_HEIGHT*0.45);
    
    UILabel *titleLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@"品牌优选"];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.frame = CGRectMake((SCREEN_WIDTH-100)/2, 0, 100, chooseView.height*0.15);
    [chooseView addSubview:titleLabel];
    
    float chooseViewH = (chooseView.height-titleLabel.height)/2;
    for (int i=0; i<6; i++) {
        
        
        UIView * vi = [[UIView alloc] init];
        vi.userInteractionEnabled = YES;
        vi.tag = 100 +i;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            //触发点击事件
            if (self.delegate && [self.delegate respondsToSelector:@selector(viewDidClick:selectIndex:)]) {
                [self.delegate viewDidClick:@"chooseView" selectIndex:vi.tag];
            }
        }];
        [vi addGestureRecognizer:tap];
   
        [chooseView addSubview:vi];
        
        if (i < 3) {
            
            vi.sd_layout
            .topSpaceToView(titleLabel, 0)
            .xIs((SCREEN_WIDTH-2)/3*i+2)
            .widthIs((SCREEN_WIDTH-10)/3)
            .heightIs(chooseViewH);
        }else if (i>2 && i<6){
            vi.sd_layout
            .yIs(titleLabel.height+chooseViewH+2)
            .xIs((SCREEN_WIDTH-2)/3*(i-3)+2)
            .widthIs((SCREEN_WIDTH-10)/3)
            .heightIs(chooseViewH);
        }
        
        UIImageView * imageV = [[UIImageView alloc] init];
        float imageVW = vi.width*0.5;
        imageV.frame = CGRectMake(vi.width*0.25, 5, imageVW, imageVW);
        imageV.layer.cornerRadius = imageV.height/2;
        imageV.layer.masksToBounds = YES;
        imageV.layer.borderWidth = 1;
        imageV.layer.borderColor = [UIColor colorWithHex:0xeeeeee].CGColor;
        [vi addSubview:imageV];
        
        UILabel *namelabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
        namelabel.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:namelabel];
        namelabel.sd_layout
        .topSpaceToView(imageV, 5)
        .xIs(4)
        .widthIs(vi.width-8)
        .heightIs(18);
        
        UILabel *introducelabel = [Utils labelTextColor:[UIColor grayColor] fontSize:11 numberOfLines:1 text:@""];
        introducelabel.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:introducelabel];
        introducelabel.sd_layout
        .topSpaceToView(namelabel, 2)
        .xIs(4)
        .widthIs(vi.width-8)
        .heightIs(18);
        
        if (i == 0) {
            _imageView1 = imageV;
            _nameLabel1 = namelabel;
            _introduceLabel1 = introducelabel;
        }else if (i == 1){
            _imageView2 = imageV;
            _nameLabel2 = namelabel;
            _introduceLabel2 = introducelabel;
        }else if (i == 2){
            _imageView3 = imageV;
            _nameLabel3 = namelabel;
            _introduceLabel3= introducelabel;
        }else if (i == 3){
            _imageView4 = imageV;
            _nameLabel4 = namelabel;
            _introduceLabel4 = introducelabel;
        }else if (i == 4){
            _imageView5 = imageV;
            _nameLabel5 = namelabel;
            _introduceLabel5= introducelabel;
        }else if (i == 5){
            _imageView6 = imageV;
            _nameLabel6 = namelabel;
            _introduceLabel6 = introducelabel;
        }else{
            return;
        }
        
    }

    
}

//分类模型赋值
-(void)setCateArray:(NSArray *)cateArray{
    _cateArray = cateArray;
    
    for (int i = 0; i <_cateArray.count; i++) {
        DWYCategoryModel *model = _cateArray[i];
        if (i == 0) {
            [_leftImageView sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _leftLabel.text = model.cate_name;
        }else if (i == 1){
            [_middleImageView sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _middleLabel.text = model.cate_name;
        }else if (i == 2){
            [_rightImageView sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _rightLabel.text = model.cate_name;
        }else{
            return;
        }
    }
}

-(void)setActivityArray:(NSArray *)activityArray{
    _activityArray = activityArray;
    
    for (int i = 0; i <_activityArray.count; i++) {
        ActivityModel *model = _activityArray[i];
        if (i == 0) {
            [_leftAvImageV sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else if (i == 1){
            [_rightAvImageV sd_setImageWithURL:[NSURL URLWithString:model.t_img_url] placeholderImage:[UIImage imageNamed:placeImageName]];
        }else{
            return;
        }
    }
}

-(void)setChooseArray:(NSArray *)chooseArray{
    _chooseArray = chooseArray;
    for (int i =0; i < _chooseArray.count; i++) {
        ChooseModel *model = _chooseArray[i];
        if (i == 0) {
            [_imageView1 sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel1.text = model.s_name;
            _introduceLabel1.text = model.s_introduce;
        }else if (i == 1){
            [_imageView2 sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel2.text = model.s_name;
            _introduceLabel2.text = model.s_introduce;
        }else if (i == 2){
            [_imageView3 sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel3.text = model.s_name;
            _introduceLabel3.text = model.s_introduce;
        }else if (i == 3){
            [_imageView4 sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel4.text = model.s_name;
            _introduceLabel4.text = model.s_introduce;
        }else if (i == 4){
            [_imageView5 sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel5.text = model.s_name;
            _introduceLabel5.text = model.s_introduce;
        }else if (i == 5){
            [_imageView6 sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel6.text = model.s_name;
            _introduceLabel6.text = model.s_introduce;
        }else{
            
            return;
        }
    }
}

//移除通知方法
- (void)willMoveToWindow:(UIWindow *)newWindow {
    if (newWindow == nil) {
        // Will be removed from window, similar to -viewDidUnload.
        // Unsubscribe from any notifications here.
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"ServeNotification" object:nil];
    }
    
}

//添加通知方法
- (void)didMoveToWindow {
    if (self.window) {
        // Added to a window, similar to -viewDidLoad.
        // Subscribe to notifications here.
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(AdvDataSource:) name:@"ServeNotification" object:nil];
    }
    
}

-(void)AdvDataSource:(NSNotification *)noti{
    NSMutableArray *array = [NSMutableArray array];
    NSArray *arr = noti.object;
    for (int i =0; i <arr.count; i++) {
        ADVModel *model = arr[i];
        [array addObject:model.b_logo];
    }
    
    self.cycleScrollView.imageURLStringsGroup = array;
}

/** 点击图片回调 */
- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    DLog(@"%ld",index);
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
