//
//  TakeoutModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/29.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TakeoutModel : NSObject

@property (nonatomic,copy) NSString *s_name;
@property (nonatomic,copy) NSString *s_logo;
@property (nonatomic,assign) int s_id;
@property (nonatomic,copy) NSString *s_introduce;
@property (nonatomic,copy) NSString *s_place;
@property (nonatomic,assign) int grade;
@property (nonatomic,copy) NSString *longitude;
@property (nonatomic,copy) NSString *latitude;

@property (nonatomic,copy) NSString *send_price;
@property (nonatomic,assign) int delivery;

@end

/** 分类 */
@interface TakeoutCategoryModel : NSObject


@property(nonatomic,assign)int cate_id;
@property(nonatomic,assign)int type;
@property (nonatomic,copy) NSString *cate_name;
@property (nonatomic,copy) NSString *cate_url;


@end

/** 推荐商家 */
@interface RecStoresModel : NSObject

@property(nonatomic,assign)int s_id;
@property (nonatomic,copy) NSString *s_name;
@property (nonatomic,copy) NSString *s_introduce;
@property (nonatomic,copy) NSString *recommend_img;

@end

