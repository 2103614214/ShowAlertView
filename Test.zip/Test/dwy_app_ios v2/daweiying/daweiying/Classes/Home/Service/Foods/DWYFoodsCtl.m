//
//  DWYFoodsCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/28.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYFoodsCtl.h"
#import "WZBSegmentedControl.h"
#import "DWYServeCell.h"
#import "DWYServeModel.h"

#import "DWYFoodsStoreCtl.h"
#import "KtvViewCtl.h"

@interface DWYFoodsCtl () <UITableViewDelegate,UITableViewDataSource>

// 可滑动的segmentedControl
@property (nonatomic, strong) WZBSegmentedControl *sectionView;
/** tabbleview */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 总页数 */
@property (nonatomic, assign) NSInteger page_total;

@end

static NSString * const FoodsCellID = @"FoodsCellID";
@implementation DWYFoodsCtl

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 45, SCREEN_WIDTH, SCREEN_HEIGHT-45)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = kHeight(100);
        _tableView.tableHeaderView = [UIView new];
        _tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        _tableView.showsVerticalScrollIndicator = NO;
        [_tableView registerClass:[DWYServeCell class] forCellReuseIdentifier:FoodsCellID];
    }
    return _tableView;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (self.type == isFoodsPage) {
        
        self.title = @"美食";
        UIButton *findBtn = [UIButton new];
        findBtn.frame = CGRectMake(0, 0, 30, 30);
        [findBtn setImage:[UIImage imageNamed:@"food_btn_search_22_22"] forState:0];
        UIBarButtonItem *find = [[UIBarButtonItem alloc] initWithCustomView:findBtn];
        self.navigationItem.rightBarButtonItem = find;
    }else if (self.type == isKtvPage){
        self.title = @"KTV";
    }
    
    [self.view addSubview:self.tableView];
    
    [self initWithHeadViews]; //初始化头部按钮
    
    
    // 添加刷新控件
    [self setupRefresh];
}

-(void)initWithHeadViews{
    // 创建segmentedControl    //滑块
    __weak typeof (self)weakSelf = self;
    WZBSegmentedControl *sectionView = [WZBSegmentedControl segmentWithFrame:(CGRect){0, 64, SCREEN_WIDTH, 44} titles:@[@"离我最近", @"平台推荐", @"好评优先",@"人气最高"] tClick:^(NSInteger index) {
        
        weakSelf.sectionView.backgroundView.frame = CGRectMake((SCREEN_WIDTH/4)*index, 44-1.5, SCREEN_WIDTH/4, 1.5);
    }];
    self.sectionView = sectionView;
    // 设置其他颜色
    [sectionView setNormalColor:[UIColor grayColor] selectColor:[UIColor colorWithHex:0xf67100] sliderColor:[UIColor colorWithHex:0xf67100] edgingColor:[UIColor clearColor] edgingWidth:0];
    sectionView.backgroundColor = [UIColor whiteColor];
    // 去除圆角
    sectionView.layer.cornerRadius = sectionView.backgroundView.layer.cornerRadius = .0f;
    
    // 调下frame
    CGRect frame = sectionView.backgroundView.frame;
    frame.origin.y = frame.size.height - 1.5;
    frame.size.height = 1;
    sectionView.backgroundView.frame = frame;
    [self.view addSubview:self.sectionView];
}


-(void)setupRefresh{
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    [self.tableView.mj_header beginRefreshing];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
    //self.collectionView.mj_footer.ignoredScrollViewContentInsetBottom = 0;
}

//请求数据
-(void)loadData{
    
    // 结束上啦
    [self.tableView.mj_footer endRefreshing];
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    NSString *urlStr;
    if (self.type == isFoodsPage) {
        
        urlStr = [Utils getMemberServiceUri:@"cate"];
    }else if (self.type == isKtvPage){
        urlStr = [Utils getMemberServiceUri:@"ktv"];
    }
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        //NSLog(@"%@",responseObject);
        [MBManager hideAlert];
        
        [self.tableView.mj_header endRefreshing];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
   
            //列表数据源
            NSDictionary *storesDict = [NSDictionary dictionary];
            if (self.type == isFoodsPage) {
                
                storesDict = [dataObject objectForKey:@"stores"];
                
            }else if (self.type == isKtvPage){
                storesDict = [dataObject objectForKey:@"ktvs"];
            }
            self.dataArray = [DWYServeModel mj_objectArrayWithKeyValuesArray:storesDict];
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.tableView.mj_header endRefreshing];
    }];
}

//加载更多
-(void)loadMoreDatas{
    
    // 结束下拉
    [self.tableView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"没有更多数据了"];
        [self.tableView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr;
    if (self.type == isFoodsPage) {
        
        urlStr = [Utils getMemberServiceUri:@"cate"];
    }else if (self.type == isKtvPage){
        urlStr = [Utils getMemberServiceUri:@"ktv"];
    }
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *storesDict = [NSDictionary dictionary];
            if (self.type == isFoodsPage) {
                
                storesDict = [dataObject objectForKey:@"stores"];
                
            }else if (self.type == isKtvPage){
                storesDict = [dataObject objectForKey:@"ktvs"];
            }
            NSArray *newProducts = [DWYServeModel mj_objectArrayWithKeyValuesArray:storesDict];
            [self.dataArray addObjectsFromArray:newProducts];
            
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.tableView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.tableView.mj_footer endRefreshing];
    }];
    
}



#pragma mark - UITableView 代理，数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DWYServeCell *cell = [tableView dequeueReusableCellWithIdentifier:FoodsCellID];
    if (!cell) {
        cell = [[DWYServeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:FoodsCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    if (self.type == isKtvPage) {
        cell.rView.hidden = YES;
        cell.priceLabel.hidden = NO;
    }
    cell.model = self.dataArray[indexPath.row];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DWYServeModel *model = self.dataArray[indexPath.row];
    if (self.type == isFoodsPage) { //美食
        DWYFoodsStoreCtl *FoodStore = [DWYFoodsStoreCtl new];
        FoodStore.storeID = model.s_id;
        [self.navigationController pushViewController:FoodStore animated:YES];
    }else{ //ktv
        KtvViewCtl *vc = [[KtvViewCtl alloc] init];
        vc.model = model;
        [self.navigationController pushViewController:vc animated:YES];
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
