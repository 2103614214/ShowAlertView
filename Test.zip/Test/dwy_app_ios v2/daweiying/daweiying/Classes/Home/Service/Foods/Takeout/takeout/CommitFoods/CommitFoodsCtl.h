//
//  CommitFoodsCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/16.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"

@interface CommitFoodsCtl : BaseViewController

/** 数据源 */
@property(nonatomic,strong)NSArray *dataArray;

/** 订单提交所需数据 */
@property(nonatomic,strong)NSDictionary *commitDict;
@end
