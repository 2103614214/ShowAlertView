//
//  DWYServeModel.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYServeModel.h"

@implementation DWYServeModel

@end


//分类
@implementation DWYCategoryModel



@end

//活动页
@implementation ActivityModel



@end

//品牌优选
@implementation ChooseModel



@end

/* 轮播头部广告 */
@implementation ADVModel



@end
