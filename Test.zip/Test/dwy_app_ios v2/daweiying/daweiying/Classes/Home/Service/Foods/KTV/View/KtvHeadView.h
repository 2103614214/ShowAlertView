//
//  KtvHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/17.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DWYServeModel.h"

@interface KtvHeadView : UIView

/** 数据模型 */
@property(nonatomic,strong)DWYServeModel *model;

@end
