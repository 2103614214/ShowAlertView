//
//  DWYCommentCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/29.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYFoodsCommentCell.h"
#import "RatingView.h"
#import "DWYCommentModel.h"

@implementation DWYFoodsCommentCell
{
    UIImageView *_imgV;
    UILabel *_nameLabel;
    UILabel *_timeLabel;
    RatingView *_rView;
    UILabel *_commentLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initWithSubViews]; //初始化控件
    }
    return self;
}


-(void)initWithSubViews{
    
    UIImage *img = [UIImage imageNamed:@"shopstore_img_logo_45_45"];
    UIImageView *imgV = [[UIImageView alloc] initWithFrame:CGRectMake(20, 10, 45, 45)];
    [imgV setImage:img];
    imgV.layer.borderColor = [UIColor colorWithHex:UI_COLOR_GRAY].CGColor;
    imgV.layer.borderWidth = 0.5;
    imgV.layer.cornerRadius = imgV.height/2;
    imgV.layer.masksToBounds = YES;
    [self addSubview:imgV];
    _imgV = imgV;
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"一个sam"];
    nameLabel.frame = CGRectMake(75, 10, 150, 21);
    [self addSubview:nameLabel];
    _nameLabel = nameLabel;
    
    UILabel *timeLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"2017-09-01"];
    timeLabel.textAlignment = NSTextAlignmentRight;
    timeLabel.adjustsFontSizeToFitWidth = YES;
    timeLabel.frame = CGRectMake(SCREEN_WIDTH-160, 10, 150, 21);
    [self addSubview:timeLabel];
    _timeLabel = timeLabel;
    
    //评分
    RatingView *rView = [[RatingView alloc]initWithFrame:CGRectMake(75, 31, 90, 25) isEdit:NO];
    rView.ratingType = INTEGER_TYPE;//整颗星
    rView.score = 4;
    [self addSubview:rView];
    _rView = rView;
    
    UILabel *commentLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"adfkjasldjfslakjdflaksjdfkasjdfkjadfjsalkdfjladkjflasjdflksdfkjlk"];
    commentLabel.numberOfLines = 2;
    commentLabel.adjustsFontSizeToFitWidth = YES;
    commentLabel.frame = CGRectMake(75, 57, SCREEN_WIDTH-75-30, 42);
    [self addSubview:commentLabel];
    _commentLabel = commentLabel;
}

-(void)setTakeoutModel:(DWYCommentModel *)takeoutModel{
    _takeoutModel = takeoutModel;
    
    [_imgV sd_setImageWithURL:[NSURL URLWithString:takeoutModel.user_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
    _nameLabel.text = takeoutModel.username;
    _rView.score = takeoutModel.grade;
    _commentLabel.text = takeoutModel.c_content;
    
    _timeLabel.text = takeoutModel.c_time;
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
