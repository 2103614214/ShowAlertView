//
//  DWYFoodsStoreCtl.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/28.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "BaseViewController.h"
#import "BaseScrollViewController.h"

@interface DWYFoodsStoreCtl : BaseScrollViewController

/** 店铺id */
@property(nonatomic,assign)int storeID;

@end
