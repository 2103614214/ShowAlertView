//
//  TakeoutLeftCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/10.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TakeoutLeftModel;
@protocol numberDelegate;

@interface TakeoutLeftCell : UITableViewCell


@property (nonatomic,retain)UIButton *addBut;   //加号
@property (nonatomic,retain)UIButton *cutBut;   //减号
@property (nonatomic,retain)UILabel  *numberLab;  //数值

@property (nonatomic,assign) NSInteger number;

/** 模型  */
@property (nonatomic, strong)TakeoutLeftModel *model;

//增加减少订单数量 需不需要动画效果
@property (copy, nonatomic) void (^plusBlock)(NSInteger count,UIButton *btn);

@property (nonatomic,assign)id<numberDelegate>delegate;

@end

@protocol numberDelegate <NSObject>

- (void)customCell:(TakeoutLeftCell *)cell buttom:(UIButton *)but numberLab:(UILabel *)lab;


@end
