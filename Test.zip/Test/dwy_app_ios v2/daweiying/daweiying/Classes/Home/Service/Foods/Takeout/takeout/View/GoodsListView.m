//
//  GoodsListView.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GoodsListView.h"
#import "GoodslistCell.h"
#import "TakeoutStoreModel.h"

#import "TakeoutStoreHeadView.h"

static NSString * const GoodslistCellID = @"GoodslistCellID";
@implementation GoodsListView


-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSMutableArray *)objects{

     return [self initWithFrame:frame withObjects:objects canReorder:NO];
}

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSMutableArray *)objects canReorder:(BOOL)reOrder{

    self = [super initWithFrame:frame];
    
    if (self) {
        self.objects = [NSMutableArray arrayWithArray:objects];
        [self layoutUI];
    }
    return self;
}

-(void)layoutUI
{
    self.tableView = [[UITableView alloc] initWithFrame:self.bounds];
    self.tableView.bounces = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //注册cell
    [self.tableView registerClass:[GoodslistCell class] forCellReuseIdentifier:GoodslistCellID];
  

}

#pragma mark - TableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.objects count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
     return 50;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    GoodslistCell *cell = [tableView dequeueReusableCellWithIdentifier:GoodslistCellID forIndexPath:indexPath];
    if (!cell) {
        cell = [[GoodslistCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:GoodslistCellID];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;  //取消点击效果
    TakeoutLeftModel *model = self.objects[indexPath.row];
    cell.model = model;
    
   
    if (model.countNumber == 0) {
        
        
    }
    
    __weak typeof (self)weakSelf = self;
    cell.operationBlock=^(NSInteger number,BOOL plus){
        
        model.countNumber = number;
        
        if (number == 0) {
            [weakSelf.objects removeObjectAtIndex:indexPath.row];
            
            float height = [weakSelf.objects count] * 50 + 40+ 50;
            
            weakSelf.frame = CGRectMake(weakSelf.frame.origin.x, SCREEN_HEIGHT - height - 59, weakSelf.width, height);
            
            [weakSelf.tableView reloadData];
        }
        weakSelf.GoodListCellClick(weakSelf.objects);
        
    };
    return cell;

}

#define SECTION_HEIGHT 40.0
// 设置section的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    

        return SECTION_HEIGHT;

}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 50;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, SECTION_HEIGHT)];
    view.backgroundColor = [UIColor whiteColor];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(10, 0, SCREEN_WIDTH-10, 0.5);
    [view addSubview:line];
    
    UILabel *label = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"餐盒"];
    label.frame = CGRectMake(15, 0, 150, 50);
    [view addSubview:label];
    
    float boxPrice = self.objects.count*self.box_price;
    NSString *boxPriceStr = [NSString stringWithFormat:@"¥%.2f",boxPrice];
    UILabel *price = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:14 numberOfLines:1 text:boxPriceStr];
    price.textAlignment = NSTextAlignmentRight;
    price.frame = CGRectMake(SCREEN_WIDTH-135-80, 0, 80, 50);
    [view addSubview:price];
    
    
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, SECTION_HEIGHT)];
 

    // 已选商品
    UILabel *label = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"已选商品"];
    label.frame = CGRectMake(15, 0, 150, SECTION_HEIGHT);
    [view addSubview:label];
    
    
    // 清空
    UIButton *openList = [UIButton buttonWithType:UIButtonTypeCustom];
    openList.frame= CGRectMake(SCREEN_WIDTH-95, 0, 80, SECTION_HEIGHT);
    [openList setTitle:@"   清空" forState:UIControlStateNormal];
    [openList setImage:[UIImage imageNamed:@"shopaddress_btn_delet_18_18"] forState:UIControlStateNormal];
    [openList setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    openList.titleLabel.font = [UIFont systemFontOfSize:15];
    [openList setTitleEdgeInsets:UIEdgeInsetsMake(15, -openList.imageView.bounds.size.width + 15, 15, 0)];
    [openList setImageEdgeInsets:UIEdgeInsetsMake(8, 15, 10, 45)];   //40 * 40
    [openList addTarget:self action:@selector(clearShoppingCart:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:openList];

    view.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    return view;
}

#pragma mark - 弹窗
-(void)showAlertViewWithTitle:(NSString *)title{
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:title message:@"清空购物车?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    
    
    [alertView show];
}

-(void)clearShoppingCart:(UIButton *)sender
{

    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:@"清空购物车?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    
    
    [alertView show];

}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
  
    if (buttonIndex == 1 ) {
        
        //删除购物车数据
        [self.objects removeAllObjects];
        
        self.GoodListCellClick(self.objects);
    }
    
    
}




@end
