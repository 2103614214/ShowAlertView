//
//  DWYServeCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RatingView.h"
@class DWYServeModel;

@interface DWYServeCell : UITableViewCell

/** 模型 */
@property(nonatomic,strong)DWYServeModel *model;
/** 评星 */
@property(nonatomic,strong)RatingView *rView;
/** 价格 */
@property(nonatomic,strong)UILabel *priceLabel;

@end
