//
//  CommitFoodsCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/16.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "CommitFoodsCtl.h"
#import "CommitFoodsHeadView.h"
#import "CommitFoodsCell.h"


static NSString * const CommitFoodsID = @"CommitFoodsID";
@interface CommitFoodsCtl () <UITableViewDelegate,UITableViewDataSource>
/** headview */
@property(nonatomic,strong)CommitFoodsHeadView *headView;
/** footview */
@property(nonatomic,strong)CommitFoodsFootView *footView;
/** <#注释#> */
@property(nonatomic,strong)TabelFoodsFootView *tableViewFoodView;
/** tabblew */
@property(nonatomic,strong)UITableView *tableView;


@end

@implementation CommitFoodsCtl

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"确认订单";
    
    self.tableView = [self setupTableView];
    
    self.footView = [[CommitFoodsFootView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-59, SCREEN_WIDTH, 59)];
    [self.footView.countBtn addTarget:self action:@selector(orderForm) forControlEvents:(UIControlEventTouchUpInside)];
    self.footView.totalPriceStr = [self.commitDict objectForKey:@"totalPrice"];
    [self.view addSubview:self.footView];
    
}

-(UITableView *)setupTableView{
    
    self.headView = [[CommitFoodsHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 49*4.5+20)];
    self.tableViewFoodView = [[TabelFoodsFootView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 49*1.5+49+10)];
    self.tableViewFoodView.dict = self.commitDict;
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-59)];
    [self.view addSubview:tableView];
    tableView.backgroundColor = [UIColor colorWithHex:0xefeff4];
    tableView.showsVerticalScrollIndicator = NO;
    [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];   //移除分隔线
    tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero]; //去除多余分割线
    tableView.rowHeight = 25;
    // 代理&&数据源
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableHeaderView = self.headView;
    tableView.tableFooterView = self.tableViewFoodView;
    [tableView registerClass:[CommitFoodsCell class] forCellReuseIdentifier:CommitFoodsID];
    return tableView;
}

#pragma mark -- 提交订单
-(void)orderForm{
    NSLog(@"提交订单");
}

#pragma mark - UITableViewDelegate && UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CommitFoodsCell *cell = [tableView dequeueReusableCellWithIdentifier:CommitFoodsID forIndexPath:indexPath];
    if (!cell) {
        cell = [[CommitFoodsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CommitFoodsID];
    }
    cell.selectionStyle =  UITableViewCellSelectionStyleNone;
    //cell.backgroundColor = [UIColor colorWithWhite:0.998 alpha:1];
    cell.model = self.dataArray[indexPath.row];
 
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 59;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 49)];
    view.backgroundColor = [UIColor whiteColor];
    NSString *Str = [self.commitDict objectForKey:@"storeName"];
    UILabel *infoLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:Str];
    infoLabel.frame = CGRectMake(15, 0, SCREEN_WIDTH-25, 49-1);
    [view addSubview:infoLabel];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(15, infoLabel.height, SCREEN_WIDTH-15, 1);
    [view addSubview:line];
    
    return view;
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
