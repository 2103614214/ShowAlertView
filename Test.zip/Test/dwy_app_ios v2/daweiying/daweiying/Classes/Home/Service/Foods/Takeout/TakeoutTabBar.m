//
//  TakeoutTabBar.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/28.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutTabBar.h"
#import "UIBarButtonItem+CustomBarBtnItem.h"

#import "TakeoutCtl.h"
#import "TakeoutOrdersCtl.h"
#import "TakeoutAddressCtl.h"

@interface TakeoutTabBar ()<UITabBarControllerDelegate,UIGestureRecognizerDelegate,UINavigationControllerDelegate>

@property (nonatomic, strong) TakeoutCtl *oneVC;
@property (nonatomic, strong) TakeoutOrdersCtl *twoVC;
@property (nonatomic, strong) TakeoutAddressCtl *threeVC;

/** <#注释#> */
@property(nonatomic,strong)UIButton *backBtn;

@end

@implementation TakeoutTabBar

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //返回
    UIButton *backBtn = [UIButton new];
    backBtn.frame = CGRectMake(0, 0, 30, 30);
    [[backBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        
        [self back];
    }];
    [backBtn setImage:[UIImage imageNamed:@"login_btn_back_22_22"] forState:0];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = backItem;
    
    
    _oneVC = [TakeoutCtl new];
    _oneVC.tabBarItem.title =@"外卖";
    _oneVC.tabBarItem.image=[[UIImage imageNamed:@"orderfood_btn_orderfood2_25_25"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    _oneVC.tabBarItem.selectedImage = [[UIImage imageNamed:@"orderfood_btn_orderfood_25_25"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    _twoVC = [[TakeoutOrdersCtl alloc]init];
    _twoVC.tabBarItem.title =@"订单";
    _twoVC.tabBarItem.image=[[UIImage imageNamed:@"orderfood_btn_order_25_25"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    _twoVC.tabBarItem.selectedImage = [[UIImage imageNamed:@"orderfood_btn_order2_25_25"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    _threeVC = [[TakeoutAddressCtl alloc] init];
    _threeVC.tabBarItem.title =@"地址";
    _threeVC.tabBarItem.image=[[UIImage imageNamed:@"orderfood_btn_location_25_25"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    _threeVC.tabBarItem.selectedImage = [[UIImage imageNamed:@"orderfood_btn_location2_25_25"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    

    
    
    self.viewControllers = @[_oneVC,_twoVC,_threeVC];
    [self.tabBar setBackgroundColor:[UIColor whiteColor]];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor colorWithHex:0x666666] }
                                             forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{ NSForegroundColorAttributeName : [UIColor colorWithHex:0xff8905] }
                                             forState:UIControlStateSelected];
    
    self.delegate = self;
    self.navigationController.delegate = self;
    
    self.title = @"外卖";
//    self.navigationItem.leftBarButtonItem = nil;
//    self.navigationItem.hidesBackButton = YES;
}


-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UINavigationControllerDelegate
// 将要显示控制器
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    //DLog(@"%@",viewController);
    // 判断要显示的控制器是否是自己
    BOOL isShowHomePage = [viewController isKindOfClass:[self class]];
    [self.navigationController setNavigationBarHidden:isShowHomePage animated:YES];
}

-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    NSInteger index = tabBarController.selectedIndex;
    NSString *title;
    
    if(index == 0) {
        self.navigationController.navigationBar.hidden = NO;
        title = @"外卖";
    } else if(index == 1) {
        self.navigationController.navigationBar.hidden = NO;
        title = @"订单";
        
    }else if (index == 2){
        self.navigationController.navigationBar.hidden = NO;
        title = @"地址";
    }
    
    self.title = title;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
