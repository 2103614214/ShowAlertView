//
//  TakeoutStoreModel.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/10.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutStoreModel.h"

/** 菜单左边分类列表 */
@implementation TakeoutStoreModel

@end

//商铺信息
@implementation TakeoutStoreInfoModel



@end

/** 菜单右边列表 */
@implementation TakeoutLeftModel

#pragma  mark - 计算数量
+(NSInteger) CountOthersWithorderData:(NSMutableArray *)ordersArray{
    
    NSInteger count = 0;
    for (int i = 0; i< ordersArray.count; i++)
    {
        TakeoutLeftModel *model = ordersArray[i];
        count += model.countNumber;
    }
    
    return count;
    
}

#pragma  mark - 计算价格
+(double)GetTotalPrice:(NSMutableArray *)dataArray{
    
    double nTotal = 0;
    for (TakeoutLeftModel *model in dataArray) {
        
        if (model.countNumber >0) {
            
            nTotal += model.countNumber * [model.price floatValue];
        }
    }
    return nTotal;
}

@end
