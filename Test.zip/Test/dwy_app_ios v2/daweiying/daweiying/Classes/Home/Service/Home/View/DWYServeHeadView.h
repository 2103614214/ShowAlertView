//
//  DWYServeHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DWYServeModel.h"
#import <SDCycleScrollView.h>


@protocol serveViewDelegate <NSObject>

@optional
// view点击的时候调用，type:选中view的类型 selectIndex：选中的index
- (void)viewDidClick:(NSString *)type selectIndex:(NSInteger)selectIndex;

@end

@interface DWYServeHeadView : UIView

/** 轮播图 */
@property(nonatomic,strong)SDCycleScrollView *cycleScrollView;
/** 分类模型 */
@property(nonatomic,strong)NSArray *cateArray;
/** 活动模型 */
@property(nonatomic,strong)NSArray *activityArray;
/** 优选 */
@property(nonatomic,strong)NSArray *chooseArray;

@property (nonatomic,weak) id<serveViewDelegate> delegate;

@end
