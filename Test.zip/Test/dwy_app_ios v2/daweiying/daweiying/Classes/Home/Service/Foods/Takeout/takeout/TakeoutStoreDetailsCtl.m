//
//  TakeoutStoreDetailsCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutStoreDetailsCtl.h"
#import "TakeoutStoreHeadView.h"
#import "WZBSegmentedControl.h"
#import "TakeoutCategoryCell.h"
#import "TakeoutStoreModel.h"
#import "TakeoutLeftCell.h"

#import "NSObject+Property.h"
#import "YXShoppingCartAnimaition.h"
#import "StoreMessageModel.h"
#import "TakeoutCommentHeadView.h"
#import "DWYCommentModel.h"
#import "DWYFoodsCommentCell.h"
#import "CollectTools.h"
#import "CommitFoodsCtl.h"
static NSString * const DWYCategoryCellID = @"DWYCategoryCellID"; //分类
static NSString * const DWYLeftCellID = @"DWYLeftCellID"; //菜单右侧列表
static NSString * const DWYCenterCellID = @"DWYCenterCellID";  //中间评论列表

@interface TakeoutStoreDetailsCtl () <UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,numberDelegate>

/** headview */
@property(nonatomic,strong)TakeoutStoreHeadView *headView;
/** footview */
@property(nonatomic,strong)TakeoutStoreFootView *footView;
// 可滑动的segmentedControl
@property (nonatomic, strong) WZBSegmentedControl *sectionView;
// 底部横向滑动的scrollView，上边放着四个tableView
@property (nonatomic, strong) UIScrollView *scrollView;

// 左边的分类tableView
@property (nonatomic, strong) UITableView *categoryLeftTableView;
// 左边的tableView
@property (nonatomic, strong) UITableView *leftTableView;
// 中间的tableView
@property (nonatomic, strong) UITableView *centerTableView;
// 右边的tableView
@property (nonatomic, strong) UITableView *rightTableView;
/** 分类数据源 */
@property(nonatomic,strong)NSMutableArray *categoryArr;
/** 商品数据源 */
@property(nonatomic,strong)NSMutableArray *foodsArr;
/** 选中数据的数据源 */
@property(nonatomic,strong)NSMutableArray *selectDataArray;
/** 商家详情 */
@property(nonatomic,strong)NSMutableArray *storeMessage;
/** 点评数据源 */
@property(nonatomic,strong)NSMutableArray *commentsArray;
/** 点评列表头部视图 */
@property(nonatomic,strong)TakeoutCommentHeadView *commentHeadView;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 总页数 */
@property (nonatomic, assign) NSInteger page_total;


/** 保存 */
@property(nonatomic,assign)NSInteger section;
@property(nonatomic,assign)NSInteger row;
/** 饭盒价格 */
@property(nonatomic,assign)float boxPrice;
/** 配送费 */
@property(nonatomic,copy)NSString *deliveryStr;

@end

@implementation TakeoutStoreDetailsCtl

-(NSMutableArray *)selectDataArray{
    if (!_selectDataArray) {
        _selectDataArray = [NSMutableArray array];
    }
    return _selectDataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.commentHeadView = [[TakeoutCommentHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.15)];
    
    [self initWithSectionView]; //创建滑块
    
     [self setupHeadAndFoot]; //创建头部及底部视图
    
    
    

    //初始化数据源
    self.categoryArr = [NSMutableArray array];
    self.foodsArr = [NSMutableArray array];
    self.storeMessage = [NSMutableArray array];
    self.commentsArray = [NSMutableArray array];

    //请求数据
    [self asyncConcurrent];
    
}

// 并发队列 + 异步执行    同时开启任务，同时执行，开启新线程
- (void)asyncConcurrent
{
    
    dispatch_queue_t queue= dispatch_queue_create("getData.queue", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(queue, ^{
        [self loadData]; //菜单
    });
    dispatch_async(queue, ^{
        [self loadStoreInfoData]; //商家详情
    });
    dispatch_async(queue, ^{
        [self loadCateCommentData]; //点评
    });
  
}

#pragma mark -- 请求外卖点评
-(void)loadCateCommentData{
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.s_id);
    NSString *urlStr = [Utils getMemberServiceUri:@"cate_comment"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            //店铺信息
            NSDictionary *storeDict = [dataObject objectForKey:@"grade"];
            self.commentHeadView.grade = storeDict;
            
            //数据源
            storeDict = [dataObject objectForKey:@"comments"];
            self.commentsArray = [DWYCommentModel mj_objectArrayWithKeyValuesArray:storeDict];
            
            [self.centerTableView reloadData];
        }
        
    } failure:^(NSError * _Nonnull error) {
        
    }];

}

#pragma mark -- 请求商家详情
-(void)loadStoreInfoData{
  
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.s_id);
    NSString *urlStr = [Utils getMemberServiceUri:@"message"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            //店铺信息
            NSDictionary *storeDict = [dataObject objectForKey:@"message"];
            NSString *send_timeStr = [NSString stringWithFormat:@"%@分钟",[storeDict objectForKey:@"send_time"]];
            NSArray *storeData = @[
                                   @{@"s_phone": [storeDict objectForKey:@"s_phone"],@"s_logo":@"foodstore_icon_phone_20_20"}
                                   ,@{@"s_phone": [storeDict objectForKey:@"s_place"],@"s_logo":@"foodstore_icon_location_20_20"}
                                   ,@{@"s_phone": send_timeStr,@"s_logo":@"foodstore_icon_time_20_20"}
                                   ];
            self.storeMessage = [StoreMessageModel mj_objectArrayWithKeyValuesArray:storeData];
            [self.rightTableView reloadData];
        }
        
    } failure:^(NSError * _Nonnull error) {
        
    }];
    
}
#pragma mark - 请求网络数据
-(void)loadData{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.s_id);

    NSString *urlStr = [Utils getMemberServiceUri:@"hot_pot"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        //NSLog(@"%@",responseObject);
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
         
            id dataObject = [responseObject objectForKey:@"data"];
            
            //店铺信息
            NSDictionary *storeDict = [dataObject objectForKey:@"store"];
            TakeoutStoreInfoModel *storeModel = [TakeoutStoreInfoModel objectWithDictionary:storeDict];
            self.headView.model = storeModel;
            self.footView.model = storeModel;
            self.boxPrice = storeModel.box_price;
            self.deliveryStr = storeModel.delivery;
            //商品信息
            NSMutableArray *storesArr = [dataObject objectForKey:@"menus"];
    
            for (NSDictionary *dict in storesArr) {
                
                if([[dict allKeys] containsObject:@"foods"]){

                    TakeoutStoreModel *model = [TakeoutStoreModel objectWithDictionary:dict];
                    
                    if (!model.foods || !model.foods.count){
                        //array是空或nil
                        //return;
                    }else{ //商品有值才添加进数据源内
                        [self.categoryArr addObject:model];
                        
                        NSMutableArray *datas = [NSMutableArray array];
                        for (NSDictionary *f_model in  model.foods) {
                            
                            TakeoutLeftModel *model = [TakeoutLeftModel objectWithDictionary:f_model];
                            [datas addObject:model];
                            
                        }
                        [self.foodsArr addObject:datas];
                    }
                    

                }
   
            
            }
            
            [self.categoryLeftTableView reloadData];
            [self.leftTableView reloadData];
            
            if (self.categoryArr.count > 0) {
                //默认选中第一行
                [self.categoryLeftTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionTop];
                self.leftTableView.backgroundView = nil;
            }else{
                [self.leftTableView showBlankPageView:1];
            }

        }else{ //获取数据失败
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        [MBManager showError];
    }];
}

//加载更多
-(void)loadMoreDatas{
    
    // 结束下拉
    [self.centerTableView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"没有更多数据了"];
        [self.centerTableView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.s_id);
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;

    NSString *urlStr = [Utils getMemberServiceUri:@"cate_comment"];
 
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
             NSDictionary *storeDict = [dataObject objectForKey:@"comments"];
             NSArray *newProducts = [DWYCommentModel mj_objectArrayWithKeyValuesArray:storeDict];

            [self.commentsArray addObjectsFromArray:newProducts];
            
            [self.centerTableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.centerTableView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.centerTableView.mj_footer endRefreshing];
    }];
    
}


-(void)setupHeadAndFoot{
    
    __weak typeof (self)weakSelf = self;
    //底部视图
    self.footView = [[TakeoutStoreFootView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-TABBAR_HEIGHT-BAR_HEIGHT/2, SCREEN_WIDTH, TABBAR_HEIGHT+BAR_HEIGHT/2) inView:self.view];
    self.footView.cartTableViewToFront = ^{
        // 将view1放在最上方
        [weakSelf.view bringSubviewToFront:weakSelf.footView.OverlayView];
    };
    self.footView.OrderList.GoodListCellClick = ^(NSMutableArray *dataArray) {
        weakSelf.selectDataArray = dataArray;
        
        [weakSelf upDataFoodsArray];
        
        for (int i = 0; i<self.categoryArr.count; i++) {
            [weakSelf updataBageWithNumber:i];
        }
        [weakSelf setupPullTableView]; //
    };
    [self.view addSubview:self.footView];
    
    [self.footView.countBtn addTarget:self action:@selector(commitFoods) forControlEvents:(UIControlEventTouchUpInside)];
    
    //添加遮罩图层
    self.OverlayView = [[OverlayView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.OverlayView.tag = 7777;
    self.OverlayView.type = isFoodsDetailsPage;
    self.OverlayView.removeOverlayView = ^{
        [[[UIApplication sharedApplication].keyWindow viewWithTag:7777] removeFromSuperview];
    };
    
    self.OverlayView.operationBlock = ^(NSInteger number, BOOL plus) {
        TakeoutLeftModel *model = weakSelf.foodsArr[weakSelf.section][weakSelf.row];
        [model setValue:@(number) forKey:@"countNumber"];
        
        TakeoutStoreModel *leftModel = weakSelf.categoryArr[weakSelf.section];
        if (plus) { //加
            leftModel.bageNumber +=1;
            
            if (weakSelf.selectDataArray.count!=0) {
                
                BOOL flage = YES;
                for (TakeoutLeftModel *model1 in weakSelf.selectDataArray) {
                    if (model.pro_id == model1.pro_id){
                        
                        NSInteger count = model.countNumber;
                        
                        [model1 setValue:@(count) forKey:@"countNumber"];
                        flage = NO;
                        break;
                    }
                }
                if(flage){
                    [weakSelf.selectDataArray addObject:model];
                }
                
            }else{
                
                [weakSelf.selectDataArray addObject:model];
                
            }
        }else{ //减
            leftModel.bageNumber -=1;
            
            for (int i=0; i<weakSelf.selectDataArray.count;i++) {
                
                
                TakeoutLeftModel *model1 = weakSelf.selectDataArray[i];
                
                
                if (model.pro_id == model1.pro_id) {
                    
                    if (model.countNumber == 0)
                    {
                        [weakSelf.selectDataArray removeObjectAtIndex:i];
                        break;
                    }else
                    {
                        
                        [model1 setValue:@(model.countNumber) forKey:@"countNumber"];
                        
                    }
                    break;
                }
                
            }

            
        }
        [weakSelf setupPullTableView];
        [weakSelf.categoryLeftTableView reloadData];
        [weakSelf.leftTableView reloadData];
    };
    self.OverlayView.alpha = 1.0;
    self.OverlayView.hidden = YES;
    [self.view addSubview:self.OverlayView];

}

#pragma mark -- 提交， 下单确认
-(void)commitFoods{
    float boxPrice = self.selectDataArray.count * self.boxPrice;
    NSDictionary *dict = @{@"totalPrice":self.footView.totalPrice.text,
                           @"boxPrice":@(boxPrice),
                           @"freight":self.deliveryStr,
                           @"s_id":@(self.s_id),
                           @"storeName":self.storeName
                           };
    CommitFoodsCtl *vc = [[CommitFoodsCtl alloc] init];
    vc.dataArray = self.selectDataArray;
    vc.commitDict = dict;
    [self.navigationController pushViewController:vc animated:YES];
}
//更新食品数据源
-(void)upDataFoodsArray{
    for (int i = 0; i<self.foodsArr.count; i++) {
        for (int a = 0; a < [self.foodsArr[i] count]; a++) {
            TakeoutLeftModel *model = self.foodsArr[i][a];
            if (self.selectDataArray.count == 0) {
                NSInteger count = 0;
                [model setValue:@(count) forKey:@"countNumber"];
            }else{
                
                for (TakeoutLeftModel *model1 in self.selectDataArray) {
                    if (model.pro_id == model1.pro_id){
                        
                        NSInteger count = model1.countNumber;
                        [model setValue:@(count) forKey:@"countNumber"];
                        
                    }
                }
            }

        }
    }
    [self.leftTableView reloadData];
}
#pragma mark - 创建滑块
-(void)initWithSectionView{
    
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    __weak typeof (self)weakSelf = self;
    //头部视图
    self.headView = [[TakeoutStoreHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 64*2)];
    self.headView.storeNameStr = self.storeName;
    [self.view addSubview:self.headView];
    [self.headView.backBtn addTarget:self action:@selector(back) forControlEvents:(UIControlEventTouchUpInside)];
    [[self.headView.makeBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        
        self.headView.makeBtn.selected = !self.headView.makeBtn.selected;
        
        if (self.headView.makeBtn.selected) {
            [CollectTools collectStore:self.s_id];
        }
        
    }];
    
    // 创建segmentedControl    //滑块
    WZBSegmentedControl *sectionView = [WZBSegmentedControl segmentWithFrame:(CGRect){0, 64*2, SCREEN_WIDTH, 44} titles:@[@"菜单", @"外卖点评", @"商家详情"] tClick:^(NSInteger index) {

        // 改变scrollView的contentOffset
        weakSelf.scrollView.contentOffset = CGPointMake(index * SCREEN_WIDTH, 0);
    
        
    }];
    
    self.sectionView = sectionView;
    // 设置其他颜色
    [sectionView setNormalColor:[UIColor grayColor] selectColor:[UIColor colorWithHex:0xf67100] sliderColor:[UIColor colorWithHex:0xf67100] edgingColor:[UIColor clearColor] edgingWidth:0];
    sectionView.backgroundColor = [UIColor whiteColor];
    // 去除圆角
    sectionView.layer.cornerRadius = sectionView.backgroundView.layer.cornerRadius = .0f;
    
    // 加两条线
    for (NSInteger i = 0; i < 2; i++) {
        UIView *line = [UIView new];
        line.backgroundColor = [UIColor colorWithHex:0xd9d9d9];
        line.frame = CGRectMake(0, 43.5 * i, SCREEN_WIDTH, 0.5);
        [sectionView addSubview:line];
    }

    
    // 调下frame
    CGRect frame = sectionView.backgroundView.frame;
    frame.origin.y = frame.size.height - 1.5;
    frame.size.height = 1;
    sectionView.backgroundView.frame = frame;
    [self.view addSubview:self.sectionView];
    
    // 底部横向滑动的scrollView
    float y = self.headView.height+44;
    CGRect rect = CGRectMake(0, y, SCREEN_WIDTH, SCREEN_HEIGHT-y);
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:rect];
    //scrollView.showsVerticalScrollIndicator = FALSE;
    scrollView.showsHorizontalScrollIndicator = FALSE;
    [self.view addSubview:scrollView];
    
    
    // 绑定代理
    scrollView.delegate = self;
    
    // 设置滑动区域
    scrollView.contentSize = CGSizeMake(3 * SCREEN_WIDTH, 0);
    scrollView.pagingEnabled = YES;
    self.scrollView = scrollView;
    
    // 创建三个tableView
    CGFloat h = self.scrollView.height-59;
    self.categoryLeftTableView = [self tableViewWithX:0 WithW:SCREEN_WIDTH*0.25 WithH:h];
    self.leftTableView = [self tableViewWithX:SCREEN_WIDTH*0.25 WithW:SCREEN_WIDTH*0.75 WithH:h];
    self.centerTableView = [self tableViewWithX:SCREEN_WIDTH WithW:SCREEN_WIDTH WithH:h+59];
    self.rightTableView = [self tableViewWithX:SCREEN_WIDTH * 2 WithW:SCREEN_WIDTH WithH:h];
    //注册cell
    [self.categoryLeftTableView registerClass:[TakeoutCategoryCell class] forCellReuseIdentifier:DWYCategoryCellID];
    [self.leftTableView registerClass:[TakeoutLeftCell class] forCellReuseIdentifier:DWYLeftCellID];

    [self.centerTableView registerClass:[DWYFoodsCommentCell class] forCellReuseIdentifier:DWYCenterCellID];
    self.centerTableView.tableHeaderView = self.commentHeadView;
    self.centerTableView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
    
}

#pragma mark -  创建tableView
- (UITableView *)tableViewWithX:(CGFloat)x WithW:(CGFloat)w WithH:(CGFloat)h{
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(x, 0, w, h)];
    [self.scrollView addSubview:tableView];
    tableView.backgroundColor = [UIColor colorWithHex:0xefeff4];
    tableView.showsVerticalScrollIndicator = NO;
    
    tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero]; //去除多余分割线
    // 代理&&数据源
    tableView.delegate = self;
    tableView.dataSource = self;
    
    return tableView;
}

-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = YES;
}



#pragma mark -  UITableViewDataSource 数据源 及UITableViewDelegate 代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (tableView == self.categoryLeftTableView) {
        
        return self.categoryArr.count;
    }else if (tableView == self.leftTableView){
        return [self.foodsArr[section] count];
    }else if (tableView == self.rightTableView){
        return 1;
    }else if (tableView == self.centerTableView){
        return self.commentsArray.count;
    }else{
        return 1;
    }

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.leftTableView) {
        return self.foodsArr.count;
    }else if (tableView == self.rightTableView){
        return self.storeMessage.count;
    }
    else{
        return 1;
    }
    
}

#pragma mark - 代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    // 取出帖子模型
//    XMGTopic *topic = self.topics[indexPath.row];
//    
//    // 返回这个模型对应的cell高度
//    return topic.cellHeight;
    if (tableView == self.leftTableView) {
        return 80;
    }else if (tableView == self.centerTableView){
        return 130;
    }else{
        return 44;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

    if (tableView == self.categoryLeftTableView) { //菜单栏左侧分类列表
        TakeoutCategoryCell *cell = [tableView dequeueReusableCellWithIdentifier:DWYCategoryCellID forIndexPath:indexPath];
        if (!cell) {
            cell = [[TakeoutCategoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:DWYCategoryCellID];
        }
        TakeoutStoreModel *model = self.categoryArr[indexPath.row];
        cell.name.text = model.cate_name;
        cell.badgeLabel.text = [NSString stringWithFormat:@"%ld",model.bageNumber];
        if (model.bageNumber > 0) {
            cell.badgeLabel.hidden = NO;
        }else{
            cell.badgeLabel.hidden = YES;
        }
        cell.preservesSuperviewLayoutMargins = NO;
        cell.separatorInset = UIEdgeInsetsZero;
        cell.layoutMargins = UIEdgeInsetsZero;
        cell.backgroundColor = [UIColor colorWithHex:0xefeff4];
        
        
        return cell;
    }else if (tableView == self.leftTableView){ //菜单栏右侧列表
        
        TakeoutLeftCell *cell = [tableView dequeueReusableCellWithIdentifier:DWYLeftCellID forIndexPath:indexPath];
        if (!cell) {
            cell = [[TakeoutLeftCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:DWYLeftCellID];
        }
        cell.delegate = self;
       // cell.selectionStyle = UITableViewCellSelectionStyleNone;  //取消点击效果
        
        TakeoutLeftModel *model = self.foodsArr[indexPath.section][indexPath.row];
        cell.model = model;
    
        if (model.countNumber  != 0) {
            
            cell.cutBut.hidden = NO;
            cell.numberLab.hidden = NO;
            cell.numberLab.text = [NSString stringWithFormat:@"%ld",model.countNumber];
            
            
        }else{
            cell.numberLab.text = nil;
            cell.numberLab.hidden = YES;
            cell.cutBut.hidden = YES;
        }
        __weak typeof(&*cell)weakCell =cell;
        __weak typeof(self)bself = self;
        cell.plusBlock = ^(NSInteger count, UIButton *btn) {
           
            weakCell.model = bself.foodsArr[indexPath.section][indexPath.row];
            weakCell.model.countNumber = count;
            
            if (btn.tag == 10086) {  //加
                if (bself.selectDataArray.count!=0) {
                    
                    BOOL flage = YES;
                    for (TakeoutLeftModel *model1 in bself.selectDataArray) {
                        if (model.pro_id == model1.pro_id){
                            
                            NSInteger count = model.countNumber;
                      
                            [model1 setValue:@(count) forKey:@"countNumber"];
                            flage = NO;
                            break;
                        }
                    }
                    if(flage){
                        [bself.selectDataArray addObject:weakCell.model];
                    }
                    
                }else{
                    
                    [bself.selectDataArray addObject:weakCell.model];
                }
                
            }else if (btn.tag == 10010){  //减
                for (int i=0; i<bself.selectDataArray.count;i++) {
                    
                    
                    TakeoutLeftModel *model1 = bself.selectDataArray[i];
                    
                    
                    if (model.pro_id == model1.pro_id) {
                        
                        if (model.countNumber == 0)
                        {
                            [bself.selectDataArray removeObjectAtIndex:i];
                            break;
                        }else
                        {

                            [model1 setValue:@(weakCell.model.countNumber) forKey:@"countNumber"];
                            
                        }
                        break;
                    }
                    
                }
                
            }
            
            [bself setupPullTableView]; //更新上拉列表
            //更新左侧分类角标
            [bself updataBageWithNumber:indexPath.section];

        };
        
  
        return cell;
        
    }else if (tableView == self.centerTableView){ //DWYFoodsCommentCell
        DWYFoodsCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:DWYCenterCellID forIndexPath:indexPath];
        if (!cell) {
            cell = [[DWYFoodsCommentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:DWYCenterCellID];
        }
        cell.takeoutModel = self.commentsArray[indexPath.row];
        
        return cell;
    }
    else{
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellID"];
        }

        if (tableView == self.rightTableView) {
            StoreMessageModel *model = self.storeMessage[indexPath.section];
            cell.imageView.image = [UIImage imageNamed:model.s_logo];
            cell.textLabel.text = model.s_phone;
            cell.textLabel.font = [UIFont systemFontOfSize:14];
        }
        return cell;
        
    }
    

}


#pragma mark -- 更新上拉列表
-(void)setupPullTableView{
    
    
    //设置数量、价格
    self.footView.badgeValue =  [TakeoutLeftModel CountOthersWithorderData:self.selectDataArray];
    double price = [TakeoutLeftModel GetTotalPrice:self.selectDataArray];
    self.footView.totalPrice.text = [NSString stringWithFormat:@"%.2f",price];
    
    self.footView.OrderList.objects = self.selectDataArray;
    self.footView.OrderList.box_price = self.boxPrice;
    [self.footView updateFrame:self.footView.OrderList];
    [self.footView.OrderList.tableView reloadData];
    
    [self animationToShopNumber];//执行动画
    
    
}

#pragma mark - 更新左侧角标
-(void)updataBageWithNumber:(NSInteger)number{
    TakeoutStoreModel *leftModel = self.categoryArr[number];
    NSInteger a = 0;
    for (int i = 0; i<self.selectDataArray.count; i++) {
        TakeoutLeftModel *bageModel = self.selectDataArray[i];
        NSInteger aa;
        
        if (leftModel.cate_id == bageModel.cate_id) {
            aa = bageModel.countNumber;
            a += aa;
        }
    }
    leftModel.bageNumber = a;
    [self.categoryLeftTableView reloadData];
    [self.categoryLeftTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:_selectIndex inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
    
}

//购物车角标动画
- (void)animationToShopNumber{
    
//    CAKeyframeAnimation *key = [CAKeyframeAnimation animationWithKeyPath:@"transform.scale"];
//    key.values =  @[@(0.1),@(1.0),@(1.5)];
//    key.keyTimes = @[@(0.0),@(0.5),@(0.8),@(1.0)];
//    key.calculationMode = kCAAnimationLinear;
//    [self.footView.badge.layer addAnimation:key forKey:@"scale"];
    
    
    CABasicAnimation *shakeAnimation = [CABasicAnimation animationWithKeyPath:@"transform.translation.y"];
    shakeAnimation.duration = 0.25f;
    shakeAnimation.fromValue = [NSNumber numberWithFloat:-5];
    shakeAnimation.toValue = [NSNumber numberWithFloat:5];
    shakeAnimation.autoreverses = YES;
    [self.footView.cartBtn.layer addAnimation:shakeAnimation forKey:nil];

}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    //return (_leftTableView == tableView) ? 20 : 0;
    if (tableView == self.leftTableView) {
        return 20;
    }else if (tableView == self.rightTableView){
        return 10;
    }
    else{
        return 0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    
    //return  (_leftTableView == tableView) ? view : nil;
    
    if (tableView == self.leftTableView) {
        TableViewHeaderView *view = [[TableViewHeaderView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 20)];
        TakeoutStoreModel *model = self.categoryArr[section];
        view.name.text = model.cate_name;
        return view;
    }else if (tableView == self.rightTableView){
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
        return view;
    }else{
        return nil;
    }
  
    
}


// TableView分区标题即将展示
- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    
    // 当前的tableView是RightTableView，RightTableView滚动的方向向上，RightTableView是用户拖拽而产生滚动的（（主要判断RightTableView用户拖拽而滚动的，还是点击LeftTableView而滚动的）
    if ((_leftTableView == tableView) && !_isScrollDown && _leftTableView.dragging) {
        [self selectRowAtIndexPath:section];
    }
    
    
    
}

// TableView分区标题展示结束
- (void)tableView:(UITableView *)tableView didEndDisplayingHeaderView:(UIView *)view forSection:(NSInteger)section {
    
    // 当前的tableView是RightTableView，RightTableView滚动的方向向下，RightTableView是用户拖拽而产生滚动的（（主要判断RightTableView用户拖拽而滚动的，还是点击LeftTableView而滚动的）
    if ((_leftTableView == tableView) && _isScrollDown && _leftTableView.dragging)
    {
        [self selectRowAtIndexPath:section + 1];
    }
    
}


// 当拖动右边TableView的时候，处理左边TableView
- (void)selectRowAtIndexPath:(NSInteger)index {
    _selectIndex = index;
   
        [_categoryLeftTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] animated:YES scrollPosition:UITableViewScrollPositionTop];
    
}

//点击左边分类，处理右边TableView
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_categoryLeftTableView != tableView && _leftTableView != tableView){
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        return;
    }

    _selectIndex = indexPath.row;
    
    if (tableView == _categoryLeftTableView) {
            [_leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:_selectIndex] atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }

    if (tableView == _leftTableView) {
        
        //保存 section , row
        self.section = indexPath.section;
        self.row = indexPath.row;
        
        self.OverlayView.hidden = NO;
        self.OverlayView.type = isFoodsDetailsPage;
        [self.OverlayView setupUI];
        self.OverlayView.model = self.foodsArr[indexPath.section][indexPath.row];
        [[[UIApplication sharedApplication] keyWindow] addSubview:self.OverlayView];
    }
    
}

#pragma mark -- 自定义cell代理方法
- (void)customCell:(TakeoutLeftCell *)cell buttom:(UIButton *)but numberLab:(UILabel *)lab{
    if (but.tag == 10086) {
        
        lab.text = [NSString stringWithFormat:@"%d",lab.text.intValue+1];
        //执行动画
        [[YXShoppingCartAnimaition shareTool] startAnimationandView:but endView:self.footView.cartBtn finishBlock:^(BOOL isFinished) {
            if (isFinished) {
                
            }
        }];
        
        
    }
    if(but.tag == 10010 && lab.text.intValue != 0){
        lab.text =[NSString stringWithFormat:@"%d",lab.text.intValue-1];
        
        
    }
    if (lab.text.intValue == 0) {
        lab.hidden = YES;
        but.hidden = YES;
    }
    
}
#pragma mark -- UIScrollView代理
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    
    // 如果当前滑动的是tableView
    if ([scrollView isKindOfClass:[UITableView class]]) {
        //NSLog(@"11111");
    }
    
    
    if (scrollView == self.scrollView) {
        
        // 改变segmentdControl
        [self.sectionView setContentOffset:(CGPoint){scrollView.contentOffset.x / 3, 0}];
        if (scrollView.contentOffset.x >=SCREEN_WIDTH) {
            self.footView.hidden = YES;
        }else{
            self.footView.hidden = NO;
        }
        return;
    }
 
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
