//
//  DWYServiceCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYServiceCtl.h"
#import "DWYServeCell.h"
#import "DWYServeHeadView.h"

#import "DWYServeModel.h"
#import "RetailHeadView.h"
#import "UISearchBar+SearchBarPlaceholder.h"

#import "DWYFoodsCtl.h"
#import "TakeoutTabBar.h"
#import "WZBSegmentedControl.h"

@interface DWYServiceCtl () <UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,serveViewDelegate>

//搜索
@property (nonatomic, strong) UISearchBar *searchBar;

/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;
/** headView */
@property(nonatomic,strong)DWYServeHeadView *headView;
/** 分类 */
@property(nonatomic,strong)NSMutableArray *categoryArray;
/** 活动页 */
@property(nonatomic,strong)NSMutableArray *activityArray;
/** 广告轮播 */
@property(nonatomic,strong)NSMutableArray *AdvArray;
/** 优选 */
@property(nonatomic,strong)NSMutableArray *chooseArray;
/** topview */
@property(nonatomic,strong)UIView *topView;
/** 返回按钮 */
@property(nonatomic,strong)UIButton *backBtn;
// 可滑动的segmentedControl
@property (nonatomic, strong) WZBSegmentedControl *sectionView;


/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;

@end

static NSString * const ServeCellID = @"ServeCellID";
@implementation DWYServiceCtl


-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableArray *)activityArray{
    if (!_activityArray) {
        _activityArray = [NSMutableArray array];
    }
    return _activityArray;
}

-(NSMutableArray *)categoryArray{
    if (!_categoryArray) {
        _categoryArray = [NSMutableArray array];
    }
    return _categoryArray;
}
-(NSMutableArray *)AdvArray{
    if (!_AdvArray) {
        _AdvArray = [NSMutableArray array];
    }
    return _AdvArray;
}

-(NSMutableArray *)chooseArray{
    if (!_chooseArray) {
        _chooseArray = [NSMutableArray array];
    }
    return _chooseArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self viewDidLoad:YES];
    
    [self setStatusBarBackgroundColor:[UIColor clearColor]]; //设置顶部状态栏颜色

    
    [self setupTopUI]; //初始化顶部ui
   // 添加刷新控件
    [self setupRefresh];
    
    //顶部返回及搜索框
    [self initTopView];
}

-(void)setupTopUI{
    self.headView = [[DWYServeHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT+15)];
    self.headView.delegate = self;

    self.tableView = [self tableViewWithX:0]; //添加tableview
}
// 创建tableView
- (UITableView *)tableViewWithX:(CGFloat)x {

    //UITableView *tableview = [[UITableView alloc] initWithFrame:CGRectMake(x, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    UITableView *tableview = [[UITableView alloc] initWithFrame:CGRectMake(x, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
    [self.view addSubview:tableview];
    tableview.delegate = self;
    tableview.dataSource = self;
    tableview.rowHeight = kHeight(100);
    tableview.tableHeaderView = self.headView;
    
    tableview.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    tableview.showsVerticalScrollIndicator = NO;
    [tableview registerClass:[DWYServeCell class] forCellReuseIdentifier:ServeCellID];
    
    return tableview;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //搜索键盘消失
    [self.searchBar resignFirstResponder];
    self.searchBar.text = nil;
    
    if ([scrollView isKindOfClass:[UITableView class]]) {
        CGFloat contentOffsetY = scrollView.contentOffset.y;
        
        if (contentOffsetY > 64) {
            self.topView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
            [self setStatusBarBackgroundColor:[UIColor colorWithHex:0xedf0f3]];
            
            //设置扫码按钮图牌颜色
            [self.backBtn setImage:[UIImage imageNamed:@"login_btn_back_22_22"] forState:0];
            
        }else{
            self.topView.backgroundColor = [UIColor clearColor];
            [self setStatusBarBackgroundColor:[UIColor clearColor]];
            [self.backBtn setImage:[UIImage imageNamed:@"fooddeteil_btn_back_22_22"] forState:0];

        }
    }
    
    // 如果当前滑动的是tableView
    if ([scrollView isKindOfClass:[UITableView class]]) {
        
        CGFloat contentOffsetY = scrollView.contentOffset.y;
        
        // 如果滑动没有超过150
        if (contentOffsetY < SCREEN_HEIGHT-64) {
            
            self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
            
            // 一旦大于等于150了，让headerView的y值等于150，就停留在上边了
        } else if (contentOffsetY >= SCREEN_HEIGHT-64) {
         
            self.tableView.contentInset = UIEdgeInsetsMake(64, 0, 0, 0);
        }
    }
    
}

-(void)initTopView{
    
    self.topView = [[UIView alloc] initWithFrame:CGRectMake(0, 20, SCREEN_WIDTH, NAV_HEIGHT)];
    [self.view addSubview:self.topView];
    //返回按钮
    UIButton *backBtn = [UIButton new];
    backBtn.frame = CGRectMake(10, 5, 30, 30);
    [backBtn setImage:[UIImage imageNamed:@"shop_btn_back_22_22"] forState:0];
    [[backBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        //返回按钮
        [self back];
    }];
    [self.topView addSubview:backBtn];
    self.backBtn = backBtn;
    
    //搜索
    _searchBar = [[UISearchBar alloc] init];
    _searchBar.keyboardType =UIKeyboardTypeNumbersAndPunctuation;
    [_searchBar changeLeftPlaceholder:@"商品名称"];
    UIImage* searchBarBg = [self GetImageWithColor:[UIColor clearColor] andHeight:32.0f];
    [_searchBar setBackgroundImage:searchBarBg];
    _searchBar.delegate = self;
    [self.topView addSubview:_searchBar];
    _searchBar.sd_layout
    .topEqualToView(backBtn)
    .leftSpaceToView(backBtn, 5)
    .widthIs(SCREEN_WIDTH-backBtn.width-20)
    .heightIs(30);
}

#pragma mark 实现搜索条背景透明化

- (UIImage*) GetImageWithColor:(UIColor *)color andHeight:(CGFloat)height{
    
    CGRect r= CGRectMake(0.0f, 0.0f, 1.0f, height);
    
    UIGraphicsBeginImageContext(r.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    
    CGContextFillRect(context, r);
    
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
    
}

-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setupRefresh{
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    [self.tableView.mj_header beginRefreshing];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
    //self.collectionView.mj_footer.ignoredScrollViewContentInsetBottom = 0;
}

//请求数据
-(void)loadData{
    
    // 结束上啦
    [self.tableView.mj_footer endRefreshing];
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
 
    
    NSString *urlStr = [Utils getMemberServiceUri:@"serve"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        //NSLog(@"%@",responseObject);
        [MBManager hideAlert];
    
         [self.tableView.mj_header endRefreshing];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            //分类
            NSDictionary *hotDict = [dataObject objectForKey:@"categorys"];
            self.categoryArray = [DWYCategoryModel mj_objectArrayWithKeyValuesArray:hotDict];
            self.headView.cateArray = self.categoryArray;
            //广告轮播
            hotDict = [dataObject objectForKey:@"banner"];
            self.AdvArray = [ADVModel mj_objectArrayWithKeyValuesArray:hotDict];
            //不发通知传值过去， 轮播图不自动轮播
            [[NSNotificationCenter defaultCenter] postNotificationName:@"ServeNotification" object:self.AdvArray];
            
            //活动
            hotDict = [dataObject objectForKey:@"recmmonds"];
            self.activityArray = [ActivityModel mj_objectArrayWithKeyValuesArray:hotDict];
            self.headView.activityArray = self.activityArray;
            //优选
            hotDict = [dataObject objectForKey:@"brands"];
            self.chooseArray = [ChooseModel mj_objectArrayWithKeyValuesArray:hotDict];
            self.headView.chooseArray = self.chooseArray;
            //列表数据源
            hotDict = [dataObject objectForKey:@"stores"];
            self.dataArray = [DWYServeModel mj_objectArrayWithKeyValuesArray:hotDict];
    
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.tableView.mj_header endRefreshing];
    }];
}

//加载更多
-(void)loadMoreDatas{
    
    // 结束下拉
    [self.tableView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"没有更多数据了"];
        [self.tableView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"serve"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *hotDict = [dataObject objectForKey:@"stores"];
            NSArray *newProducts = [DWYServeModel mj_objectArrayWithKeyValuesArray:hotDict];
            [self.dataArray addObjectsFromArray:newProducts];
            
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.tableView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.tableView.mj_footer endRefreshing];
    }];

}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = YES;
}


#pragma mark - UITableView 代理，数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DWYServeCell *cell = [tableView dequeueReusableCellWithIdentifier:ServeCellID];
    if (!cell) {
        cell = [[DWYServeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ServeCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    cell.model = self.dataArray[indexPath.row];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return SCREEN_HEIGHT*0.07+1;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    // 创建segmentedControl
    __weak typeof(self)weakSelf = self;
    WZBSegmentedControl *sectionView = [WZBSegmentedControl segmentWithFrame:(CGRect){0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.07} titles:@[@"离我最近", @"平台推荐", @"好评优先",@"人气最高"] tClick:^(NSInteger index) {
        
        weakSelf.sectionView.backgroundView.frame = CGRectMake((SCREEN_WIDTH/4)*index, SCREEN_HEIGHT*0.07-1.5, SCREEN_WIDTH/4, 1.5);
        
    }];
    sectionView.titleBtnClick = ^{
        
        [weakSelf.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionTop];
    };
    
    // 赋值给全局变量
    self.sectionView = sectionView;
    
    // 设置其他颜色
    [sectionView setNormalColor:[UIColor grayColor] selectColor:[UIColor colorWithHex:0xf67100] sliderColor:[UIColor colorWithHex:0xf67100] edgingColor:[UIColor clearColor] edgingWidth:0];
    sectionView.backgroundColor = [UIColor whiteColor];
    // 去除圆角
    sectionView.layer.cornerRadius = sectionView.backgroundView.layer.cornerRadius = .0f;
    
    // 调下frame
    CGRect frame = sectionView.backgroundView.frame;
    frame.origin.y = frame.size.height - 1.5;
    frame.size.height = 1;
    sectionView.backgroundView.frame = frame;
    
    UIView *headView = [UIView new];
    headView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
    headView.frame = CGRectMake(0, 0, SCREEN_WIDTH, sectionView.height+1);
    [headView addSubview:sectionView];
    
    return headView;
}


#pragma mark -- serveViewDelegate点击代理回调
-(void)viewDidClick:(NSString *)type selectIndex:(NSInteger)selectIndex{
    if ([type isEqualToString:@"category"]) { //分类
        
        if (selectIndex == 100) { //
            TakeoutTabBar *takeout = [[TakeoutTabBar alloc] init];
            [self.navigationController pushViewController:takeout animated:YES];
        }else if (selectIndex == 101){ //美食
            DWYFoodsCtl *foods = [DWYFoodsCtl new];
            foods.type = isFoodsPage;
            [self.navigationController pushViewController:foods animated:YES];
        }else{//ktv
            DWYFoodsCtl *foods = [DWYFoodsCtl new];
            foods.type = isKtvPage;
            [self.navigationController pushViewController:foods animated:YES];
        }
    }else if ([type isEqualToString:@"activityView"]){ //活动页
        
        
    }else if ([type isEqualToString:@"chooseView"]){ //优选
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
