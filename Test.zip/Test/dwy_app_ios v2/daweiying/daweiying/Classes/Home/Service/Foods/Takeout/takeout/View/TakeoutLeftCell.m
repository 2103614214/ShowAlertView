//
//  TakeoutLeftCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/10.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutLeftCell.h"
#import "TakeoutStoreModel.h"

@interface TakeoutLeftCell()

@property (nonatomic, strong) UIImageView *imageV;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *priceLabel;
@property (nonatomic, strong) UILabel *numberLabel; //销量

@end

@implementation TakeoutLeftCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.imageV = [[UIImageView alloc] initWithFrame:CGRectMake(15, 10, 60, 60)];
        self.imageV.layer.borderColor = [UIColor colorWithHex:0xd7d7d7].CGColor;
        self.imageV.layer.borderWidth = 0.5;
        self.imageV.layer.cornerRadius = 3;
        self.imageV.layer.masksToBounds = YES;
        [self.contentView addSubview:self.imageV];
        
        float x = 85;
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, 10, 130, 20)];
        self.nameLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.nameLabel];
        
        self.numberLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, 32, 130, 20)];
        self.numberLabel.font = [UIFont systemFontOfSize:12];
        self.numberLabel.textColor = [UIColor colorWithHex:UI_COLOR_GRAY];
        [self.contentView addSubview:self.numberLabel];
        
        self.priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, 55, 130, 20)];
        self.priceLabel.font = [UIFont systemFontOfSize:14];
        self.priceLabel.textColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
        [self.contentView addSubview:self.priceLabel];
        
        
        _addBut = [UIButton new];
        [_addBut setImage:[UIImage imageNamed:@"menu_btn_add_23_23"] forState:UIControlStateNormal];
        _addBut.frame =CGRectMake(SCREEN_WIDTH*0.75-32, 40, 25, 25);
        [_addBut addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        _addBut.tag = 10086;
        [self addSubview:_addBut];
  
        
        _cutBut = [UIButton new];
        [_cutBut setImage:[UIImage imageNamed:@"menu_btn_reduce_23_23"] forState:UIControlStateNormal];
        _cutBut.frame = CGRectMake(SCREEN_WIDTH*0.75-87,40, 25, 25);
        [_cutBut addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        _cutBut.tag = 10010;
        _cutBut.hidden = YES;
        [self addSubview:_cutBut];
        
        _numberLab = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*0.75-65, 40, 33, 25)];
        _numberLab.textAlignment = NSTextAlignmentCenter;
        _numberLab.text = @"0";
        _numberLab.textColor = [UIColor colorWithHex:0x999999];
        _numberLab.hidden = YES;
        _numberLab.font = [UIFont boldSystemFontOfSize:14];
        [self addSubview:_numberLab];
        
    }
    return self;
}

- (void)click:(UIButton *)sender{
    _numberLab.hidden = NO;
    _cutBut.hidden = NO;
    
    self.number =[_numberLab.text intValue];
    if (sender.tag == 10086) {
        self.number +=1;
    }else if (sender.tag == 10010){
        self.number -=1;
    }
    self.plusBlock(self.number,sender);
    if ([self.delegate respondsToSelector:@selector(customCell:buttom:numberLab:)]) {
        [self.delegate customCell:self buttom:sender numberLab:_numberLab];
        
    }
}

- (void)setModel:(TakeoutLeftModel *)model {
    
    _model = model;
    
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:model.logo_url]placeholderImage:[UIImage imageNamed:@"placeholder"]];
    self.nameLabel.text = model.pro_name;
    self.numberLabel.text = [NSString stringWithFormat:@"月销售%d",model.number];
    self.priceLabel.text = [NSString stringWithFormat:@"¥%@",model.price];
       
    
}



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
