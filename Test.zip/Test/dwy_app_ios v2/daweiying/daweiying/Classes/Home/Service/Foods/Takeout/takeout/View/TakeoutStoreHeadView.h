//
//  TakeoutStoreHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BadgeView.h"
#import "TakeoutStoreModel.h"
#import "OverlayView.h"
#import "GoodsListView.h"

#pragma mark - 头部视图
@interface TakeoutStoreHeadView : UIView

/** 返回 */
@property(nonatomic,strong)UIButton *backBtn;
/** 收藏 */
@property(nonatomic,strong)UIButton *makeBtn;
/** 标题 */
@property(nonatomic,copy)NSString *storeNameStr;
/** 商户信息模型 */
@property(nonatomic,strong)TakeoutStoreInfoModel *model;

@end


#pragma mark - 底部视图
@interface TakeoutStoreFootView : UIView

@property (nonatomic,strong) BadgeView *badge;

@property (nonatomic,strong) OverlayView *OverlayView;//遮罩图层
@property (nonatomic,strong) GoodsListView *OrderList;//选择的订单列表

@property (nonatomic,strong)   UIView *parentView;//背景图层
@property (nonatomic,assign) BOOL open;


@property (nonatomic,copy) void (^cartTableViewToFront)();

@property(nonatomic,strong)UIImageView *cartBtn;

@property (nonatomic,assign) NSInteger badgeValue;
/** 总价格 */
@property(nonatomic,strong)UILabel *totalPrice;
/** 点击结算 */
@property(nonatomic,strong)UIButton *countBtn;
/** 商户信息模型 */
@property(nonatomic,strong)TakeoutStoreInfoModel *model;


-(instancetype) initWithFrame:(CGRect)frame inView:(UIView *)parentView;
-(void)dismissAnimated:(BOOL) animated;
-(void)updateFrame:(GoodsListView *)orderListView;


@end
