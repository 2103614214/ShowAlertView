//
//  TakeoutCategoryCell.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/10.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

/** 菜单类左边分类列表 */
@interface TakeoutCategoryCell : UITableViewCell


@property (nonatomic, strong) UILabel *name;
/** 气泡 */
@property(nonatomic,strong) UILabel *badgeLabel;;

@end


/** 菜单类右边列表表头 */
@interface TableViewHeaderView : UIView


@property (nonatomic, strong) UILabel *name;

@end
