//
//  DWYServeModel.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DWYServeModel : NSObject

@property (nonatomic,copy) NSString *s_name;
@property (nonatomic,copy) NSString *s_logo;
@property (nonatomic,assign) int s_id;
@property (nonatomic,copy) NSString *s_introduce;
@property (nonatomic,copy) NSString *s_place;
@property (nonatomic,assign) int grade;
@property (nonatomic,copy) NSString *longitude;
@property (nonatomic,copy) NSString *latitude;

@property (nonatomic,copy) NSString *price;

@end

/** 分类 */
@interface DWYCategoryModel : NSObject

@property (nonatomic,assign) int cate_id;
@property (nonatomic,assign) int type;

@property (nonatomic,copy) NSString *cate_name;
@property (nonatomic,copy) NSString *cate_url;

@end

/** 活动页 */
@interface ActivityModel : NSObject

@property (nonatomic,assign) int t_id;
@property (nonatomic,assign) int t_type;

@property (nonatomic,copy) NSString *t_name;
@property (nonatomic,copy) NSString *t_img_url;
@property (nonatomic,copy) NSString *t_introduce;

@end

/** 品牌优选 */
@interface ChooseModel : NSObject

@property (nonatomic,assign) int s_id;
@property (nonatomic,copy) NSString *s_name;
@property (nonatomic,copy) NSString *s_logo;
@property (nonatomic,copy) NSString *s_introduce;

@end

/* 轮播头部广告 */
@interface ADVModel : NSObject

@property (nonatomic,assign) int b_id;
@property(nonatomic,assign)int type;
@property (nonatomic,copy) NSString *b_name;
@property (nonatomic,copy) NSString *b_logo;
@property (nonatomic,copy) NSString *b_introduce;

@end
