//
//  DWYFoodsStoreCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/28.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYFoodsStoreCtl.h"
#import "DWYFoodsDetailsHeadView.h"
#import "DWYActivityCell.h"
#import "DWYFoodsCommentCell.h"

#import "DWYActivitysModel.h"

@interface DWYFoodsStoreCtl () <UITableViewDelegate,UITableViewDataSource>

/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** 活动页数据源 */
@property(nonatomic,strong)NSMutableArray *activitysArray;
/** 评论页 */
@property(nonatomic,strong)NSMutableArray *commentArray;
/** headview */
@property(nonatomic,strong)DWYFoodsDetailsHeadView *headView;


@end

static NSString * const FoodsAtivitysCellID = @"FoodsAtivitysCellID";
static NSString * const FoodscommentCellID = @"FoodsCommentCellID";
@implementation DWYFoodsStoreCtl

-(NSMutableArray *)activitysArray{
    if (!_activitysArray) {
        _activitysArray = [NSMutableArray array];
    }
    return _activitysArray;
}

-(NSMutableArray *)commentArray{
    if (!_commentArray) {
        _commentArray = [NSMutableArray array];
    }
    return _commentArray;
}

-(UITableView *)tableView{
    if (!_tableView) {
        
        //_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableHeaderView = self.headView;
        _tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        _tableView.showsVerticalScrollIndicator = NO;
        [_tableView registerClass:[DWYActivityCell class] forCellReuseIdentifier:FoodsAtivitysCellID];
        [_tableView registerClass:[DWYFoodsCommentCell class] forCellReuseIdentifier:FoodscommentCellID];
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self viewDidLoad:YES];
    
    [self setStatusBarBackgroundColor:[UIColor clearColor]];
    
    self.headView = [[DWYFoodsDetailsHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.35+10)];
    
    [self.view addSubview:self.tableView];
    
    //返回按钮
    __weak typeof (self)weakSelf = self;
    UIButton *backBtn = [UIButton new];
    backBtn.frame = CGRectMake(10, 25, 30, 30);
    backBtn.alpha = 0.5;
    [backBtn setImage:[UIImage imageNamed:@"shopdt_btn_back_30_30"] forState:0];
    [[backBtn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(id x) {
        //返回按钮
        [weakSelf back];
    }];
    [self.view addSubview:backBtn];
    
    
    //网络请求数据
    [self loadData];
    
    
    NSLog(@"---------------888888");
}

-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)loadData{
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.storeID);  //@(11);  // 11有数据
    
    NSString *urlStr = [Utils getMemberServiceUri:@"cate_store"];
 
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        //NSLog(@"%@",responseObject);
        [MBManager hideAlert];
        
        //[self.tableView.mj_header endRefreshing];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            //列表数据源
            NSDictionary *storesDict = [dataObject objectForKey:@"store"];
            self.headView.storeDict = storesDict;
            
            storesDict = [dataObject objectForKey:@"activitys"];
            self.activitysArray = [DWYActivitysModel mj_objectArrayWithKeyValuesArray:storesDict];
            
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
   
        
    } failure:^(NSError * _Nonnull error) {
        //if (self.params != params) return;
        [MBManager showError];
        //[self.tableView.mj_header endRefreshing];
        NSLog(@"%@",error);
    }];

}


#pragma mark - UITableView 代理，数据源方法

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return section == 0?self.activitysArray.count:1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return indexPath.section == 0?80:140;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}
//脚视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 9;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    switch (indexPath.section) {
        case 0:{
            
            DWYActivityCell *cell = [tableView dequeueReusableCellWithIdentifier:FoodsAtivitysCellID];
            if (!cell) {
                cell = [[DWYActivityCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:FoodsAtivitysCellID];
            }
            [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    
            cell.model = self.activitysArray[indexPath.row];
            
            return cell;
        }

            break;
        case 1:{
            
            DWYFoodsCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:FoodscommentCellID];
            if (!cell) {
                cell = [[DWYFoodsCommentCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:FoodscommentCellID];
            }
            [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
            cell.preservesSuperviewLayoutMargins = NO;
            cell.separatorInset = UIEdgeInsetsZero;
            cell.layoutMargins = UIEdgeInsetsZero;
            
            //cell.model = self.dataArray[indexPath.row];
            
            return cell;
            
        }
            break;
    }

    return nil;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *headview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50)];
    headview.backgroundColor = [UIColor whiteColor];
    
    UIImageView *logoV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 30, 30)];
    [logoV setImage:[UIImage imageNamed:@"fooddeteil_icon_tuan_24_24"]];
    [headview addSubview:logoV];
    
    UILabel *textLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    textLabel.frame = CGRectMake(50, 13, 150, 25);
    [headview addSubview:textLabel];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(0, headview.height-1, SCREEN_WIDTH, 1);
    [headview addSubview:line];
    
    switch (section) {
        case 0:{
            textLabel.text = @"团购优惠";
        }
            break;
        case 1:{
            textLabel.text = @"用户评论";
        }
            break;
    }

    return headview;
}

-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated{
     self.navigationController.navigationBar.hidden = NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
