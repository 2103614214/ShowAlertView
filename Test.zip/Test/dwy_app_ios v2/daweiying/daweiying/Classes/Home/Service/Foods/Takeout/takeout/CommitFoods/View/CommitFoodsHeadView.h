//
//  CommitFoodsHeadView.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/16.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommitFoodsHeadView : UIView

@end



#pragma mark - 底部view
@interface CommitFoodsFootView : UIView

/** 部价 */
@property(nonatomic,copy)NSString *totalPriceStr;
@property(nonatomic,strong)UIButton *countBtn;
@end


#pragma mark - tabelview 底部view
@interface TabelFoodsFootView : UIView

@property(nonatomic,strong)NSDictionary *dict;

@end
