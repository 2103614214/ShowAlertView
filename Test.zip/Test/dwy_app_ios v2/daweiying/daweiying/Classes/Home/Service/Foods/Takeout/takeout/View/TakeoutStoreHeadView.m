//
//  TakeoutStoreHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/9.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutStoreHeadView.h"


#pragma mark - 顶部视图
@implementation TakeoutStoreHeadView
{
    UILabel  *_nameLabel;
    UIImageView *_logoV;
    UILabel *_remak;
    UILabel *_soundLabel;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        [self initWithSubViews]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews{
    self.backgroundColor = [UIColor lightGrayColor];
    
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, BAR_HEIGHT, NAV_HEIGHT, NAV_HEIGHT)];
    [backBtn setImage:[UIImage imageNamed:@"shop_btn_back_22_22"] forState:0];
    [self addSubview:backBtn];
    self.backBtn = backBtn;
    
    UIButton *makeBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-NAV_HEIGHT, BAR_HEIGHT, NAV_HEIGHT, NAV_HEIGHT)];
    [makeBtn setImage:[UIImage imageNamed:@"menu_btn_collection1_22_22"] forState:0];
    [makeBtn setImage:[UIImage imageNamed:@"menu_btn_collection2_22_22"] forState:UIControlStateSelected];
    [self addSubview:makeBtn];
    self.makeBtn = makeBtn;
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor whiteColor] fontSize:17 numberOfLines:1 text:self.storeNameStr];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:nameLabel];
    nameLabel.sd_layout
    .yIs(BAR_HEIGHT)
    .leftSpaceToView(backBtn, 10)
    .rightSpaceToView(makeBtn, 10)
    .heightIs(NAV_HEIGHT);
    _nameLabel = nameLabel;
    
    float y = BAR_HEIGHT + NAV_HEIGHT;
    float W = y - 10;
    CGRect rect = CGRectMake(15, y+5, W, W);
    UIImageView *logoV = [[UIImageView alloc] initWithFrame:rect];
    [logoV setImage:[UIImage imageNamed:@"shopstore_img_logo_45_45"]];
    logoV.layer.borderColor = [UIColor colorWithHex:0xd7d7d7].CGColor;
    logoV.layer.borderWidth = 0.5;
    logoV.layer.cornerRadius = logoV.width/2;
    logoV.layer.masksToBounds = YES;
    [self addSubview:logoV];
    _logoV = logoV;
    
    UILabel *remak = [Utils labelTextColor:[UIColor whiteColor] fontSize:15 numberOfLines:1 text:@""];
    [self addSubview:remak];
    remak.sd_layout
    .leftSpaceToView(logoV, 15)
    .yIs(y+5)
    .widthIs(SCREEN_WIDTH-logoV.width-40)
    .heightIs(26);
    _remak = remak;
    
    UIView *bgView = [UIView new];
    bgView.backgroundColor = [UIColor grayColor];
    bgView.layer.cornerRadius = 10;
    bgView.layer.masksToBounds = YES;
    [self addSubview:bgView];
    bgView.sd_layout
    .leftSpaceToView(logoV, 15)
    .topSpaceToView(remak, 2)
    .widthIs(SCREEN_WIDTH*0.6)
    .heightIs(25);
    
    UIImage *img = [UIImage imageNamed:@"menu_btn_notice_14_14"];
    UIImageView *soundV = [[UIImageView alloc] initWithFrame:CGRectMake(10, 3, 18, 18)];
    [soundV setImage:img];
    [bgView addSubview:soundV];
    
    UILabel *soundLabel = [Utils labelTextColor:[UIColor whiteColor] fontSize:13 numberOfLines:1 text:@""];
    soundLabel.frame = CGRectMake(33, 1, bgView.width-35, 21);
    [bgView addSubview:soundLabel];
    _soundLabel = soundLabel;
    
}


-(void)setStoreNameStr:(NSString *)storeNameStr{
    _nameLabel.text = storeNameStr;
}

-(void)setModel:(TakeoutStoreInfoModel *)model{
    _model = model;
    
    [_logoV sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
    
    NSString *disStr = @"";
    for (int i = 0; i <model.discounts.count; i++) {
        NSString *placeStr = model.discounts[i];
       disStr=[disStr  stringByAppendingFormat:@"%@,",placeStr];
    }
    _soundLabel.text = disStr;
    
    NSString *remarkStr = [NSString stringWithFormat:@"%d分钟 | 起送¥%@ | 配送¥%@",model.send_time,model.send_price,model.delivery];
    _remak.text = remarkStr;
}

@end

#pragma mark - 底部视图
@implementation TakeoutStoreFootView
{
    UILabel *_remark;
}

-(instancetype) initWithFrame:(CGRect)frame inView:(UIView *)parentView
{
    self = [super initWithFrame:frame];
    if (self) {
        self.parentView = parentView;
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xd9d9d9];
    line.frame = CGRectMake(0, 0, SCREEN_WIDTH, 1);
    [self addSubview:line];
    
    UIImageView *cartBtn = [[UIImageView alloc] initWithFrame:CGRectMake(15, 8, self.height-16, self.height-16)];
    [cartBtn setImage:[UIImage imageNamed:@"menu_btn_shoppingcart_35_35"]];
    cartBtn.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    [[tap rac_gestureSignal] subscribeNext:^(id x) {
        [self shoppCartClick];
    }];
    [cartBtn addGestureRecognizer:tap];
    [self addSubview:cartBtn];
    self.cartBtn = cartBtn;
    
    //小圆点
    self.badge = [[BadgeView alloc] initWithFrame:CGRectMake(cartBtn.frame.size.width, 5, 18, 18) withString:nil];
    [self addSubview:self.badge];
    self.badge.hidden = YES;
    
    UILabel *totalPrice = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:15 numberOfLines:1 text:@"¥ 0.00"];
    [self addSubview:totalPrice];
    totalPrice.sd_layout
    .leftSpaceToView(cartBtn, 10)
    .yIs(10)
    .widthIs(130)
    .heightIs(21);
    self.totalPrice = totalPrice;
    
    UILabel *remark = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_GRAY] fontSize:12 numberOfLines:1 text:@""];
    remark.adjustsFontSizeToFitWidth = YES;
    [self addSubview:remark];
    remark.sd_layout
    .leftSpaceToView(cartBtn, 10)
    .topSpaceToView(totalPrice, 0)
    .widthIs(150)
    .heightIs(21);
    _remark = remark;
    
    float countBtnW = 130;
    UIButton *countBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-countBtnW-10, 10, countBtnW, self.height-20)];
    countBtn.userInteractionEnabled = NO;
    countBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    countBtn.layer.cornerRadius = 3;
    countBtn.layer.masksToBounds = YES;
    countBtn.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:countBtn];
    self.countBtn = countBtn;
    
    
    int maxHeight = SCREEN_HEIGHT - 250;
    self.OrderList = [[GoodsListView alloc] initWithFrame:CGRectMake(0,SCREEN_HEIGHT - maxHeight, SCREEN_WIDTH, maxHeight) withObjects:nil  canReorder:YES];
    
    self.OverlayView = [[OverlayView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-59)];
    self.OverlayView.ShoppingCartView = self;
    self.OverlayView.alpha = 0.0;
    [self.OverlayView addSubview:self];
    [self.parentView addSubview:self.OverlayView];
    self.open = NO;
}


-(void)setModel:(TakeoutStoreInfoModel *)model{
    _model = model;
    
    NSString *btnStr = [NSString stringWithFormat:@"¥%@元起配送",model.send_price];
    [self.countBtn setTitle:btnStr forState:0];
    
    NSString *remarkStr = [NSString stringWithFormat:@"另外需要 ¥%@配送费",model.delivery];
    _remark.text = remarkStr;
}

-(void)setBadgeValue:(NSInteger)badgeValue{
    
    
    _badgeValue = badgeValue;
    self.badge.textLabel.text = [NSString stringWithFormat:@"%lu",(unsigned long)badgeValue];
    if (badgeValue>0) {
        self.badge.hidden = NO;
        self.countBtn.userInteractionEnabled = YES;
        self.cartBtn.userInteractionEnabled = YES;
        self.countBtn.backgroundColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
        
    }
    else{
        self.badge.hidden = YES;
        self.countBtn.userInteractionEnabled = NO;
        self.cartBtn.userInteractionEnabled = NO;
        self.countBtn.backgroundColor = [UIColor lightGrayColor];
        
    }
    
}

#pragma  mark 点击购物车
- (void)shoppCartClick{

    if (!(self.badgeValue>0)) {
        [self.cartBtn setUserInteractionEnabled:NO];
        return;
    }
    
    self.cartTableViewToFront(); //放置前方
    
    [self updateFrame:self.OrderList];
    [self.OverlayView addSubview:self.OrderList];
    
    [UIView animateWithDuration:0.1 animations:^{
        CGPoint point = self.cartBtn.center;
        
        point.y -= (self.OrderList.frame.size.height );
        self.OverlayView.alpha = 1.0;
        
    } completion:^(BOOL finished) {
        
        self.open = YES;
    }];
    
}

#pragma  mark 更新ListView 的高度
-(void)updateFrame:(GoodsListView *)orderListView
{
    
    if(orderListView.objects.count ==0){
        [self dismissAnimated:YES];
        return;
    }
  
    float height = 0;
    
    height = [orderListView.objects count] * 50 + 40+ 50;
    int maxHeight = self.parentView.frame.size.height - 250;
    if (height >= maxHeight) {
        height = maxHeight;
    }
    
    float orignY = self.OrderList.frame.origin.y;
    
    self.OrderList.frame = CGRectMake(self.OrderList.frame.origin.x, self.parentView.bounds.size.height - height - 59, self.OrderList.frame.size.width, height);
    float currentY = self.OrderList.frame.origin.y;
    
    if (self.open) {
        [UIView animateWithDuration:0.1 animations:^{
            CGPoint point = self.cartBtn.center;
            
            point.y -= orignY - currentY;

            
        } completion:^(BOOL finished) {
            
            
        }];
    }
    
}


#pragma mark - dismiss
-(void)dismissAnimated:(BOOL)animated
{
    
    [self.cartBtn bringSubviewToFront:self.OverlayView];
    
    [UIView animateWithDuration:0.1 animations:^{
        _OverlayView.alpha = 0.0;
        //self.shoppingCartBtn.frame = CGRectMake(10, -10, 50,50);
        
    } completion:^(BOOL finished) {
        self.open = NO;
    }];
}

@end
