//
//  DWYFoodsDetailsHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/29.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYFoodsDetailsHeadView.h"
#import "RatingView.h"



@implementation DWYFoodsDetailsHeadView
{
    RatingView *_rView;
    UILabel *_storeName;
    UILabel *_expenseLabel;
    UILabel *_addressLabel;
    UIImageView *_imageV;
    NSString *_telNumber;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        [self initWithSubViews]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews{
    
    self.backgroundColor = [UIColor clearColor];
    
    UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.17)];
    [self addSubview:imageV];
    _imageV = imageV;
    
    UIView *storeDetailView = [UIView new];
    storeDetailView.backgroundColor = [UIColor whiteColor];
    [self addSubview:storeDetailView];
    storeDetailView.sd_layout
    .topSpaceToView(imageV, 1)
    .xIs(0)
    .widthIs(SCREEN_WIDTH)
    .heightIs(SCREEN_HEIGHT*0.18);
    
    float X = 10;
    float H = storeDetailView.height/2;
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(X, H, SCREEN_WIDTH-X, 1);
    [storeDetailView addSubview:line];
    
    UILabel *storeName = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@""];
    storeName.frame = CGRectMake(X, 10, 150, 21);
    [storeDetailView addSubview:storeName];
    _storeName = storeName;
    
    //评分
    RatingView *rView = [[RatingView alloc]initWithFrame:CGRectMake(X, H/2, 90, 25) isEdit:NO];
    rView.ratingType = INTEGER_TYPE;//整颗星
    rView.score = 4;
    [storeDetailView addSubview:rView];
    _rView = rView;
    
    UILabel *expenseLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@""];
    [storeDetailView addSubview:expenseLabel];
    expenseLabel.sd_layout
    .topEqualToView(rView)
    .leftSpaceToView(rView, 10)
    .widthIs(100)
    .heightIs(25);
    _expenseLabel = expenseLabel;
    
    UIImageView *addressImg = [[UIImageView alloc] initWithFrame:CGRectMake(X, H+H/4, H/2, H/2)];
    [addressImg setImage:[UIImage imageNamed:@"orderfood_btn_location2_25_25"]];
    [storeDetailView addSubview:addressImg];
    
    UIButton *telBtn = [UIButton addBtnImage:@"fooddeteil_btn_phone_27_27" WithTarget:self action:@selector(telBtnClick)];
    telBtn.frame = CGRectMake(SCREEN_WIDTH-H/1.5-20, H+(H-H/1.5)/2, H/1.5, H/1.5);
    [storeDetailView addSubview:telBtn];

    
    UILabel *addressLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    addressLabel.numberOfLines = 2;
    addressLabel.adjustsFontSizeToFitWidth = YES;
    [storeDetailView addSubview:addressLabel];
    addressLabel.sd_layout
    .topSpaceToView(line, 10)
    .leftSpaceToView(addressImg, 10)
    .rightSpaceToView(telBtn, 10)
    .heightIs(H-20);
    _addressLabel = addressLabel;
}

-(void)setStoreDict:(NSDictionary *)storeDict{
    _storeDict = storeDict;
   
    [_imageV sd_setImageWithURL:[NSURL URLWithString:[_storeDict objectForKey:@"s_logo"]] placeholderImage:[UIImage imageNamed:placeImageName]];
    _storeName.text = [_storeDict objectForKey:@"s_name"];
    _expenseLabel.text = [NSString stringWithFormat:@"人均 %@",[_storeDict objectForKey:@"expense"]];
    _addressLabel.text = [_storeDict objectForKey:@"s_place"];
    _telNumber = [_storeDict objectForKey:@"s_phone"];
}

-(void)telBtnClick{
    //打电话
    [Utils callTel:_telNumber];

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
