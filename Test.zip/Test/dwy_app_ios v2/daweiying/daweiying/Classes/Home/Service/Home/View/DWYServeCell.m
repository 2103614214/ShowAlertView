//
//  DWYServeCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/27.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYServeCell.h"
#import "RatingView.h"

#import "DWYServeModel.h"

@implementation DWYServeCell
{
    UIImageView *_imageLogo;
    UILabel *_storeName;
    UILabel *_distanceLabel;
    UILabel *_addressLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        float cellH = kHeight(100);
        //初始化控件
        UIImageView *imageLogo = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, cellH-20, cellH-20)];
        [self addSubview:imageLogo];
        _imageLogo = imageLogo;
        
        UILabel *storeName = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@""];
        [self addSubview:storeName];
        storeName.sd_layout
        .yIs(10)
        .leftSpaceToView(imageLogo, 10)
        .widthIs(SCREEN_WIDTH-imageLogo.width-30)
        .heightIs(25);
        _storeName = storeName;
        
        //评分
        self.rView = [[RatingView alloc]initWithFrame:CGRectMake(cellH, 35, 90, 25)isEdit:NO];
        self.rView.ratingType = INTEGER_TYPE;//整颗星
        [self addSubview:self.rView];

        
        UILabel *distanceLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@"3.02km"];
        distanceLabel.textAlignment = NSTextAlignmentRight;
        distanceLabel.frame = CGRectMake(SCREEN_WIDTH-90, kHeight(69), 80, 21);
        [self addSubview:distanceLabel];
        _distanceLabel = distanceLabel;
        
        UILabel *addressLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
        addressLabel.frame = CGRectMake(imageLogo.width+20, kHeight(69), SCREEN_WIDTH-imageLogo.width-20-90, 21);
        [self addSubview:addressLabel];
        _addressLabel = addressLabel;
        
        self.priceLabel = [Utils labelTextColor:[UIColor colorWithHex:0xf67100] fontSize:15 numberOfLines:1 text:@""];
        self.priceLabel.hidden = YES;
        [self addSubview:self.priceLabel];
        self.priceLabel.sd_layout
        .bottomSpaceToView(addressLabel, 0)
        .leftSpaceToView(imageLogo, 10)
        .widthIs(120)
        .heightIs(25);
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setModel:(DWYServeModel *)model{
    _model = model;
    
    [_imageLogo sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
    _storeName.text = model.s_name;
    _addressLabel.text = model.s_place;
    
    _rView.score = model.grade;
    
    self.priceLabel.text = [NSString stringWithFormat:@"¥%@",model.price];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
