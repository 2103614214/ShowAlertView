//
//  TakeoutCommentHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/11.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutCommentHeadView.h"
#import "RatingView.h"

@implementation TakeoutCommentHeadView
{
    RatingView *_tasteView;
    RatingView *_packView;
    RatingView *_sendView;
    UILabel *_commentNumber;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addUI];
    }
    return self;
}

-(void)addUI{
    
    UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 5, SCREEN_WIDTH, SCREEN_HEIGHT*0.15-10)];
    bgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:bgView];
    
    float y = self.height*0.2;
    UILabel *commentNumber = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:30 numberOfLines:1 text:@"5.0"];
    commentNumber.textAlignment = NSTextAlignmentCenter;
    commentNumber.frame = CGRectMake(SCREEN_WIDTH*0.2, y, 80, self.height*0.4);
    [self addSubview:commentNumber];
    _commentNumber = commentNumber;
    
    UILabel *label = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@"商家评分"];
    label.textAlignment = NSTextAlignmentCenter;
    [self addSubview:label];
    label.sd_layout
    .topSpaceToView(commentNumber, 0)
    .leftEqualToView(commentNumber)
    .widthIs(commentNumber.width)
    .heightIs(y);
    
    UILabel *tasteLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"口味"];
    [self addSubview:tasteLabel];
    tasteLabel.sd_layout
    .yIs(y-5)
    .leftSpaceToView(commentNumber, 20)
    .widthIs(40)
    .heightIs(y);
    
    //口味评分
    float X = SCREEN_WIDTH*0.2+ commentNumber.width+20+ tasteLabel.width+5;
    float ratingVH = self.height/4;
    float ratingVY = 12;
    RatingView *tasteView = [[RatingView alloc]initWithFrame:CGRectMake(X, ratingVY, 90,ratingVH)isEdit:NO];
    tasteView.ratingType = INTEGER_TYPE;//整颗星
    [self addSubview:tasteView];
    _tasteView = tasteView;
    
    UILabel *packLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"包装"];
    [self addSubview:packLabel];
    packLabel.sd_layout
    .topSpaceToView(tasteLabel, 5)
    .leftSpaceToView(commentNumber, 20)
    .widthIs(40)
    .heightIs(y);
    
    //包装评分
    ratingVY += tasteView.height;
    RatingView *packView = [[RatingView alloc]initWithFrame:CGRectMake(X, ratingVY, 90,ratingVH) isEdit:NO];
    packView.ratingType = INTEGER_TYPE;//整颗星
    [self addSubview:packView];
    _packView = packView;
    
    UILabel *sendLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"配送"];
    [self addSubview:sendLabel];
    sendLabel.sd_layout
    .topSpaceToView(packLabel, 5)
    .leftSpaceToView(commentNumber, 20)
    .widthIs(40)
    .heightIs(y);
    
    //配送评分
    ratingVY += packView.height;
    RatingView *sendView = [[RatingView alloc]initWithFrame:CGRectMake(X, ratingVY, 90,ratingVH) isEdit:NO];
    sendView.ratingType = INTEGER_TYPE;//整颗星
    [self addSubview:sendView];
    _sendView = sendView;
}

-(void)setGrade:(NSDictionary *)grade{
    _grade = grade;
    
//    _tasteView.score = [[grade objectForKey:@"taste"] floatValue];
//    _packView.score = [[grade objectForKey:@"pack"] floatValue];
//    _sendView.score = [[grade objectForKey:@"grade"] floatValue];
//    _commentNumber.text = [NSString stringWithFormat:@"%.1f",[[grade objectForKey:@"delivery"] floatValue]];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
