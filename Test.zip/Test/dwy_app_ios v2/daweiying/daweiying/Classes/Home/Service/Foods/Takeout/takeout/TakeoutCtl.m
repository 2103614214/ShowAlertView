//
//  DWYTakeoutCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/28.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutCtl.h"
#import "TakeoutHeadView.h"
#import "TakeoutCell.h"
#import "TakeoutModel.h"

#import "TakeoutStoreDetailsCtl.h"

@interface TakeoutCtl () <UITableViewDelegate,UITableViewDataSource>

/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** 数据源 */
@property(nonatomic,strong)NSMutableArray *dataArray;
/** headview */
@property(nonatomic,strong)TakeoutHeadView *headView;
/** 分类 */
@property(nonatomic,strong)NSMutableArray *categoryArray;
/** 推荐商家 */
@property(nonatomic,strong)NSMutableArray *rec_storesArray;

/** 当前页码 */
@property (nonatomic, assign) NSInteger page;
/** 上一次的请求参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 当前页码 */
@property (nonatomic, assign) NSInteger page_total;
@end

static NSString * const TakeoutCellID = @"TakeoutCellID";
@implementation TakeoutCtl

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT-64-49)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.rowHeight = kHeight(100);
        _tableView.tableHeaderView = self.headView;
        _tableView.backgroundColor = [UIColor colorWithHex:0xedf0f3];
        _tableView.showsVerticalScrollIndicator = NO;
        [_tableView registerClass:[TakeoutCell class] forCellReuseIdentifier:TakeoutCellID];
    }
    return _tableView;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

-(NSMutableArray *)categoryArray{
    if (!_categoryArray) {
        _categoryArray = [NSMutableArray array];
    }
    return _categoryArray;
}

-(NSMutableArray *)rec_storesArray{
    if (!_rec_storesArray) {
        _rec_storesArray = [NSMutableArray array];
    }
    return _rec_storesArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.headView = [[TakeoutHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.5+10)];
    
    [self.view addSubview:self.tableView];
    
    // 添加刷新控件
    [self setupRefresh];

}

-(void)setupRefresh{
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    // 自动改变透明度
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    [self.tableView.mj_header beginRefreshing];
    
    self.tableView.mj_footer = [MJRefreshBackNormalFooter  footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreDatas)];
    //self.collectionView.mj_footer.ignoredScrollViewContentInsetBottom = 0;
}

//请求数据
-(void)loadData{
    
    // 结束上啦
    [self.tableView.mj_footer endRefreshing];
    
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    
    
    NSString *urlStr = [Utils getMemberServiceUri:@"restaurant"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        //NSLog(@"%@",responseObject);
        [MBManager hideAlert];
        
        [self.tableView.mj_header endRefreshing];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            id abc = [dataObject objectForKey:@"page_total"];
            self.page_total = [abc integerValue];
            //分类
            NSDictionary *categoryDict = [dataObject objectForKey:@"categorys"];
            self.categoryArray = [TakeoutCategoryModel mj_objectArrayWithKeyValuesArray:categoryDict];
            self.headView.categoryArray = self.categoryArray;
            
            //推荐商家
            categoryDict = [dataObject objectForKey:@"rec_stores"];
            self.rec_storesArray = [RecStoresModel mj_objectArrayWithKeyValuesArray:categoryDict];
            self.headView.rec_storesArray = self.rec_storesArray;
            
            //列表数据源
            categoryDict = [dataObject objectForKey:@"stores"];
            self.dataArray = [TakeoutModel mj_objectArrayWithKeyValuesArray:categoryDict];
            
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        // 清空页码
        self.page = 1;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.tableView.mj_header endRefreshing];
    }];
}

//加载更多
-(void)loadMoreDatas{
    
    // 结束下拉
    [self.tableView.mj_header endRefreshing];
    
    if (self.page == self.page_total)
    {
        [MBManager showBriefAlert:@"没有更多数据了"];
        [self.tableView.mj_footer endRefreshingWithNoMoreData]; //当所有数据加载完毕后执行此方法
        return;
    }
    // 参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    NSInteger page = self.page + 1;
    params[@"page"] = @(page);
    self.params = params;
    
    NSString *urlStr = [Utils getMemberLoginUri:@"serve"];
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        [MBManager hideAlert];
        //DLog(@"%@",responseObject);
        if (self.params != params) return;
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
            NSDictionary *hotDict = [dataObject objectForKey:@"stores"];
            NSArray *newProducts = [TakeoutModel mj_objectArrayWithKeyValuesArray:hotDict];
            [self.dataArray addObjectsFromArray:newProducts];
            
            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        [self.tableView.mj_footer endRefreshing];
        // 清空页码
        self.page = page;
        
    } failure:^(NSError * _Nonnull error) {
        if (self.params != params) return;
        [MBManager showError];
        [self.tableView.mj_footer endRefreshing];
    }];
    
}


#pragma mark - UITableView 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    TakeoutCell *cell = [tableView dequeueReusableCellWithIdentifier:TakeoutCellID];
    if (!cell) {
        cell = [[TakeoutCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TakeoutCellID];
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone]; // 去除阴影
    cell.preservesSuperviewLayoutMargins = NO;
    cell.separatorInset = UIEdgeInsetsZero;
    cell.layoutMargins = UIEdgeInsetsZero;
    
    cell.model = self.dataArray[indexPath.row];
    
    return cell;
}

#pragma mark -- UITableView 代理
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    TakeoutModel *model = self.dataArray[indexPath.row];
    TakeoutStoreDetailsCtl *storeDetails = [TakeoutStoreDetailsCtl new];
    storeDetails.storeName = model.s_name;
    storeDetails.s_id = model.s_id;
    [self.navigationController pushViewController:storeDetails animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
