//
//  TakeoutCategoryCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/10.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutCategoryCell.h"

@interface TakeoutCategoryCell()

@property (nonatomic, strong) UIView *redView;

@end

@implementation TakeoutCategoryCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        
        self.name = [Utils labelTextColor:[UIColor grayColor] fontSize:14 numberOfLines:1 text:@""];
        self.name.highlightedTextColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
        self.name.textAlignment = NSTextAlignmentCenter;
        self.name.frame = CGRectMake(3, 0, SCREEN_WIDTH*0.25-20, self.height);
        [self addSubview:self.name];
        
        UILabel *badgeLabel = [[UILabel alloc] init];
        badgeLabel.textColor = [UIColor whiteColor];
        badgeLabel.backgroundColor=[UIColor colorWithHex:0xfe8c01];
        badgeLabel.textAlignment = NSTextAlignmentCenter;
        badgeLabel.layer.cornerRadius=8;
        badgeLabel.layer.masksToBounds =YES;
        badgeLabel.font = [UIFont systemFontOfSize:11];
        badgeLabel.text = @"";
        badgeLabel.hidden = YES;
        [self addSubview:badgeLabel];
        badgeLabel.sd_layout
        .yIs(5)
        .leftSpaceToView(self.name, 0)
        .widthIs(15)
        .heightIs(15);
        self.badgeLabel = badgeLabel;
        
        self.redView = [[UIView alloc] initWithFrame:CGRectMake(0, self.contentView.height/4, 2, self.contentView.height/2)];
        self.redView.backgroundColor = [UIColor colorWithHex:UI_COLOR_ORANGE];
        [self.contentView addSubview:self.redView];
    }
    
    
    
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
    
    self.contentView.backgroundColor = selected ? [UIColor whiteColor] : [UIColor clearColor];
    self.highlighted = selected;
    self.name.highlighted = selected;
    self.redView.hidden = !selected;
    
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}



@end


@implementation TableViewHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        self.backgroundColor = [UIColor colorWithHex:UI_COLOR_BGCOLOR];
        self.name = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 200, 20)];
        self.name.font = [UIFont systemFontOfSize:13];
        self.name.textColor = [UIColor grayColor];
        [self addSubview:self.name];
    }
    return self;
}

@end
