//
//  KtvHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/17.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "KtvHeadView.h"

@implementation KtvHeadView
{
    UIImageView *_logoV;
    UILabel *_nameLabel;
    UILabel *_remarkLabel;
    UILabel *_telLabel;
    UILabel *_placeLabel;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initWithSubViews]; //初始化
    }
    return self;
}

// (self.view.height-10)/3  0.4 0.6
-(void)initWithSubViews{
    
    //简介
    float H = self.height-10;
    UIView *introV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, H*0.4)];
    introV.backgroundColor = [UIColor whiteColor];
    [self addSubview:introV];
    
    UIImageView *logoV = [[UIImageView alloc] initWithFrame:CGRectMake(15, 8, introV.height-15, introV.height-15)];
    [logoV setImage:[UIImage imageNamed:@"shopstore_img_logo_45_45"]];
    logoV.layer.cornerRadius = logoV.width/2;
    logoV.layer.masksToBounds = YES;
    [introV addSubview:logoV];
    _logoV = logoV;
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@"百老汇音乐剧"];
    [introV addSubview:nameLabel];
    nameLabel.sd_layout
    .leftSpaceToView(logoV, 10)
    .topEqualToView(logoV)
    .widthIs(SCREEN_WIDTH-logoV.width-45)
    .heightIs(logoV.height/2);
    _nameLabel = nameLabel;
    
    UILabel *remarkLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@"百老汇音乐剧"];
    [introV addSubview:remarkLabel];
    remarkLabel.sd_layout
    .leftSpaceToView(logoV, 10)
    .topSpaceToView(nameLabel, 0)
    .widthIs(SCREEN_WIDTH-logoV.width-45)
    .heightIs(21);
    _remarkLabel = remarkLabel;
    
    //电话，地址
    UIView *infoV = [[UIView alloc] initWithFrame:CGRectMake(0, introV.height+5, SCREEN_WIDTH, H*0.6)];
    infoV.backgroundColor = [UIColor whiteColor];
    [self addSubview:infoV];
    
    UIImageView *telV = [Utils addImgWithFrame:CGRectMake(30, (infoV.height/2-25)/2, 25, 25) AndImage:@"shopstore_icon_phone_22_22"];
    [infoV addSubview:telV];
    
    UILabel *telLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    [infoV addSubview:telLabel];
    telLabel.sd_layout
    .leftSpaceToView(telV, 10)
    .yIs((infoV.height/2-25)/2)
    .widthIs(SCREEN_WIDTH-telV.width-50)
    .heightIs(25);
    _telLabel = telLabel;
    
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(15, infoV.height/2, SCREEN_WIDTH-15, 1);
    [infoV addSubview:line];
    
    UIImageView *placeV = [Utils addImgWithFrame:CGRectMake(30, (infoV.height/2-25)/2+infoV.height/2, 25, 25) AndImage:@"shopstore_icon_location_22_22"];
    [infoV addSubview:placeV];
    
    UILabel *placeLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    [infoV addSubview:placeLabel];
    placeLabel.sd_layout
    .leftSpaceToView(placeV, 10)
    .yIs((infoV.height/2-25)/2+infoV.height/2)
    .widthIs(SCREEN_WIDTH-telV.width-50)
    .heightIs(25);
    _placeLabel = placeLabel;
}

-(void)setModel:(DWYServeModel *)model{
    _model = model;
    [_logoV sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
    _nameLabel.text = model.s_name;
    _remarkLabel.text = model.s_introduce;
    _telLabel.text = @"0755-25176717";
    _placeLabel.text= model.s_place;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
