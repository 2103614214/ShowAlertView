//
//  GoodsListView.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TakeoutStoreFootView;

@interface GoodsListView : UIView <UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) NSMutableArray *objects;

@property (nonatomic,strong) UITableView *tableView;

/** 饭盒价格 */
@property(nonatomic,assign)float box_price;

@property (nonatomic,copy) void (^GoodListCellClick)(NSMutableArray *dataArray);


-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSMutableArray *)objects;

-(instancetype)initWithFrame:(CGRect)frame withObjects:(NSMutableArray *)objects canReorder:(BOOL)reOrder;


@end
