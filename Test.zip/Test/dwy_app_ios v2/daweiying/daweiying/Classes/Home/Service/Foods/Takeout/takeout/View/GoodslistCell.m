//
//  GoodslistCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "GoodslistCell.h"

@implementation GoodslistCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self initWithSubViews];
    }
    return self;
}

-(void)initWithSubViews{
    
    //加号
    UIButton *addBtn = [UIButton addBtnImage:@"menu_btn_add_23_23" WithTarget:self action:@selector(plusclick:)];
    addBtn.frame = CGRectMake(SCREEN_WIDTH-50, 10, 30, 30);
    [self addSubview:addBtn];
    
    
    UILabel *numberLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:13 numberOfLines:1 text:@""];
    numberLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:numberLabel];
    numberLabel.sd_layout
    .rightSpaceToView(addBtn, 2)
    .yIs(10)
    .widthIs(30)
    .heightIs(30);
    self.numberLabel = numberLabel;
    
    //减号
    UIButton *subBtn = [UIButton addBtnImage:@"menu_btn_reduce_23_23" WithTarget:self action:@selector(minusclick:)];
    [self addSubview:subBtn];
    subBtn.sd_layout
    .rightSpaceToView(numberLabel, 2)
    .yIs(10)
    .widthIs(30)
    .heightIs(30);
    
    UILabel *priceLabel = [Utils labelTextColor:[UIColor colorWithHex:UI_COLOR_ORANGE] fontSize:14 numberOfLines:1 text:@""];
    priceLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:priceLabel];
    priceLabel.sd_layout
    .yIs(10)
    .rightSpaceToView(subBtn, 20)
    .widthIs(80)
    .heightIs(30);//135
    self.priceLabel = priceLabel;
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    [self addSubview:nameLabel];
    nameLabel.sd_layout
    .xIs(15)
    .yIs(10)
    .heightIs(30)
    .rightSpaceToView(priceLabel, 20);
    self.Namelabel = nameLabel;
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(TakeoutLeftModel *)model{
    self.Namelabel.text = [NSString stringWithFormat:@"%@",model.pro_name];
    self.priceLabel.text = [NSString stringWithFormat:@"¥ %@",model.price];
    self.numberLabel.text = [NSString stringWithFormat:@"%ld",model.countNumber];
}



- (void)minusclick:(id)sender {
    self.number =[self.numberLabel.text integerValue];
    self.number -=1;
    [self showNumber:self.number];
    self.operationBlock(self.number,NO);
}

- (void)plusclick:(id)sender {
    
    self.number =[self.numberLabel.text integerValue];
    self.number += 1;
    [self showNumber:self.number];
    self.operationBlock(self.number,YES);

}



-(void)showNumber:(NSUInteger)count
{
    self.numberLabel.text = [NSString stringWithFormat:@"%lu",(unsigned long)self.number];
}

@end
