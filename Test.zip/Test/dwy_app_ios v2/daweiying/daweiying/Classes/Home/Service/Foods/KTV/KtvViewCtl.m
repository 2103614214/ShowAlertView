//
//  KtvViewCtl.m
//  daweiying
//
//  Created by 汪亮 on 2017/10/17.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "KtvViewCtl.h"
#import "KtvHeadView.h"
@interface KtvViewCtl () <UITableViewDelegate,UITableViewDataSource>

/** tableview */
@property(nonatomic,strong)UITableView *tableView;
/** headview */
@property(nonatomic,strong)KtvHeadView *headView;

@end

@implementation KtvViewCtl

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.model.s_name;
    
    self.tableView = [self setupTableView];
    
    [self loadData];
}

-(void)loadData{
    [MBManager showLoading];
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"sid"] = @(self.model.s_id);
    
    NSString *urlStr = [Utils getMemberServiceUri:@"ktv_detail"];
    
    [[WLNetworking sharedWLNetworking] POST:urlStr parameters:params success:^(id  _Nonnull responseObject) {
        //NSLog(@"%@",responseObject);
        [MBManager hideAlert];
        
        NSMutableDictionary *ret = [Utils didResponse:responseObject];
        NSString *status = [ret objectForKey:@"status"];
        
        
        if ([status isEqualToString:@"200"]) {
            
            id dataObject = [responseObject objectForKey:@"data"];
            
//            //列表数据源
//            NSDictionary *storesDict = [dataObject objectForKey:@"store"];
//            self.headView.storeDict = storesDict;
//            
//            storesDict = [dataObject objectForKey:@"activitys"];
//            self.activitysArray = [DWYActivitysModel mj_objectArrayWithKeyValuesArray:storesDict];
//            
//            [self.tableView reloadData];
            
        }else{
            [MBManager showError:@"获取数据失败"];
        }
        
        
    } failure:^(NSError * _Nonnull error) {
        //if (self.params != params) return;
        [MBManager showError];
        //[self.tableView.mj_header endRefreshing];
        NSLog(@"%@",error);
    }];

}

-(UITableView *)setupTableView{
    self.headView = [[KtvHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.28)];
    self.headView.model = self.model;
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    [self.view addSubview:tableView];
    tableView.backgroundColor = [UIColor colorWithHex:0xefeff4];
    tableView.showsVerticalScrollIndicator = NO;
    tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero]; //去除多余分割线
    
    // 代理&&数据源
    tableView.delegate = self;
    tableView.dataSource = self;
    
    
    tableView.tableHeaderView = self.headView;
    return tableView;
}

#pragma mark - UITableViewDelegate && UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellID"];
    }
    cell.backgroundColor = [UIColor colorWithWhite:0.998 alpha:1];

    cell.textLabel.text = @"tableView";

    return cell;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
