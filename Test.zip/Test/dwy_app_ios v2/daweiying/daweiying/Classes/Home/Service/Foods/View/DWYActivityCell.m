//
//  DWYActivityCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/29.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "DWYActivityCell.h"
#import "DWYActivitysModel.h"

@implementation DWYActivityCell
{
    UIImageView *_storeLogoV;
    UILabel *_nameLabel;
    UILabel *_priceLabel;
    UILabel *_numberLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self initWithSubViews]; //初始化控件
    }
    return self;
}

-(void)initWithSubViews{
    UIImageView *storeLogoV = [[UIImageView alloc] initWithFrame:CGRectMake(30, 10, 60, 60)];
    [self addSubview:storeLogoV];
    _storeLogoV = storeLogoV;
    
    UILabel *nameLabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
    [self addSubview:nameLabel];
    nameLabel.sd_layout
    .topEqualToView(storeLogoV)
    .leftSpaceToView(storeLogoV, 10)
    .widthIs(150)
    .heightIs(25);
    _nameLabel = nameLabel;
    
    UILabel *priceLabel = [Utils labelTextColor:UIColorFromRGB(UI_COLOR_ORANGE) fontSize:15 numberOfLines:1 text:@""];
    [self addSubview:priceLabel];
    priceLabel.sd_layout
    .topSpaceToView(nameLabel, 10)
    .leftEqualToView(nameLabel)
    .widthIs(150)
    .heightIs(25);
    _priceLabel = priceLabel;
    
    UILabel *numberLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
    numberLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:numberLabel];
    numberLabel.sd_layout
    .yIs(30)
    .xIs(SCREEN_WIDTH-160)
    .widthIs(150)
    .heightIs(25);
    _numberLabel = numberLabel;
    
}

-(void)setModel:(DWYActivitysModel *)model{
    _model = model;
    
    [_storeLogoV sd_setImageWithURL:[NSURL URLWithString:@"http://39.108.226.155/upload/123.png"] placeholderImage:[UIImage imageNamed:placeImageName]];
    _nameLabel.text = model.name;
    
    _numberLabel.text = [NSString stringWithFormat:@"已售%@份 >",model.number];
   
    NSString *balance =[NSString stringWithFormat:@"¥ %@",model.now_price];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:balance];
    [aString addAttribute:NSFontAttributeName value:[UIFont fontWithName:@ "Arial"  size:(14.0)]range:NSMakeRange(0, 1)];
    _priceLabel.attributedText= aString;
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
