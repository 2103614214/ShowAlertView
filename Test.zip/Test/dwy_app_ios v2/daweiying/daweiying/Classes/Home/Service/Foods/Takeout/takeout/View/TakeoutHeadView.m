//
//  TakeoutHeadView.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/29.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutHeadView.h"
#import "TakeoutModel.h"

@implementation TakeoutHeadView
{
    UIImageView *_imageView1;
    UIImageView *_imageView2;
    UIImageView *_imageView3;
    UIImageView *_imageView4;
    UIImageView *_imageView5;
    
    UILabel *_label1;
    UILabel *_label2;
    UILabel *_label3;
    UILabel *_label4;
    UILabel *_label5;
    
    //推荐商家
    UIImageView *_recImageView1;
    UIImageView *_recImageView2;
    UIImageView *_recImageView3;
    UIImageView *_recImageView4;

    
    UILabel *_nameLabel1;
    UILabel *_nameLabel2;
    UILabel *_nameLabel3;
    UILabel *_nameLabel4;

    
    UILabel *_introduceLabel1;
    UILabel *_introduceLabel2;
    UILabel *_introduceLabel3;
    UILabel *_introduceLabel4;

    
}


#define CURRENT_SIZE(_size) _size / 375.0 * SCREEN_WIDTH
-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        [self initWithSubViews];
    }
    return self;
}


-(void)initWithSubViews{
    self.backgroundColor = [UIColor clearColor];
    
    //分类
    UIView *categoryView = [UIView new];
    categoryView.backgroundColor = [UIColor whiteColor];
    categoryView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*0.15);
    [self addSubview:categoryView];
    
    for (int i=0; i<5;i++) {
        UIView * vi = [[UIView alloc] initWithFrame:CGRectMake((SCREEN_WIDTH / 5.0 ) * i, 0, SCREEN_WIDTH / 5.0, self.height)];
        vi.userInteractionEnabled = YES;
        vi.tag = 100 + i;
        vi.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] init];
        [[tap1 rac_gestureSignal] subscribeNext:^(id x) {
            
            //self.imageViewBlock(@"selection", 101);
            NSLog(@"%ld",vi.tag);
        }];
        [vi addGestureRecognizer:tap1];
        
        float imageVW = vi.width/1.8;
        UIImageView * imageV = [[UIImageView alloc] initWithFrame:CGRectMake((vi.width-imageVW)/2, CURRENT_SIZE(15), imageVW, vi.width/1.8)];
        [vi addSubview:imageV];
        
        UILabel * label = [[UILabel alloc] init];
        label.font = [UIFont systemFontOfSize:11];
        label.textColor = [UIColor grayColor];
        label.textAlignment = NSTextAlignmentCenter;
        [vi addSubview:label];
        label.sd_layout
        .topSpaceToView(imageV, 5)
        .centerXEqualToView(imageV)
        .widthIs(SCREEN_HEIGHT / 5)
        .heightIs(15);
        
        if (i == 0) {
            _imageView1 = imageV;
            _label1 = label;
        }else if (i == 1){
            _imageView2 = imageV;
            _label2 = label;
        }else if (i == 2){
            _imageView3 = imageV;
            _label3 = label;
        }else if (i == 3){
            _imageView4 = imageV;
            _label4 = label;
        }else if (i == 4){
            _imageView5 = imageV;
            _label5 = label;
        }else{
            return;
        }
        
        [categoryView addSubview:vi];
        
        
    }

    
    
    //推荐商家
    UIView *storeView = [UIView new];
    storeView.backgroundColor = [UIColor whiteColor];
    storeView.frame = CGRectMake(0, SCREEN_HEIGHT*0.15+5, SCREEN_WIDTH, SCREEN_HEIGHT*0.35);
    [self addSubview:storeView];
    
    float titleX = storeView.width/2-25;
    UILabel *titleLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:15 numberOfLines:1 text:@"推荐商家"];
    titleLabel.frame = CGRectMake(titleX, 0, 90, storeView.height*0.2);
    [storeView addSubview:titleLabel];
    
    UIImage *imageName = [UIImage imageNamed:@"shop_icon_fire_18_18"];
    UIImageView *imageV = [[UIImageView alloc] initWithImage:imageName];
    float imageVW = titleLabel.height/1.5;
    imageV.frame = CGRectMake(titleX-imageVW-10, 5, imageVW, imageVW);
    [storeView addSubview:imageV];
    
    float viH = (storeView.height- titleLabel.height-2)/2;
    float viW = (storeView.width- 1)/2;
    UILabel *line = [UILabel new];
    line.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line.frame = CGRectMake(0, titleLabel.height, SCREEN_WIDTH, 1);
    [storeView addSubview:line];
    
    UILabel *line1 = [UILabel new];
    line1.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line1.frame = CGRectMake(0, titleLabel.height+viH+1, SCREEN_WIDTH, 1);
    [storeView addSubview:line1];
    
    UILabel *line2 = [UILabel new];
    line2.backgroundColor = [UIColor colorWithHex:0xeeeeee];
    line2.frame = CGRectMake(viW, titleLabel.height, 1, storeView.height-titleLabel.height);
    [storeView addSubview:line2];
    
    for (int i=0; i<4; i++) {
        
        
        UIView * vi = [[UIView alloc] init];
        vi.userInteractionEnabled = YES;
        vi.tag = 100 +i;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
        [[tap rac_gestureSignal] subscribeNext:^(id x) {
            //触发点击事件
//            if (self.delegate && [self.delegate respondsToSelector:@selector(viewDidClick:selectIndex:)]) {
//                [self.delegate viewDidClick:@"chooseView" selectIndex:vi.tag];
//            }
            DLog(@"1111111");
        }];
        [vi addGestureRecognizer:tap];
        
        [storeView addSubview:vi];
        
        if (i < 2) {
            
            vi.sd_layout
            .topSpaceToView(line, 0)
            .xIs(viW*i+1)
            .widthIs(viW)
            .heightIs(viH);
        }else if (i>1 && i<4){

            vi.sd_layout
            .xIs(viW*(i-2)+2)
            .yIs(titleLabel.height+viH+2)
            .widthIs(viW)
            .heightIs(viH);
        }
        
        UIImageView * imageV = [[UIImageView alloc] init];
        float imageVW = vi.width/3;
        float imageVH = vi.height*0.7;
        imageV.frame = CGRectMake(vi.width-imageVW-10, vi.height*0.15, imageVW, imageVH);
        [vi addSubview:imageV];
        
        UILabel *namelabel = [Utils labelTextColor:[UIColor blackColor] fontSize:14 numberOfLines:1 text:@""];
        namelabel.textAlignment = NSTextAlignmentLeft;
        [vi addSubview:namelabel];
        namelabel.sd_layout
        .topEqualToView(imageV)
        .rightSpaceToView(imageV, 5)
        .xIs(10)
        .heightIs(21);
        
        UILabel *introducelabel = [Utils labelTextColor:[UIColor grayColor] fontSize:11 numberOfLines:1 text:@""];
        introducelabel.textAlignment = NSTextAlignmentLeft;
        [vi addSubview:introducelabel];
        introducelabel.sd_layout
        .topSpaceToView(namelabel, 2)
        .rightSpaceToView(imageV, 5)
        .xIs(10)
        .heightIs(21);
        
        if (i == 0) {
            _recImageView1 = imageV;
            _nameLabel1 = namelabel;
            _introduceLabel1 = introducelabel;
        }else if (i == 1){
            _recImageView2 = imageV;
            _nameLabel2 = namelabel;
            _introduceLabel2 = introducelabel;
        }else if (i == 2){
            _recImageView3 = imageV;
            _nameLabel3 = namelabel;
            _introduceLabel3= introducelabel;
        }else if (i == 3){
            _recImageView4 = imageV;
            _nameLabel4 = namelabel;
            _introduceLabel4 = introducelabel;
        }else{
            return;
        }
        
    }

    
}


-(void)setCategoryArray:(NSArray *)categoryArray{
    _categoryArray = categoryArray;
    
    for (int i =0; i < _categoryArray.count; i++) {
        TakeoutCategoryModel *model = _categoryArray[i];
        if (i == 0) {
            [_imageView1 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label1.text = model.cate_name;
        }else if (i == 1){
            [_imageView2 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label2.text = model.cate_name;
        }else if (i == 2){
            [_imageView3 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label3.text = model.cate_name;
        }else if (i == 3){
            [_imageView4 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label4.text = model.cate_name;
        }else if (i == 4){
            [_imageView5 sd_setImageWithURL:[NSURL URLWithString:model.cate_url] placeholderImage:[UIImage imageNamed:placeImageName]];
            _label5.text = model.cate_name;
        }else{
            
            return;
        }
    }

}

-(void)setRec_storesArray:(NSArray *)rec_storesArray{
    _rec_storesArray = rec_storesArray;
    
    for (int i =0; i < _rec_storesArray.count; i++) {
        RecStoresModel *model = _rec_storesArray[i];
        if (i == 0) {
            [_recImageView1 sd_setImageWithURL:[NSURL URLWithString:model.recommend_img] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel1.text = model.s_name;
            _introduceLabel1.text = model.s_introduce;
        }else if (i == 1){
            [_recImageView2 sd_setImageWithURL:[NSURL URLWithString:model.recommend_img] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel2.text = model.s_name;
            _introduceLabel2.text = model.s_introduce;
        }else if (i == 2){
            [_recImageView3 sd_setImageWithURL:[NSURL URLWithString:model.recommend_img] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel3.text = model.s_name;
            _introduceLabel3.text = model.s_introduce;
        }else if (i == 3){
            [_recImageView4 sd_setImageWithURL:[NSURL URLWithString:model.recommend_img] placeholderImage:[UIImage imageNamed:placeImageName]];
            _nameLabel4.text = model.s_name;
            _introduceLabel4.text = model.s_introduce;
        }else{
            
            return;
        }
    }

}

@end
