//
//  TakeoutCell.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/29.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import "TakeoutCell.h"
#import "TakeoutModel.h"
#import "RatingView.h"

@implementation TakeoutCell
{
    RatingView *_rView;
    UIImageView *_imageLogo;
    UILabel *_storeName;
    UILabel *_distanceLabel;
    UILabel *_sendLabel;
    UILabel *_sendPriceLabel;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        float cellH = kHeight(100);
        //初始化控件
        UIImageView *imageLogo = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, cellH-20, cellH-20)];
        [self addSubview:imageLogo];
        _imageLogo = imageLogo;
        
        UILabel *storeName = [Utils labelTextColor:[UIColor blackColor] fontSize:15 numberOfLines:1 text:@""];
        [self addSubview:storeName];
        storeName.sd_layout
        .yIs(10)
        .leftSpaceToView(imageLogo, 10)
        .widthIs(SCREEN_WIDTH-imageLogo.width-30)
        .heightIs(25);
        _storeName = storeName;
        
        //评分
        RatingView * rView = [[RatingView alloc]initWithFrame:CGRectMake(cellH, 35, 90, 25) isEdit:NO];
        rView.ratingType = INTEGER_TYPE;//整颗星
        [self addSubview:rView];
        _rView = rView;
        
        UILabel *distanceLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@"3.02km"];
        distanceLabel.textAlignment = NSTextAlignmentRight;
        distanceLabel.frame = CGRectMake(SCREEN_WIDTH-90, kHeight(69), 80, 21);
        [self addSubview:distanceLabel];
        _distanceLabel = distanceLabel;
        
        UILabel *sendLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
        sendLabel.frame = CGRectMake(imageLogo.width+20, kHeight(69), 70, 21);
        [self addSubview:sendLabel];
        _sendLabel = sendLabel;
        
        UILabel *sendPriceLabel = [Utils labelTextColor:[UIColor grayColor] fontSize:13 numberOfLines:1 text:@""];
        //sendPriceLabel.frame = CGRectMake(imageLogo.width+40+sendLabel.width, 69, 80, 21);
        [self addSubview:sendPriceLabel];
        _sendPriceLabel = sendPriceLabel;
        sendPriceLabel.sd_layout
        .topEqualToView(sendLabel)
        .leftSpaceToView(sendLabel, 10)
        .widthIs(80)
        .heightIs(21);
    }
    return self;
}

-(void)setModel:(TakeoutModel *)model{
    _model = model;
    
    [_imageLogo sd_setImageWithURL:[NSURL URLWithString:model.s_logo] placeholderImage:[UIImage imageNamed:placeImageName]];
    _storeName.text = model.s_name;
    _sendLabel.text = [NSString stringWithFormat:@"¥%@ 起送",model.send_price];
    _sendPriceLabel.text = [NSString stringWithFormat:@"配送费 ¥%d",model.delivery];
    _rView.score = model.grade;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
