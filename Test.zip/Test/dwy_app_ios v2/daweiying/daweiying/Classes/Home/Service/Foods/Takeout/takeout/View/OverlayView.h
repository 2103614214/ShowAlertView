//
//  OverlayView.h
//  daweiying
//
//  Created by 汪亮 on 2017/10/14.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TakeoutStoreFootView;
@class TakeoutLeftModel;
typedef enum {
    isFoodsDetailsPage = 1,  //食品详情
    isPullListPage = 2,  //上拉列表
} FoodsType;

@interface OverlayView : UIView

/** 弹出视图类型 */
@property(nonatomic,assign)FoodsType type;

@property (nonatomic,copy) void (^removeOverlayView)();

-(void)setupUI;

@property (nonatomic,strong) TakeoutStoreFootView *ShoppingCartView;

@property (nonatomic,assign) NSInteger number;

@property (nonatomic,copy) void (^operationBlock)(NSInteger number,BOOL plus);
/** 模型  */
@property (nonatomic, strong)TakeoutLeftModel *model;
@end
