//
//  Constants.h
//  daweiying
//
//  Created by 汪亮 on 2017/9/12.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//


typedef enum {
    OrderTypeAll = 1,
    OrderTypeWaitPay = 2,
    OrderTypeWaitShipments = 3,
    OrderTypeWaitReceive = 4,
    OrderTypeCommit = 5
} OrdersType;

/** 占位图片名 */
FOUNDATION_EXPORT NSString *const placeImageName;
/** 占位图头像 */
FOUNDATION_EXPORT NSString *const placeLogoImageName;
/** 导航栏高度 */
FOUNDATION_EXPORT int const NAV_HEIGHT;
/** 底部tabbar高度 */
FOUNDATION_EXPORT int const TABBAR_HEIGHT;
/** 顶部状态栏高度 */
FOUNDATION_EXPORT int const BAR_HEIGHT;


/** 桔黄色 */
FOUNDATION_EXPORT int const UI_COLOR_ORANGE;
/** 灰色 */
FOUNDATION_EXPORT int const UI_COLOR_GRAY;
/** 背景颜色 */
FOUNDATION_EXPORT int const UI_COLOR_BGCOLOR;


/** 开单-顶部标题的Y */
UIKIT_EXTERN CGFloat const TitilesViewY;
/** 顶部标题的高度 */
UIKIT_EXTERN CGFloat const OrderTitilesViewH;

UIKIT_EXTERN CGFloat const Gap;
UIKIT_EXTERN CGFloat const leftSpace;
UIKIT_EXTERN CGFloat const rightSpace;

//微信
FOUNDATION_EXPORT NSString *const WXAPPID;
FOUNDATION_EXPORT NSString *const WX_APP_Login_SECRET;
FOUNDATION_EXPORT NSString *const WX_APP_SECRET;

//商家入驻协议
FOUNDATION_EXPORT NSString *const merchantEnterUrl;
//隐私协议
FOUNDATION_EXPORT NSString *const privacyProtocolUrl;
//注册协议
FOUNDATION_EXPORT NSString *const registrationProtocolUrl;
//付甲一方
FOUNDATION_EXPORT NSString *const fjyfGuideUrl;

