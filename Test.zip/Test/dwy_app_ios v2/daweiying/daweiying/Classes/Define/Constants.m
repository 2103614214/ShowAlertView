//
//  Constants.m
//  daweiying
//
//  Created by 汪亮 on 2017/9/12.
//  Copyright © 2017年 大维营(深圳)科技有限公司. All rights reserved.
//


NSString *const placeImageName = @"placeholder";
NSString *const placeLogoImageName = @"shopstore_img_logo_45_45";

int const NAV_HEIGHT = 44;
int const TABBAR_HEIGHT = 49;
int const BAR_HEIGHT = 20;

int const UI_COLOR_ORANGE= 0xf67100;
int const UI_COLOR_GRAY= 0x999999;
int const UI_COLOR_BGCOLOR = 0xefeff4;



/** 开单-顶部标题的Y */
CGFloat const TitilesViewY = 64;
/** 顶部标题的高度 */
CGFloat const OrderTitilesViewH = 35;

CGFloat const Gap = 10;
CGFloat const leftSpace = 50.0;
CGFloat const rightSpace = 10.0;

//微信
NSString *const WXAPPID = @"wx1b15934a72b5ed02"; //wx1b15934a72b5ed02
//登录
NSString *const WX_APP_Login_SECRET = @"57dbb95fbe6f04c1c356d4be08625509";
//支付
NSString *const WX_APP_SECRET = @"8b2247232d1acd07281458832b692151";


//商家入驻协议
NSString *const merchantEnterUrl = @"http://www.dwying.com/merchantEnter";
//隐私协议
NSString *const privacyProtocolUrl = @"http://www.dwying.com/privacyProtocol";
//注册协议
NSString *const registrationProtocolUrl = @"http://www.dwying.com/registrationProtocol";
//付甲一方
NSString *const fjyfGuideUrl = @"http://www.dwying.com/fjyfGuide";

